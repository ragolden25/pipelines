#!/bin/bash

ansible-playbook -i /home/ansible/inventory.ini configure_grafana_stack.yml --vault-password-file ~/vault_pass.txt
