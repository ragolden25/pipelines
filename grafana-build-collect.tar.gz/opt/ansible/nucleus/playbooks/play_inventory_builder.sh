#!/bin/bash

ansible-playbook -vvv create_inventory.yml --vault-password-file ~/vault_pass.txt
