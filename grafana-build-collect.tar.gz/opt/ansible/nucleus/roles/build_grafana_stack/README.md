# build_grafana_stack Role

## 📂 Purpose
Automates the quarterly build-and-release pipeline for the Grafana stack:
version detection, image build, save, delivery, scanning, and signing of
functional and hardened images.

## ⚙️ Tasks

### Phase 1: Quarter Management
- Determine quarter automatically
- Set raw quarter facts
- Normalize quarter variables
- Fail if quarter and previous_quarter are identical
- Set is_new_quarter fact

### Phase 2: Directory & Metadata Preparation
- Create and seed quarterly directories
- Update "current" symlink to point to new quarter
- Clean new quarter directory
- Detect component versions
- Generate metadata files

### Phase 3: Image Build
- Build functional images
- Build hardened images

### Phase 4: Save & Delivery
- Save functional images
- Save hardened images
- Deliver functional images
- Deliver hardened images

### Phase 5: Version & Compose Finalization
- Read GRAFANA_VERSION from versions.env
- Read PROMETHEUS_VERSION from versions.env
- Read NGINX_VERSION from versions.env
- Read IDRAC_VERSION from versions.env
- Promote version vars into facts (UPPERCASE)
- Map uppercase vars to lowercase vars
- Render docker-compose.yml and .env
- Gather functional + hardened Dockerfiles
- Ensure quarterly gpgkeys directory exists

### Phase 6: Security Scanning
- Scan hardened and functional images
  - SBOM generation (Syft)
  - Vulnerability scanning (Grype)
  - Compensating control verification — confirms hardening mitigations
    (purged packages, manual binary/library removal) are actually present
    in the built image, covering CVEs that Grype flags but can't verify
    were mitigated
  - OpenSCAP compliance scanning
- Scan SAST dockerfiles
  - Static analysis of Dockerfiles (Hadolint)

### Phase 7: Image Signing
- Sign hardened images
- Sign functional images
- Sign base image

### Phase 8: Cleanup
- Normalize permissions

## 📌 Requirements
- Ansible control node on server ansible-forge

## 📖 Notes
- Phase groupings reflect task name semantics and preserve the original
  execution order from tasks/main.yml; they are not derived from inline
  comments in the source file. Confirm the boundaries match your intent.
- Time it takes to build and scan images is approximately 17 minutes.

## 🚀 Usage
```yaml
- hosts: build_grafana_stack
  roles:
    - build_grafana_stack
```
