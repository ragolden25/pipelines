#!/usr/bin/env python3

import os
import json
import zipfile
import sys
from datetime import datetime

BASE_DIR = "/opt/ansible/scripts/VisualStudioCode"
VERSIONS_DIR = os.path.join(BASE_DIR, "versions")


def load_json(path):
    with open(path) as f:
        return json.load(f)


def validate_version_folder(version_dir):
    required = [
        "VSCodeSetup-x64.exe",
        "vscode-server-linux-x64.tar.gz",
        "extensions",
        "metadata/metadata.json",
        "metadata/commit.txt",
        "metadata/extensions.json"
    ]

    missing = []
    for item in required:
        if not os.path.exists(os.path.join(version_dir, item)):
            missing.append(item)

    if missing:
        print("ERROR: Missing required files:")
        for m in missing:
            print("  -", m)
        sys.exit(1)


def create_manifest(version, version_dir):
    metadata = load_json(os.path.join(version_dir, "metadata", "metadata.json"))
    extensions = load_json(os.path.join(version_dir, "metadata", "extensions.json"))
    commit_id = open(os.path.join(version_dir, "metadata", "commit.txt")).read().strip()

    manifest = {
        "vscode": {
            "version": version,
            "commit": commit_id,
            "installer": "VSCodeSetup-x64.msi",
            "server_tarball": "vscode-server-linux-x64.tar.gz"
        },
        "extensions": extensions,
        "generated": {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "export_script_version": "1.0"
        }
    }

    manifest_path = os.path.join(version_dir, "manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"Generated manifest: {manifest_path}")
    return manifest_path


def zip_version(version, version_dir):
    zip_name = f"vscode-{version}-export.zip"
    zip_path = os.path.join(BASE_DIR, zip_name)

    print(f"Creating ZIP archive: {zip_path}")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(version_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, BASE_DIR)
                z.write(full_path, rel_path)

    print(f"ZIP complete: {zip_path}")
    return zip_path


def main():
    versions = sorted(os.listdir(VERSIONS_DIR))
    if not versions:
        print("No versions found.")
        sys.exit(1)

    version = versions[-1]
    version_dir = os.path.join(VERSIONS_DIR, version)

    print(f"Exporting version: {version}")
    validate_version_folder(version_dir)

    create_manifest(version, version_dir)
    zip_version(version, version_dir)

    print("\nExport complete.")


if __name__ == "__main__":
    main()
