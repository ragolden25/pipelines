#!/bin/bash

timestamp=$(date +"%Y%m%d-%H%M")
report_dir="/var/lib/containers/trivy/reports"

mkdir -p "$report_dir"

for img in $(docker ps --format '{{.Image}}'); do
    safe_name=$(echo "$img" | tr '/:' '_')
    output="/reports/${safe_name}-sbom-${timestamp}.cdx"

    echo "Generating SBOM for $img..."
    docker run --rm \
      -v /var/lib/containers/trivy/db:/root/.cache/trivy/db \
      -v /var/lib/containers/trivy/reports:/reports \
      aquasec/trivy:latest image --format cyclonedx --output "$output" "$img"
done

echo "SBOM generation complete. Reports saved in $report_dir"
