#!/bin/bash

timestamp=$(date +"%Y%m%d-%H%M")
report_dir="/var/lib/containers/trivy/reports"

mkdir -p "$report_dir"

for img in $(docker ps --format '{{.Image}}'); do
    safe_name=$(echo "$img" | tr '/:' '_')
    output="/reports/${safe_name}-vuln-${timestamp}.json"

    echo "Scanning $img..."
    docker run --rm \
      -v /var/lib/containers/trivy/db:/root/.cache/trivy/db \
      -v /var/lib/containers/trivy/reports:/reports \
      -v /var/run/docker.sock:/var/run/docker.sock \
      aquasec/trivy:latest image --format json --output "$output" "$img"
done

echo "Vulnerability scans complete. Reports saved in $report_dir"
