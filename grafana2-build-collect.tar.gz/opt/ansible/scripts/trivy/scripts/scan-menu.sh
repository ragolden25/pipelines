#!/bin/bash

SCRIPTS_DIR="$(dirname "$0")"

clear
echo "==============================================="
echo "           Trivy Scanning Menu"
echo "==============================================="
echo ""
echo " 1) Run Vulnerability Scan (All Images)"
echo " 2) Run SBOM Scan (All Images)"
echo " 3) Update Trivy DB"
echo " 4) Export Scan Reports"
echo " 5) Import Latest Image + DB"
echo " 6) Exit"
echo ""
read -rp "Select an option: " choice

case "$choice" in
    1)
        "${SCRIPTS_DIR}/scan-all-vuln.sh"
        ;;
    2)
        "${SCRIPTS_DIR}/scan-all-sbom.sh"
        ;;
    3)
        "${SCRIPTS_DIR}/update-db.sh"
        ;;
    4)
        "${SCRIPTS_DIR}/export-reports.sh"
        ;;
    5)
        "${SCRIPTS_DIR}/import-latest.sh"
        ;;
    6)
        echo "Exiting..."
        exit 0
        ;;
    *)
        echo "Invalid option. Please try again."
        ;;
esac
