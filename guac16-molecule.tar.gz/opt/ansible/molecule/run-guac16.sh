#!/bin/bash
# run-guac16.sh deploy|verify [nucleus|ccop] - the guac16 Molecule scenario in two steps, so the
# dashboard can report the deployment and the image checks as separate rows.
#   class nucleus (default) = hardened images + production compose; ccop = functional images +
#   the relaxed docker-compose-ccop.yml.j2
#   deploy  prepare the test artifact folder, then run the whole configure_guacamole role on guac
#   verify  check the deployed stack, then always clean up (scratch folder + Molecule state)
# A failed deploy cleans up too. Logs go to /opt/ansible/molecule/logs/guac16-<class>-<step>-<date>.log
STEP="${1:-}"
case "$STEP" in deploy|verify) ;; *) echo "usage: $0 deploy|verify [nucleus|ccop]"; exit 2 ;; esac
export MOL_IMAGE_CLASS="${2:-nucleus}"
case "$MOL_IMAGE_CLASS" in nucleus|ccop) ;; *) echo "class must be nucleus or ccop"; exit 2 ;; esac

source /opt/ansible/molecule/venv/bin/activate
export XDG_CACHE_HOME=/opt/ansible/molecule/cache
SCR=/opt/ansible/molecule/scratch/guacamole
ROLE=/opt/ansible/nucleus/roles/configure_guacamole
LOG=/opt/ansible/molecule/logs/guac16-$MOL_IMAGE_CLASS-$STEP-$(date +%F-%H%M).log
mkdir -p "$(dirname "$LOG")"

cleanup() {
  rm -rf "$SCR"
  ( cd "$ROLE" && molecule reset -s guac16 >/dev/null 2>&1 )
  true
}

cd "$ROLE" || exit 1
if [ "$STEP" = deploy ]; then
  cleanup                                  # start from nothing left by an earlier run
  trap 'rc=$?; [ $rc -ne 0 ] && cleanup' EXIT
  molecule converge -s guac16 2>&1 | tee "$LOG"
  rc=${PIPESTATUS[0]}
else
  trap cleanup EXIT
  molecule verify -s guac16 2>&1 | tee "$LOG"
  rc=${PIPESTATUS[0]}
fi
echo "log: $LOG (exit $rc)"
exit $rc
