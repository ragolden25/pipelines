#!/bin/bash
# Usage: ./analyze-json.sh file.json

FILE="$1"

if [[ -z "$FILE" ]]; then
    echo "Usage: $0 <json-file>"
    exit 1
fi

echo "=== Top-level keys ==="
jq 'keys' "$FILE"

echo
echo "=== Keys of each top-level object ==="
jq -r '
  to_entries[] |
  "Object: \(.key)\nKeys: \(.value | keys_unsorted)\n"
' "$FILE"

echo
echo "=== Deep structure (recursive keys) ==="
jq -r '
  paths |
  map(tostring) |
  join(".")
' "$FILE" | sort -u

echo
echo "=== Sample of vulnerability fields (if present) ==="
jq -r '
  if .matches then
    .matches[0] | paths | map(tostring) | join(".")
  else
    "No .matches[] found"
  end
' "$FILE"

echo
echo "=== Sample of SBOM artifact fields (if present) ==="
jq -r '
  if .artifacts then
    .artifacts[0] | paths | map(tostring) | join(".")
  else
    "No .artifacts[] found"
  end
' "$FILE"
