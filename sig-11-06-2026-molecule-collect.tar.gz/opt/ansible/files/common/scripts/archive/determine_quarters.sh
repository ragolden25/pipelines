#!/bin/bash

CALENDAR="/opt/ansible/files/common/calendar.env"

# Load the calendar file
if [[ ! -f "$CALENDAR" ]]; then
    echo "quarter=unknown"
    echo "previous_quarter=unknown"
    exit 1
fi

source "$CALENDAR"

TODAY=$(date +%Y-%m-%d)

CURRENT_QUARTER=""
PREVIOUS_QUARTER=""
LAST_QUARTER=""

# Iterate through all FYxxQx entries in chronological order
for VAR in $(grep -oP 'FY\d{2}Q[1-4]_START' "$CALENDAR" | sort); do
    QTR=${VAR%_START}   # e.g., FY26Q3
    START=${!VAR}       # value of FY26Q3_START
    END_VAR="${QTR}_END"
    END=${!END_VAR}     # value of FY26Q3_END

    # Track previous quarter as we iterate
    if [[ -n "$CURRENT_QUARTER" ]]; then
        break
    fi

    # Check if TODAY falls within this quarter
    if [[ "$TODAY" > "$START" && "$TODAY" < "$END" ]] || [[ "$TODAY" == "$START" ]] || [[ "$TODAY" == "$END" ]]; then
        CURRENT_QUARTER=$(echo "$QTR" | tr 'A-Z' 'a-z')   # lowercase
        PREVIOUS_QUARTER=$(echo "$LAST_QUARTER" | tr 'A-Z' 'a-z')
    fi

    LAST_QUARTER="$QTR"
done

# Fallback if TODAY is after last defined quarter
if [[ -z "$CURRENT_QUARTER" ]]; then
    CURRENT_QUARTER=$(echo "$LAST_QUARTER" | tr 'A-Z' 'a-z')
    # previous quarter = second-to-last quarter
    PREVIOUS_QUARTER=$(grep -oP 'FY\d{2}Q[1-4]_START' "$CALENDAR" | sort | tail -2 | head -1 | sed 's/_START//' | tr 'A-Z' 'a-z')
fi

echo "quarter=$CURRENT_QUARTER"
echo "previous_quarter=$PREVIOUS_QUARTER"
