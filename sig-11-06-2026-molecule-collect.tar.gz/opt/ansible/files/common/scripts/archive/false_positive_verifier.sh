#!/usr/bin/env bash
set -euo pipefail

ROOTFS="$1"

echo "=== False Positive Verification Report ==="
echo "Verifying absence of OS-level packages in hardened nucleus image..."
echo

check() {
    NAME="$1"
    shift
    echo "-- $NAME --"
    FOUND=0
    for FILE in "$@"; do
        TARGET="${ROOTFS}${FILE}"
        if [ -e "$TARGET" ]; then
            echo "FOUND:  $FILE"
            FOUND=1
        else
            echo "ABSENT: $FILE"
        fi
    done

    if [ "$FOUND" -eq 0 ]; then
        case "$NAME" in
            util-linux)
                echo "All util-linux binaries are absent — related CVEs are false positives."
                ;;
            systemd)
                echo "All systemd binaries are absent — related CVEs are false positives."
                ;;
            shadow)
                echo "All shadow account-management binaries are absent — related CVEs are false positives."
                ;;
            gzip)
                echo "gzip is not present — gzip CVEs are false positives."
                ;;
            xz)
                echo "xz is not present — xz CVEs are false positives."
                ;;
            *)
                echo "All binaries for $NAME are absent — related CVEs are false positives."
                ;;
        esac
    else
        echo "One or more $NAME binaries are present — related CVEs may be valid."
    fi
    echo
}

check "util-linux" \
    /usr/bin/lsblk \
    /usr/bin/fdisk \
    /usr/bin/mount \
    /usr/bin/umount

check "systemd" \
    /usr/lib/systemd/systemd \
    /bin/systemctl \
    /usr/bin/journalctl

check "shadow" \
    /usr/bin/passwd \
    /usr/bin/chage \
    /usr/sbin/useradd \
    /usr/sbin/usermod

check "gzip" \
    /bin/gzip \
    /usr/bin/gzip

check "xz" \
    /usr/bin/xz \
    /bin/xz

echo "Verification complete — OS-level package CVEs for these groups are false positives when binaries are absent."
