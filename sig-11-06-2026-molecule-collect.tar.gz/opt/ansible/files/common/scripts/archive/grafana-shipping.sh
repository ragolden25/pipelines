#!/usr/bin/env bash

set -euo pipefail

# =====================================================================
# Grafana Shipping Bundle Builder (Flat .xz Artifacts)
# Quarter-aware
# =====================================================================

DATE="$(date +%d%b%Y | tr '[:upper:]' '[:lower:]')"   # e.g., 22aug2026
SHIP_DIR="/opt/ansible/shipping/grafana/${DATE}"

# Detect quarter dynamically
Q_OUT=$( /opt/ansible/files/common/scripts/determine_quarters.sh )
QUARTER=$(echo "$Q_OUT" | grep '^quarter=' | cut -d= -f2)

if [[ -z "${QUARTER}" || "${QUARTER}" == "unknown" ]]; then
    echo "ERROR: Could not determine quarter."
    exit 2
fi

QUARTER_SRC="/opt/ansible/files/grafana/${QUARTER}"
IMG_SRC="${QUARTER_SRC}/images"
ROLE_ROOT="/opt/ansible/nucleus/roles"
SCRIPT_ROOT="/opt/ansible/scripts"

mkdir -p "${SHIP_DIR}"

INVENTORY="${SHIP_DIR}/inventory.txt"
echo "Inventory of Grafana file transfers on ${DATE}" > "${INVENTORY}"
echo "" >> "${INVENTORY}"

add_inventory() {
    local file="$1"
    local src="$2"
    local dest="$3"
    local size
    size=$(du -h "${file}" | awk '{print $1}')

    echo "${file##*/} (${size})" >> "${INVENTORY}"
    echo "  source: ${src}" >> "${INVENTORY}"
    echo "  dest:   ${dest}" >> "${INVENTORY}"
    echo "" >> "${INVENTORY}"
}

# =====================================================================
# 1. Compress Grafana role → configure_grafana.tar.xz
# =====================================================================

G_ROLE="configure_grafana_stack"
G_SRC="${ROLE_ROOT}/${G_ROLE}"
G_OUT="${SHIP_DIR}/${G_ROLE}.tar.xz"

echo "==> Compressing role: ${G_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${G_ROLE}" | xz -T0 -9e > "${G_OUT}"

add_inventory "${G_OUT}" "${G_SRC}" "${ROLE_ROOT}"

# =====================================================================
# 2. Compress install_docker_python role → .tar.xz
# =====================================================================

IDP_ROLE="install_docker_python"
IDP_SRC="${ROLE_ROOT}/${IDP_ROLE}"
IDP_OUT="${SHIP_DIR}/${IDP_ROLE}.tar.xz"

echo "==> Compressing role: ${IDP_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${IDP_ROLE}" | xz -T0 -9e > "${IDP_OUT}"

add_inventory "${IDP_OUT}" "${IDP_SRC}" "${ROLE_ROOT}"

# =====================================================================
# 3. Ship Grafana images (large image handled separately)
# =====================================================================

echo "==> Shipping Grafana images"

# Large Grafana image (handled separately)
LARGE_GRAFANA_IMG=$(ls "${IMG_SRC}"/nucleus-grafana-*.tar.gz 2>/dev/null || true)

if [[ -n "${LARGE_GRAFANA_IMG}" ]]; then
    GRAFANA_OUT="${SHIP_DIR}/grafana-image.tar.gz.xz"
    echo "==> Compressing large Grafana image separately"
    xz -T0 -9e -c "${LARGE_GRAFANA_IMG}" > "${GRAFANA_OUT}"
    add_inventory "${GRAFANA_OUT}" "${LARGE_GRAFANA_IMG}" "${IMG_SRC}"
fi

# Other images (grouped)
echo "==> Grouping remaining Grafana images"
G_OTHER_TAR="${SHIP_DIR}/grafana-other-images.tar"

tar -C "${IMG_SRC}" -cf "${G_OTHER_TAR}" \
    $(ls "${IMG_SRC}"/*.tar.gz | grep -v "grafana-" || true)

echo "==> Compressing grafana-other-images.tar"
xz -T0 -9e "${G_OTHER_TAR}"

add_inventory "${G_OTHER_TAR}.xz" "${IMG_SRC}/*.tar.gz (non-grafana)" "${IMG_SRC}"

# =====================================================================
# 4. Optional: include cis_docker.zip
# =====================================================================

CIS_ZIP="${SCRIPT_ROOT}/cis_docker.zip"
if [[ -f "${CIS_ZIP}" ]]; then
    echo "==> Including cis_docker.zip"
    cp "${CIS_ZIP}" "${SHIP_DIR}/cis_docker.zip"
    add_inventory "${SHIP_DIR}/cis_docker.zip" "${CIS_ZIP}" "${SCRIPT_ROOT}"
fi

# =====================================================================
# 5. Compress quarter directory (excluding images)
# =====================================================================

QUARTER_OUT="${SHIP_DIR}/${QUARTER}.tar.xz"

echo "==> Creating quarter bundle (excluding images)"
tar -C "${QUARTER_SRC}" --exclude="images" -cf - . | xz -T0 -9e > "${QUARTER_OUT}"

add_inventory "${QUARTER_OUT}" "${QUARTER_SRC}" "/opt/ansible/files/grafana"

# =====================================================================
# Summary
# =====================================================================

echo ""
echo "=============================================================="
echo "Grafana shipping bundle created:"
echo "  ${SHIP_DIR}"
echo ""
echo "Files included:"
ls -lh "${SHIP_DIR}"
echo ""
echo "Inventory written to:"
echo "  ${INVENTORY}"
echo "=============================================================="
