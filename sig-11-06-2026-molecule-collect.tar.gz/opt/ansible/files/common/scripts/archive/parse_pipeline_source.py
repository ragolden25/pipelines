#!/usr/bin/env python3
import os
import re
import sys
import yaml
from graphviz import Digraph

# Central repository path where your Ansible roles reside
ROLES_DIR = "/opt/ansible/nucleus/roles"

# Global setup for our flowchart output
dot = Digraph(name="Pipeline_Map", comment="Automated Code Architecture Map", format="png")
dot.attr(rankdir="TB") # Top-to-Bottom flow hierarchy
dot.attr(compound="true")

# Global style rules
dot.attr(
    'node',
    fontname='Helvetica',
    fontsize='11',
    shape='box',
    style='filled',
    fillcolor='#F3F4F6',
    color='#9CA3AF'
)
dot.attr('edge', fontname='Helvetica', fontsize='9', color='#4B5563', arrowhead='vee')


def parse_shell_script(script_path, parent_node_id, cluster_id):
    """Crawls a physical bash/shell script to grab internal custom # STEP lines."""
    if not os.path.exists(script_path):
        return

    steps = []
    with open(script_path, "r", errors='ignore') as f:
        for line in f:
            match = re.search(r"#\s*STEP:\s*(.+)", line)
            if match:
                steps.append(match.group(1).strip())

    if not steps:
        return

    # Draw the internal steps inside a dedicated sub-graph box
    prev_step_id = None
    for idx, step in enumerate(steps):
        step_node_id = f"step_{cluster_id}_{idx}"
        dot.node(
            step_node_id,
            label=f"Step {idx+1}: {step}",
            fillcolor="#D1FAE5",
            color="#10B981"
        ) # Green nodes

        # Link parent task node to the first internal execution step
        if idx == 0:
            dot.edge(parent_node_id, step_node_id, color="#059669", style="dashed", label="executes")

        if prev_step_id:
            dot.edge(prev_step_id, step_node_id, color="#10B981")
        prev_step_id = step_node_id


def resolve_role_tasks(role_name):
    """Locates the main.yml task entry point for a role inside ROLES_DIR."""
    possible_paths = [
        os.path.join(ROLES_DIR, role_name, "tasks", "main.yml"),
        os.path.join(ROLES_DIR, role_name, "tasks", "main.yaml")
    ]
    for path in possible_paths:
        if os.path.exists(path):
            return path
    return None


def process_ansible_tasks(tasks, base_dir, role_name="Main"):
    """Recursively processes YAML lists of Ansible tasks."""
    if not isinstance(tasks, list):
        return

    prev_task_id = None
    for idx, task in enumerate(tasks):
        if not isinstance(task, dict) or not task:
            continue

        # Extract standard task metadata
        task_name = task.get("name", f"Unnamed Task [{idx}]")

        # FIX FOR PYTHON < 3.12: Pre-sanitize strings outside the f-string curly braces
        clean_role_name = re.sub(r'\W+', '_', str(role_name))
        clean_task_name = re.sub(r'\W+', '_', str(task_name))
        task_id = f"task_{clean_role_name}_{clean_task_name}"

        # 1. Handle include_tasks / import_tasks
        if "include_tasks" in task or "import_tasks" in task:
            dot.node(task_id, label=f"Include: {task_name}", fillcolor="#DBEAFE", color="#3B82F6") # Blue node

            nested_file = task.get("include_tasks") or task.get("import_tasks")
            nested_path = os.path.join(base_dir, nested_file)
            if os.path.exists(nested_path):
                with open(nested_path, "r") as f:
                    try:
                        nested_tasks = yaml.safe_load(f)
                        process_ansible_tasks(nested_tasks, base_dir, role_name=task_name)
                    except yaml.YAMLError:
                        pass

        # 2. Handle include_role / import_role
        elif "include_role" in task or "import_role" in task:
            role_dict = task.get("include_role") or task.get("import_role")
            target_role = role_dict.get("name") if isinstance(role_dict, dict) else role_dict

            dot.node(task_id, label=f"Role: {target_role}", fillcolor="#FEF08A", color="#EAB308") # Yellow node

            role_file = resolve_role_tasks(target_role)
            if role_file:
                role_base_dir = os.path.dirname(role_file)
                with open(role_file, "r") as f:
                    try:
                        role_tasks = yaml.safe_load(f)
                        process_ansible_tasks(role_tasks, role_base_dir, role_name=target_role)
                    except yaml.YAMLError:
                        pass

        else:
            dot.node(task_id, label=task_name, fillcolor="#FFFFFF") # Plain white task blocks

        # Connect successive Ansible execution steps
        if prev_task_id:
            dot.edge(prev_task_id, task_id)
        prev_task_id = task_id

        # Scan task dictionary fields for command/shell execution paths
        for module in ["shell", "command", "ansible.builtin.shell", "ansible.builtin.command"]:
            if module in task:
                module_content = task[module]
                cmd_string = ""

                if isinstance(module_content, dict):
                    cmd_string = module_content.get("cmd", "")
                elif isinstance(module_content, str):
                    cmd_string = module_content

                script_match = re.search(r"([\w\-/.]+\.(?:sh|py))", cmd_string)
                if script_match:
                    raw_script_path = script_match.group(1)
                    resolved_script = (
                        raw_script_path
                        if raw_script_path.startswith("/")
                        else os.path.join(base_dir, raw_script_path)
                    )
                    parse_shell_script(resolved_script, task_id, task_id)


if __name__ == "__main__":
    playbook_path = "/opt/ansible/nucleus/playbooks/build_grafana_stack.yml"
    target_dir = os.path.dirname(playbook_path)

    if not os.path.exists(playbook_path):
        print(f"Error: Target file '{playbook_path}' cannot be found.")
        sys.exit(1)

    print(f"Parsing deployment source structure: {playbook_path}")
    with open(playbook_path, "r") as f:
        try:
            playbook_data = yaml.safe_load(f)

            if isinstance(playbook_data, list):
                for play in playbook_data:
                    if not isinstance(play, dict):
                        continue

                    # Process standard tasks within a play
                    if "tasks" in play:
                        process_ansible_tasks(play["tasks"], target_dir)

                    # Process play-level roles list (e.g., roles: [ role1, role2 ])
                    if "roles" in play:
                        for role in play["roles"]:
                            r_name = role.get("role", role) if isinstance(role, dict) else role
                            r_file = resolve_role_tasks(r_name)
                            if r_file:
                                r_dir = os.path.dirname(r_file)
                                with open(r_file, "r") as rf:
                                    r_tasks = yaml.safe_load(rf)
                                    process_ansible_tasks(r_tasks, r_dir, role_name=r_name)

        except yaml.YAMLError as err:
            print(f"CRITICAL Error parsing YAML structure: {err}")
            sys.exit(1)

    output_render_path = "/opt/ansible/files/common/automated_pipeline_architecture"
    dot.render(output_render_path, cleanup=True)
    print(
        f"Pipeline flow schema successfully mapped directly to source definitions at:\n{output_render_path}.png"
    )
