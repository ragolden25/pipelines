#!/bin/bash
set -euo pipefail

# Fix restrictive umask (077) that breaks Grype/Syft output
umask 022

# Arguments
IMAGE=""
OUTPUT_DIR=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --image)
            IMAGE="$2"
            shift 2
            ;;
        --output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1"
            exit 1
            ;;
    esac
done

if [[ -z "$IMAGE" || -z "$OUTPUT_DIR" ]]; then
    echo "Usage: sbom_generate_and_scan.sh --image <image> --output <dir>"
    exit 1
fi

# Timestamp prefix
TS=$(date -u +"%Y%m%dT%H%M%SZ")
PREFIX="$(echo "$IMAGE" | sed 's|/|-|g')-ansible.nuc2.scires.com-${TS}"

echo "==> Using image: $IMAGE"
echo "==> Output directory: $OUTPUT_DIR"
echo "==> Prefix: $PREFIX"

mkdir -p "$OUTPUT_DIR"

# Pull Syft + Grype
echo "==> Pulling Syft and Grype"
docker pull anchore/syft:latest
docker pull anchore/grype:latest

# SBOM output
SBOM_JSON="${OUTPUT_DIR}/${PREFIX}.sbom.json"

# Vulnerability outputs
VULN_JSON="${OUTPUT_DIR}/${PREFIX}.vuln.json"
VULN_CSV="${OUTPUT_DIR}/${PREFIX}.vuln.csv"
NORMALIZED="${OUTPUT_DIR}/${PREFIX}.vuln.normalized.csv"

echo "==> Generating SBOM with Syft"
docker run --rm \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v "$OUTPUT_DIR":"$OUTPUT_DIR" \
    anchore/syft:latest "$IMAGE" -o json > "$SBOM_JSON"

sync

echo "==> Running Grype vulnerability scan (JSON)"
docker run --rm \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v "$OUTPUT_DIR":"$OUTPUT_DIR" \
    anchore/grype:latest "$IMAGE" -o json > "$VULN_JSON"

sync

echo "==> Converting Grype JSON → CSV (.matches[] schema)"
jq -r '
  .matches[]? |
  [
    .vulnerability.id,
    .vulnerability.severity,
    .artifact.name,
    .artifact.version,
    (.vulnerability.fix.state // "none"),
    (.vulnerability.fix.versions // [] | join(";"))
  ] | @csv
' "$VULN_JSON" > "$VULN_CSV"

echo "==> Normalizing vuln CSV for IA"
/opt/ansible/files/common/scripts/normalize_vuln_csv.sh "$VULN_CSV"

echo "==> SBOM + vulnerability scan complete"
echo "==> SBOM: $SBOM_JSON"
echo "==> Vuln JSON: $VULN_JSON"
echo "==> Vuln CSV: $VULN_CSV"
echo "==> Normalized CSV: $NORMALIZED"
