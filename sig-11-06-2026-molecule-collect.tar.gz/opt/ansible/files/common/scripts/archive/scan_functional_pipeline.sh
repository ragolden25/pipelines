#!/usr/bin/env bash
set -euo pipefail

# ================================================================
# Functional Image Scan Pipeline
# Startup → API → Config Validation
# Deterministic, explicit, debuggable
# ================================================================

# -------------------------------
# Parse arguments
# -------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --name) IMAGE_NAME="$2"; shift 2 ;;
        --version) IMAGE_VERSION="$2"; shift 2 ;;
        --quarter) QUARTER="$2"; shift 2 ;;
        --output) OUTPUT_BASE="$2"; shift 2 ;;
        --timestamp) SCAN_TIMESTAMP="$2"; shift 2 ;;
        *)
            echo "Unknown argument: $1"
            exit 99
            ;;
    esac
done

# -------------------------------
# Derived values
# -------------------------------
SAFE_NAME="nucleus-${IMAGE_NAME}_$(echo "${IMAGE_VERSION}" | sed 's/[:.]/_/g')"
IMAGE_REF="nucleus/${IMAGE_NAME}:${IMAGE_VERSION}"
OUTPUT_DIR="${OUTPUT_BASE}/${QUARTER}/provenance/functional"

mkdir -p "${OUTPUT_DIR}"

echo "=== Functional Scan Pipeline ==="
echo "Image: ${IMAGE_REF}"
echo "Safe Name: ${SAFE_NAME}"
echo "Quarter: ${QUARTER}"
echo "Output Dir: ${OUTPUT_DIR}"
echo "Timestamp: ${SCAN_TIMESTAMP}"
echo

# -------------------------------
# Step 1: Startup Test
# -------------------------------
echo "[1/3] Startup Functional Test"
STARTUP_SCRIPT="/opt/ansible/files/common/scripts/functional_startup_test.sh"

if ! "${STARTUP_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --timestamp "${SCAN_TIMESTAMP}"; then
    echo "ERROR: Startup functional test failed for ${IMAGE_REF}"
    exit 10
fi

echo "Startup test complete."
echo

# -------------------------------
# Step 2: API Test
# -------------------------------
echo "[2/3] API Functional Test"
API_SCRIPT="/opt/ansible/files/common/scripts/functional_api_test.sh"

if ! "${API_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --safe-name "${SAFE_NAME}" \
        --timestamp "${SCAN_TIMESTAMP}"; then
    echo "ERROR: API functional test failed for ${IMAGE_REF}"
    exit 20
fi

echo "API test complete."
echo

# -------------------------------
# Step 3: Config Validation
# -------------------------------
echo "[3/3] Configuration Validation"
CONFIG_SCRIPT="/opt/ansible/files/common/scripts/functional_config_validate.sh"

if ! "${CONFIG_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --timestamp "${SCAN_TIMESTAMP}"; then
    echo "ERROR: Configuration validation failed for ${IMAGE_REF}"
    exit 30
fi

echo "Configuration validation complete."
echo

echo "=== Functional Scan Pipeline Finished Successfully ==="
exit 0
