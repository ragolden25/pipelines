#!/usr/bin/env bash
set -euo pipefail

# ================================================================
# Hardened Image Scan Pipeline
# SBOM → Normalize → OpenSCAP
# Deterministic, explicit, debuggable
# ================================================================

# -------------------------------
# Parse arguments
# -------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --name) IMAGE_NAME="$2"; shift 2 ;;
        --version) IMAGE_VERSION="$2"; shift 2 ;;
        --quarter) QUARTER="$2"; shift 2 ;;
        --output) OUTPUT_BASE="$2"; shift 2 ;;
        --timestamp) SCAN_TIMESTAMP="$2"; shift 2 ;;
        *)
            echo "Unknown argument: $1"
            exit 99
            ;;
    esac
done

# -------------------------------
# Derived values
# -------------------------------
SAFE_NAME="nucleus-${IMAGE_NAME}_$(echo "${IMAGE_VERSION}" | sed 's/[:.]/_/g')"
IMAGE_REF="nucleus/${IMAGE_NAME}:${IMAGE_VERSION}"
OUTPUT_DIR="${OUTPUT_BASE}/${QUARTER}/provenance/nucleus"

mkdir -p "${OUTPUT_DIR}"

echo "=== Hardened Scan Pipeline ==="
echo "Image: ${IMAGE_REF}"
echo "Safe Name: ${SAFE_NAME}"
echo "Quarter: ${QUARTER}"
echo "Output Dir: ${OUTPUT_DIR}"
echo "Timestamp: ${SCAN_TIMESTAMP}"
echo

# -------------------------------
# Step 1: SBOM + Grype Scan
# -------------------------------
echo "[1/3] SBOM + Grype Scan"
SBOM_SCRIPT="/opt/ansible/files/common/scripts/sbom_generate_and_scan.sh"

if ! "${SBOM_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --timestamp "${SCAN_TIMESTAMP}"; then
    echo "ERROR: SBOM scan failed for ${IMAGE_REF}"
    exit 10
fi

echo "SBOM scan complete."
echo

# -------------------------------
# Step 2: SBOM Normalize
# -------------------------------
echo "[2/3] SBOM Normalize"
NORMALIZE_SCRIPT="/opt/ansible/files/common/scripts/sbom_normalize.sh"

if ! "${NORMALIZE_SCRIPT}" \
        --input "${OUTPUT_DIR}" \
        --safe-name "${SAFE_NAME}"; then
    echo "ERROR: SBOM normalization failed for ${SAFE_NAME}"
    exit 20
fi

echo "Normalization complete."
echo

# -------------------------------
# Step 3: OpenSCAP Scan
# -------------------------------
echo "[3/3] OpenSCAP Scan"
OPENSCAP_SCRIPT="/opt/ansible/files/common/scripts/openscap_scan.sh"

if ! "${OPENSCAP_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --timestamp "${SCAN_TIMESTAMP}"; then
    echo "ERROR: OpenSCAP scan failed for ${IMAGE_REF}"
    exit 30
fi

echo "OpenSCAP scan complete."
echo

echo "=== Hardened Scan Pipeline Finished Successfully ==="
exit 0
