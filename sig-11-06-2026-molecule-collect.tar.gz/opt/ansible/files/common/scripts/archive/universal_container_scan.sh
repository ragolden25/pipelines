#!/usr/bin/env bash

set -euo pipefail

# ================================================================
# Universal Container Scan Pipeline
# SBOM → Normalize → OpenSCAP
# Works for ANY container image
# ================================================================

# ---------------------------------------------------------------
# Argument Parser
# ---------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --image) IMAGE_NAME="$2"; shift 2 ;;
        --version) IMAGE_VERSION="$2"; shift 2 ;;
        --safe-name) SAFE_NAME="$2"; shift 2 ;;
        --output) OUTPUT_BASE="$2"; shift 2 ;;
        --timestamp) TS="$2"; shift 2 ;;
        --quarter) QUARTER="$2"; shift 2 ;;
        *)
            echo "Unknown argument: $1"
            exit 99
            ;;
    esac
done

IMAGE_REF="${IMAGE_NAME}:${IMAGE_VERSION}"

# ---------------------------------------------------------------
# Quarter Auto-Detection (fallback if --quarter not provided)
# ---------------------------------------------------------------
if [[ -z "${QUARTER:-}" ]]; then
    Q_OUT=$( /opt/ansible/files/common/scripts/determine_quarters.sh )
    QUARTER=$(echo "$Q_OUT" | grep '^quarter=' | cut -d= -f2)

    if [[ -z "${QUARTER}" || "${QUARTER}" == "unknown" ]]; then
        echo "ERROR: QUARTER could not be determined automatically."
        exit 2
    fi
fi

echo "Using quarter: ${QUARTER}"

# ---------------------------------------------------------------
# Determine final output directory based on image namespace
# ---------------------------------------------------------------
if [[ "${IMAGE_NAME}" == ccop/* ]]; then
    OUTPUT_DIR="${OUTPUT_BASE}/${QUARTER}/provenance/ccop"
else
    OUTPUT_DIR="${OUTPUT_BASE}/${QUARTER}/provenance/nucleus"
fi

mkdir -p "${OUTPUT_DIR}"

LOG="${OUTPUT_DIR}/scan_${SAFE_NAME}_${TS}.log"

echo "=== Universal Container Scan Pipeline ===" | tee "${LOG}"
echo "Image: ${IMAGE_REF}" | tee -a "${LOG}"
echo "Safe Name: ${SAFE_NAME}" | tee -a "${LOG}"
echo "Timestamp: ${TS}" | tee -a "${LOG}"
echo "Output Dir: ${OUTPUT_DIR}" | tee -a "${LOG}"
echo | tee -a "${LOG}"

# ---------------------------------------------------------------
# Step 1: SBOM + Vulnerability Scan
# ---------------------------------------------------------------
echo "[1/3] SBOM + Vulnerability Scan" | tee -a "${LOG}"

SBOM_SCRIPT="/opt/ansible/files/common/scripts/sbom_generate_and_scan.sh"

if ! "${SBOM_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --timestamp "${TS}" >> "${LOG}" 2>&1; then
    echo "ERROR: SBOM scan failed for ${IMAGE_REF}" | tee -a "${LOG}"
    exit 10
fi

echo "SBOM scan complete." | tee -a "${LOG}"
echo | tee -a "${LOG}"

# ---------------------------------------------------------------
# Step 2: Normalize Vulnerability CSV
# ---------------------------------------------------------------
echo "[2/3] Normalize Vulnerability CSV" | tee -a "${LOG}"

NORMALIZE_SCRIPT="/opt/ansible/files/common/scripts/normalize_vuln_csv.sh"

# *** FIXED: include timestamp in vuln CSV filename ***
CSV_FILE="${OUTPUT_DIR}/${SAFE_NAME}_${TS}.vuln.csv"

if ! "${NORMALIZE_SCRIPT}" "${CSV_FILE}" >> "${LOG}" 2>&1; then
    echo "ERROR: Vulnerability CSV normalization failed for ${SAFE_NAME}" | tee -a "${LOG}"
    exit 20
fi

echo "Normalization complete." | tee -a "${LOG}"
echo | tee -a "${LOG}"

# ---------------------------------------------------------------
# Step 3: OpenSCAP Scan
# ---------------------------------------------------------------

# *** NEW: Skip OpenSCAP for minimal base images ***
if [[ "${IMAGE_NAME}" == "container-forge/debian13-slim" ]]; then
    echo "Skipping OpenSCAP for base image: ${IMAGE_NAME}" | tee -a "${LOG}"
    exit 0
fi

echo "[3/3] OpenSCAP Scan" | tee -a "${LOG}"

OPENSCAP_SCRIPT="/opt/ansible/files/common/scripts/openscap_container_scan.sh"

if ! "${OPENSCAP_SCRIPT}" \
        --image "${IMAGE_REF}" \
        --output "${OUTPUT_DIR}" \
        --timestamp "${TS}" >> "${LOG}" 2>&1; then
    echo "ERROR: OpenSCAP scan failed for ${IMAGE_REF}" | tee -a "${LOG}"
    exit 30
fi

echo "OpenSCAP scan complete." | tee -a "${LOG}"
echo | tee -a "${LOG}"

echo "=== Universal Container Scan Pipeline Finished Successfully ===" | tee -a "${LOG}"
exit 0
