#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Avocado Shipping Bundle Builder (Flat .tar.xz Artifacts)
# Quarter-aware, signature-safe for Docker images
# =====================================================================

DATE="$(date +%d%b%Y | tr '[:upper:]' '[:lower:]')"   # e.g., 22jul2026
SHIP_DIR="/opt/ansible/shipping/avocado/${DATE}"

# Detect quarter dynamically
Q_OUT=$(/opt/ansible/files/common/scripts/determine_quarters.sh)
QUARTER=$(echo "$Q_OUT" | grep '^quarter=' | cut -d= -f2)

if [[ -z "${QUARTER}" || "${QUARTER}" == "unknown" ]]; then
  echo "ERROR: Could not determine quarter."
  exit 2
fi

QUARTER_SRC="/opt/ansible/files/avocado/${QUARTER}"
IMG_SRC="${QUARTER_SRC}/images"
ROLE_ROOT="/opt/ansible/nucleus/roles"
SCRIPT_ROOT="/opt/ansible/scripts"

mkdir -p "${SHIP_DIR}"

INVENTORY="${SHIP_DIR}/inventory.txt"
echo "Inventory of file transfers on ${DATE}" > "${INVENTORY}"
echo "" >> "${INVENTORY}"

add_inventory() {
  local file="$1"
  local src="$2"
  local dest="$3"
  local size
  size=$(du -h "${file}" | awk '{print $1}')
  echo "${file##*/} (${size})" >> "${INVENTORY}"
  echo "  source: ${src}" >> "${INVENTORY}"
  echo "  dest:   ${dest}" >> "${INVENTORY}"
  echo "" >> "${INVENTORY}"
}

# =====================================================================
# 1. Nucleus images → one directory, tar, xz PER IMAGE
#    (matches grafana-shipping.sh's per-image convention; no grouping)
# =====================================================================

echo "==> Packaging nucleus images (one dir → tar → xz per image)"

for img in "${IMG_SRC}"/nucleus-*.tar.gz; do
  [[ -e "${img}" ]] || continue

  base="${img##*/}"          # e.g. nucleus-foo.tar.gz
  name="${base%.tar.gz}"     # e.g. nucleus-foo

  work_dir="${SHIP_DIR}/images-work/${name}"
  mkdir -p "${work_dir}"
  cp "${img}" "${work_dir}/"

  out="${SHIP_DIR}/${name}.tar.xz"
  tar -C "${SHIP_DIR}/images-work" -cf - "${name}" | xz -T0 -9e > "${out}"
  add_inventory "${out}" "${img}" "${IMG_SRC}"

  rm -rf "${work_dir}"
done

# =====================================================================
# 2. Ccop images → one directory, tar, xz PER IMAGE
#    (matches grafana-shipping.sh's per-image convention; no grouping)
# =====================================================================

echo "==> Packaging ccop images (one dir → tar → xz per image)"

for img in "${IMG_SRC}"/ccop-*.tar.gz; do
  [[ -e "${img}" ]] || continue

  base="${img##*/}"
  name="${base%.tar.gz}"

  work_dir="${SHIP_DIR}/images-work/${name}"
  mkdir -p "${work_dir}"
  cp "${img}" "${work_dir}/"

  out="${SHIP_DIR}/${name}.tar.xz"
  tar -C "${SHIP_DIR}/images-work" -cf - "${name}" | xz -T0 -9e > "${out}"
  add_inventory "${out}" "${img}" "${IMG_SRC}"

  rm -rf "${work_dir}"
done

# =====================================================================
# 3. Wrap debian13-base-latest.tar.gz → debian13-base-latest.tar.xz
#    (dir → tar → xz, gzip untouched)
# =====================================================================

DEBIAN_SRC="${IMG_SRC}/debian13-base-latest.tar.gz"

if [[ -f "${DEBIAN_SRC}" ]]; then
  echo "==> Preparing debian13-base-latest directory (dir → tar → xz)"
  DEBIAN_WORK_DIR="${SHIP_DIR}/images-work/debian13-base-latest"
  mkdir -p "${DEBIAN_WORK_DIR}"
  cp "${DEBIAN_SRC}" "${DEBIAN_WORK_DIR}/"

  DEBIAN_TAR="${SHIP_DIR}/debian13-base-latest.tar"
  tar -C "${DEBIAN_WORK_DIR}" -cf "${DEBIAN_TAR}" .
  xz -T0 -9e "${DEBIAN_TAR}"

  add_inventory "${DEBIAN_TAR}.xz" "${DEBIAN_SRC}" "${IMG_SRC}"
fi

# Clean up image work dirs
rm -rf "${SHIP_DIR}/images-work"

# =====================================================================
# 4. Compress configure_guacamole role → configure_guacamole.tar.xz
# =====================================================================

CFG_ROLE="configure_guacamole"
CFG_SRC="${ROLE_ROOT}/${CFG_ROLE}"
CFG_OUT="${SHIP_DIR}/${CFG_ROLE}.tar.xz"

echo "==> Compressing role: ${CFG_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${CFG_ROLE}" | xz -T0 -9e > "${CFG_OUT}"
add_inventory "${CFG_OUT}" "${CFG_SRC}" "${ROLE_ROOT}"

# =====================================================================
# 5. Compress install_docker_python role → install_docker_python.tar.xz
# =====================================================================

IDP_ROLE="install_docker_python"
IDP_SRC="${ROLE_ROOT}/${IDP_ROLE}"
IDP_OUT="${SHIP_DIR}/${IDP_ROLE}.tar.xz"

echo "==> Compressing role: ${IDP_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${IDP_ROLE}" | xz -T0 -9e > "${IDP_OUT}"
add_inventory "${IDP_OUT}" "${IDP_SRC}" "${ROLE_ROOT}"

# =====================================================================
# 6. Scan install_docker_python for external referenced directories
# =====================================================================

scan_install_docker_python_files() {
  local role="install_docker_python"
  local role_dir="${ROLE_ROOT}/${role}"
  local out_dir="${SHIP_DIR}"

  echo "==> Scanning install_docker_python for external referenced directories"

  mapfile -t refs < <(
    grep -RhoE 'src: *[^ ]+|template: *[^ ]+|/opt/ansible/files/[^ ]+' \
      "${role_dir}/tasks" 2>/dev/null \
    | sed -E 's/.*src: *//; s/.*template: *//'
  )

  declare -A dirs_to_ship=()

  for ref in "${refs[@]}"; do
    local f
    if [[ "${ref}" == /* ]]; then
      f="${ref}"
    else
      f="${role_dir}/${ref}"
    fi

    if [[ "${f}" == "${role_dir}"/* ]]; then
      continue
    fi

    if [[ -f "${f}" ]]; then
      local parent
      parent="$(dirname "${f}")"
      dirs_to_ship["${parent}"]=1
    fi
  done

  for d in "${!dirs_to_ship[@]}"; do
    local base
    base="$(basename "${d}")"
    local out="${out_dir}/${role}-${base}.tar.xz"

    echo "==> Shipping external directory: ${d}"
    tar -C "$(dirname "${d}")" -cf - "${base}" | xz -T0 -9e > "${out}"
    add_inventory "${out}" "${d}" "/opt/ansible/files"
  done
}

scan_install_docker_python_files

# =====================================================================
# 7. Optional: include cis_docker.zip
# =====================================================================

CIS_ZIP="${SCRIPT_ROOT}/cis_docker.zip"
if [[ -f "${CIS_ZIP}" ]]; then
  echo "==> Including cis_docker.zip"
  cp "${CIS_ZIP}" "${SHIP_DIR}/cis_docker.zip"
  add_inventory "${SHIP_DIR}/cis_docker.zip" "${CIS_ZIP}" "${SCRIPT_ROOT}"
fi

# =====================================================================
# 8. Compress quarter directory (excluding images and stray files)
#    (safely including root directory name, matching grafana-shipping.sh)
# =====================================================================

QUARTER_OUT="${SHIP_DIR}/${QUARTER}.tar.xz"

echo "==> Creating quarter bundle: ${QUARTER}.tar.xz"

# -C changes to the parent folder, targets the quarter folder name
# directly -- enforces the "<quarter>/" top-level directory on extract,
# matching grafana-shipping.sh's convention. Also excludes previous
# runs, images (shipped separately above), and backup files left by
# jq/sed.
tar -C "/opt/ansible/files/avocado" \
  --exclude="${QUARTER}/images" \
  --exclude="*.tar.xz" \
  --exclude="*.orig" \
  --exclude="*.old" \
  --exclude="*.tmp" \
  -cf - "${QUARTER}" | xz -T0 -9e > "${QUARTER_OUT}"

add_inventory "${QUARTER_OUT}" "${QUARTER_SRC}" "/opt/ansible/files/avocado"

# =====================================================================
# Summary
# =====================================================================

echo ""
echo "=============================================================="
echo "Shipping bundle created:"
echo "  ${SHIP_DIR}"
echo ""
echo "Files included:"
ls -lh "${SHIP_DIR}"
echo ""
echo "Inventory written to:"
echo "  ${INVENTORY}"
echo "=============================================================="
