#!/usr/bin/env bash
set -euo pipefail

LOGFILE="$1"
shift

{
    echo "COMMAND: $*"
    echo "START: $(date -Iseconds)"
    "$@"
    STATUS=$?
    echo "END: $(date -Iseconds)"
    echo "EXIT_CODE: $STATUS"
} &> "$LOGFILE"

exit $STATUS
