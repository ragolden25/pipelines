#!/usr/bin/env bash

# Clear the screen for a pristine view of the schemas
clear

echo "=============================================================="
echo "          GRAFANA /APIS DEFINITIVE DISCOVERY SUITE            "
echo "=============================================================="
echo ""

VAULT_FILE="/home/ansible/vault_pass.txt"
ADMIN_PWD=""

# 1. Dynamically read the password from the local vault file
if [[ -f "$VAULT_FILE" ]]; then
    ADMIN_PWD=$(cat "$VAULT_FILE")
fi

# Fallback check if the vault file doesn't exist or is empty
if [[ -z "$ADMIN_PWD" ]]; then
    echo "⚠️  Could not read /home/ansible/vault_pass.txt"
    read -rsp "Enter the master admin password manually: " ADMIN_PWD
    echo ""
fi

# Define the unified App Platform API groups to expose
declare -A APIS_GROUPS
APIS_GROUPS=(
    ["Dashboards"]="dashboard.grafana.app/v1"
    ["Datasources"]="datasource.grafana.app/v1"
    ["Alert Rules"]="alerting.grafana.app/v1"
    ["Folders"]="folder.grafana.app/v1"
    ["Receivers/Contact Points"]="notifications.alerting.grafana.app/v1beta1"
)

echo "=============================================================="
echo "==> MAPPING ROOT /APIS INDEX GROUP NAMESPACES"
echo "=============================================================="
curl -s -k -u "admin:${ADMIN_PWD}" http://localhost:3000/apis
echo ""
echo ""

# Loop through each group and dump the raw structural capabilities definition
for service in "${!APIS_GROUPS[@]}"; do
    path="${APIS_GROUPS[$service]}"
    echo "=============================================================="
    echo "==> RAW SCHEMA CAPACITY DEFINITIONS FOR: ${service^^}"
    echo "    Endpoint: http://localhost:3000/apis/${path}"
    echo "=============================================================="
    
    curl -s -k -f -u "admin:${ADMIN_PWD}" "http://localhost:3000/apis/${path}"
    
    echo ""
    echo ""
done

echo "=============================================================="
echo "                      END OF SCHEMAS                          "
echo "=============================================================="
