#!/usr/bin/env bash
#
# compensating_control_verifier.sh
#
# Formerly false_positive_verifier.sh. Renamed because "false positive" is
# the wrong term for what this script checks: the packages below ARE
# genuinely present in the SBOM/dpkg metadata at the flagged version, and
# Grype is correctly reading that. What this script verifies is a
# RISK-ACCEPTANCE-VIA-COMPENSATING-CONTROL disposition instead: the specific
# binaries and shared libraries that provide the exploitable code path for
# each package group have been deliberately deleted from the shipped rootfs
# (see the corresponding Dockerfile's hardening-sweep RUN step), so the
# vulnerable code is not reachable even though the package's version metadata
# still causes the scanner to flag it.
#
# This does NOT cover every CVE in every one of these package groups --
# only the ones whose vulnerable component matches a path checked below.
# Any CVE tied to a binary/library NOT in this list should be treated as
# still potentially live and reviewed individually.
#
# LINKAGE ANALYSIS (shared-library groups only): "confirm with ldd" is a
# to-do nobody actually does by hand, so this script does it itself. It
# uses `readelf -d` rather than literal ldd -- ldd works by executing the
# binary's loader (LD_TRACE_LOADED_OBJECTS=1 <binary>), which runs a sliver
# of the binary itself, not something to do against flagged binaries pulled
# out of a container under review. readelf -d reads the same NEEDED entries
# straight out of the ELF dynamic section, giving the identical answer --
# does any shipped binary actually require this library -- with zero
# execution. Caveat this script states plainly rather than hiding: this
# only catches a library pulled in via DT_NEEDED at link time; something
# loaded via dlopen() at runtime would not appear here. Requires `readelf`
# (binutils) on the scanning host; if it's missing, linkage analysis is
# skipped and the finding falls back to a manual-review disposition rather
# than silently claiming something it didn't check.
#
# IA MANUAL VERIFICATION: to reproduce this check independently against a
# built image, extract its filesystem and point this script at the result:
# CID=$(docker create <image>:<tag>)
# mkdir -p /tmp/rootfs_check && docker export "$CID" | tar -x -C /tmp/rootfs_check
# docker rm "$CID"
# ./compensating_control_verifier.sh /tmp/rootfs_check
# Every PRESENT/ABSENT line is a plain file-existence test against that
# extracted tree -- reproduce by hand with:
# test -e /tmp/rootfs_check/<path> && echo PRESENT || echo ABSENT
# Every LINKED BY line is a readelf -d NEEDED scan across every ELF file in
# that tree -- reproduce by hand with:
# readelf -d /tmp/rootfs_check/<binary> | grep NEEDED
#
set -euo pipefail

ROOTFS="$1"

echo "=== Compensating-Control Verification Report ==="
echo "Image rootfs under test: ${ROOTFS}"
echo "Method: direct file-existence test for each binary/library listed"
echo "below against the extracted image filesystem. No package-manager"
echo "metadata (dpkg status, SBOM) is consulted here -- this checks what"
echo "is actually shipped on disk, independent of what Syft/Grype recorded."
echo

echo "=== Plain-Language Summary (for non-technical reviewers) ==="
echo "A normal computer is like an apartment building: it has one"
echo "foundation (the kernel) and one building manager (systemd) who"
echo "turns on the lights and water for every apartment. A container"
echo "isn't an apartment in that building -- it's a single vending"
echo "machine plugged into the building's outlet. It has no foundation"
echo "of its own, and no apartments to manage, so a building manager was"
echo "never needed in the first place."
echo
echo "The groups checked below are leftover tools from a normal full"
echo "computer that a vending-machine-style container has no use for:"
echo "  util-linux     - tools for partitioning/formatting a physical hard"
echo "                   drive. This container never touches a real drive"
echo "                   directly, so these are like keeping a tire iron"
echo "                   in a car whose wheels are welded on."
echo "  systemd        - the building manager described above."
echo "  shadow/passwd  - tools for creating new logins/user accounts. This"
echo "                   container's one account was set once when it was"
echo "                   built and never changes while it's running."
echo "  gzip / xz      - tools for compressing/decompressing files. Nothing"
echo "                   in this container zips or unzips files while it's"
echo "                   running."
echo
echo "Each group below gets one of three verdicts:"
echo "  Risk accepted / ABSENT      The tool genuinely is not in this"
echo "                               image. The scanner still lists the"
echo "                               package by name/version because"
echo "                               that's metadata, not a live check --"
echo "                               this report IS the live check, and it"
echo "                               found nothing that could be used."
echo "  NOT MITIGATED                The tool (or a library it depends on)"
echo "                               IS present, and something in the"
echo "                               image actually needs it. Treat this"
echo "                               as a real, open item."
echo "  NOT MITIGATED,                The file is present, but nothing in"
echo "  but likely removable          this image actually uses it --"
echo "                               reasonable to remove on review, just"
echo "                               not done yet."
echo

HAVE_READELF=0
if command -v readelf >/dev/null 2>&1; then
    HAVE_READELF=1
else
    echo "WARNING: readelf not found on this host -- shared-library findings"
    echo "below will skip linkage analysis and fall back to a manual-review"
    echo "disposition instead of a checked one. Install binutils to enable it."
    echo
fi

# Collect every ELF file in the rootfs ONCE, so each library lookup doesn't
# re-walk the tree. Static analysis only (readelf -h/-d read the ELF
# header/dynamic section) -- nothing in the rootfs is ever executed.
ELF_LIST_FILE=""
if [ "$HAVE_READELF" -eq 1 ]; then
    ELF_LIST_FILE="$(mktemp)"
    trap 'rm -f "$ELF_LIST_FILE"' EXIT
    find "$ROOTFS" -type f 2>/dev/null | while IFS= read -r F; do
        if readelf -h "$F" >/dev/null 2>&1; then
            echo "$F"
        fi
    done > "$ELF_LIST_FILE"
fi

# For a shared library at $1 (full on-disk path under ROOTFS), print which
# shipped ELF files declare it as a NEEDED dependency. Echoes nothing and
# returns 1 if none do (or if readelf isn't available).
find_linkers() {
    local LIBPATH="$1"
    local SONAME
    SONAME="$(basename "$LIBPATH")"
    [ "$HAVE_READELF" -eq 1 ] || return 1

    local FOUND_ANY=1
    while IFS= read -r BIN; do
        [ -n "$BIN" ] || continue
        # Skip the library's own file so a library that happens to declare
        # itself (rare, but seen with some SONAME/filename aliasing) isn't
        # reported as linking itself.
        [ "$BIN" = "$LIBPATH" ] && continue
        if readelf -d "$BIN" 2>/dev/null | grep -q "NEEDED.*\[${SONAME}\]"; then
            echo "  LINKED BY: ${BIN#"$ROOTFS"}"
            FOUND_ANY=0
        fi
    done < "$ELF_LIST_FILE"
    return "$FOUND_ANY"
}

check() {
    NAME="$1"
    RATIONALE="$2"
    shift 2
    echo "-- ${NAME} --"
    echo "Rationale: ${RATIONALE}"

    # Derive the right noun from the group's NAME suffix so the
    # DISPOSITION line never conflates executables with shared libraries --
    # a shared library can't simply be deleted the way a standalone binary
    # can, since something else actually required at runtime may be
    # dynamically linked against it.
    case "$NAME" in
        *"(shared libraries)")
            NOUN_PLURAL="shared libraries"
            KIND="libraries"
            ;;
        *)
            NOUN_PLURAL="executables"
            KIND="binaries"
            ;;
    esac

    FOUND=0
    ANY_LINKED=0
    ANY_UNLINKED_PRESENT=0
    for FILE in "$@"; do
        TARGET="${ROOTFS}${FILE}"
        if [ -e "$TARGET" ]; then
            echo "PRESENT: $FILE"
            FOUND=1
            if [ "$KIND" = "libraries" ]; then
                if find_linkers "$TARGET"; then
                    ANY_LINKED=1
                else
                    if [ "$HAVE_READELF" -eq 1 ]; then
                        echo "  LINKED BY: (none found via static NEEDED scan -- a dlopen()'d dependency would not appear here)"
                        ANY_UNLINKED_PRESENT=1
                    else
                        echo "  LINKED BY: (not checked -- readelf unavailable on this host)"
                    fi
                fi
            fi
        else
            echo "ABSENT: $FILE"
        fi
    done

    if [ "$FOUND" -eq 0 ]; then
        echo "DISPOSITION: Risk accepted via compensating control. All"
        echo " ${NAME} ${NOUN_PLURAL} checked above are absent from"
        echo " the shipped rootfs. The package version remains in the"
        echo " image's dpkg/SBOM metadata (which is why the scanner still"
        echo " reports it), but the exploitable code path this script"
        echo " checks for is not present on disk and cannot be invoked."
    elif [ "$KIND" = "libraries" ] && [ "$HAVE_READELF" -eq 1 ]; then
        if [ "$ANY_LINKED" -eq 1 ]; then
            echo "DISPOSITION: NOT MITIGATED. One or more ${NAME} are"
            echo " PRESENT and confirmed, via static NEEDED analysis above,"
            echo " to be linked by at least one shipped binary. That binary"
            echo " requires this library at runtime, so it cannot be"
            echo " removed without also removing (or statically relinking)"
            echo " whatever depends on it. Findings against this package"
            echo " group must be treated as live until each linking binary"
            echo " is individually reviewed."
        else
            echo "DISPOSITION: NOT MITIGATED, but likely removable. One or"
            echo " more ${NAME} are present on disk, yet static NEEDED"
            echo " analysis above found no shipped binary that requires"
            echo " any of them. They are not yet risk-accepted -- the"
            echo " files still exist and the scanner still sees the"
            echo " package version -- but nothing found here depends on"
            echo " them, so removal is a reasonable next step. The one gap"
            echo " this analysis cannot see is a dlopen()'d dependency at"
            echo " runtime, which a static NEEDED scan will not catch."
        fi
    else
        echo "DISPOSITION: NOT MITIGATED. One or more ${NAME}"
        if [ "$KIND" = "libraries" ]; then
            echo " ${NOUN_PLURAL} are present, and linkage could not be"
            echo " checked on this host (readelf unavailable). Install"
            echo " binutils and re-run to get a checked disposition rather"
            echo " than this placeholder; until then, treat this group as"
            echo " live."
        else
            echo " ${NOUN_PLURAL} are still present. These are standalone"
            echo " binaries, not shared libraries, so each one can likely"
            echo " be removed from the image directly; findings against"
            echo " this package group must be treated as potentially live"
            echo " until each listed path is either removed or"
            echo " individually justified."
        fi
    fi
    echo
}

# --- util-linux ------------------------------------------------------------
# Binaries: block-device, namespace/cgroup, and legacy multi-user-terminal
# tooling with no purpose in a headless single-service container, and
# several (nsenter, unshare, setpriv) that are specifically useful to an
# attacker with code execution for container/namespace escape attempts.
# Libraries: libblkid/libmount/libuuid/libsmartcols are the part most
# likely to be a *hidden* dependency of something else in the image --
# the DISPOSITION above now reports which shipped binary (if any) actually
# needs each one, instead of leaving that as a manual follow-up.
check "util-linux (binaries)" \
    "Block-device, namespace/cgroup, and legacy terminal tools; not required by postgres/guacd/nginx/Tomcat at runtime." \
    /usr/bin/lsblk \
    /usr/bin/fdisk \
    /usr/sbin/sfdisk \
    /usr/sbin/cfdisk \
    /usr/sbin/losetup \
    /usr/sbin/blkid \
    /bin/mount \
    /usr/bin/mount \
    /bin/umount \
    /usr/bin/umount \
    /sbin/swapon \
    /sbin/swapoff \
    /usr/bin/nsenter \
    /usr/bin/unshare \
    /usr/bin/setpriv \
    /usr/bin/chrt \
    /usr/bin/ionice \
    /usr/bin/taskset \
    /usr/bin/setarch \
    /sbin/agetty \
    /usr/bin/wall \
    /usr/bin/write \
    /usr/bin/mesg \
    /usr/bin/last \
    /usr/bin/lastb \
    /usr/bin/utmpdump \
    /usr/bin/script \
    /usr/bin/scriptreplay \
    /usr/bin/eject \
    /usr/sbin/readprofile \
    /sbin/hwclock \
    /usr/sbin/hwclock \
    /usr/sbin/rtcwake \
    /usr/bin/rename \
    /usr/bin/logger \
    /usr/bin/column \
    /usr/bin/flock \
    /usr/bin/getopt

check "util-linux (shared libraries)" \
    "DISPOSITION below reports actual linkage (readelf -d NEEDED scan), not a request to go check manually." \
    /usr/lib/x86_64-linux-gnu/libblkid.so.1 \
    /usr/lib/x86_64-linux-gnu/libmount.so.1 \
    /usr/lib/x86_64-linux-gnu/libuuid.so.1 \
    /usr/lib/x86_64-linux-gnu/libsmartcols.so.1

# --- systemd -----------------------------------------------------------
check "systemd (binaries)" \
    "systemd is the host's init/service-manager layer, not something a container runs: the container runtime itself is PID 1 here and starts only this one application process directly, so these binaries were never part of the image to begin with." \
    /usr/lib/systemd/systemd \
    /bin/systemctl \
    /usr/bin/systemctl \
    /usr/bin/journalctl \
    /usr/bin/loginctl \
    /usr/bin/busctl

check "systemd (shared libraries)" \
    "DISPOSITION below reports actual linkage (readelf -d NEEDED scan); libsystemd/libudev are the most common transitively-linked pieces of systemd." \
    /usr/lib/x86_64-linux-gnu/libsystemd.so.0 \
    /usr/lib/x86_64-linux-gnu/libudev.so.1

# --- shadow / passwd -----------------------------------------------------
# Note: Grype reports the upstream project name "shadow"; the Debian
# package providing these binaries is named "passwd". Confirm with
# `dpkg -S /usr/bin/passwd` if scripting an apt-get purge for this group.
check "shadow/passwd account-management" \
    "No interactive login or account provisioning happens inside a running container; users/UIDs are fixed at build time." \
    /usr/bin/passwd \
    /usr/bin/chage \
    /usr/bin/chfn \
    /usr/bin/chsh \
    /usr/bin/newgrp \
    /usr/bin/gpasswd \
    /usr/sbin/useradd \
    /usr/sbin/usermod \
    /usr/sbin/userdel \
    /usr/sbin/groupadd \
    /usr/sbin/groupmod \
    /usr/sbin/groupdel \
    /usr/sbin/adduser \
    /usr/sbin/addgroup

# --- gzip ------------------------------------------------------------------
check "gzip" \
    "No runtime need to compress/decompress inside the container; dpkg-deb links compression libraries directly and does not shell out to this binary." \
    /bin/gzip \
    /usr/bin/gzip \
    /bin/gunzip \
    /usr/bin/gunzip

# --- xz ----------------------------------------------------------------
check "xz" \
    "Same rationale as gzip." \
    /usr/bin/xz \
    /bin/xz \
    /usr/bin/unxz \
    /bin/unxz

echo "=== Summary ==="
echo "Every DISPOSITION line above is derived solely from the PRESENT/ABSENT"
echo "results (and, for shared-library groups, the readelf -d NEEDED scan)"
echo "in this report -- there is no additional hidden criteria. A package"
echo "group marked NOT MITIGATED requires per-CVE review against the vendor"
echo "security tracker (e.g. security-tracker.debian.org) to confirm which"
echo "specific binary or library each CVE affects before it can be"
echo "dispositioned."
echo "Verification complete."
