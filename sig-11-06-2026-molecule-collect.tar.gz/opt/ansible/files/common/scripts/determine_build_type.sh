#!/bin/bash
#
# determine_build_type.sh
#
# Output:
#   Line 1: build type ("quarterly" or "weekly")
#   Line 2: week number (only for weekly builds)
#

# Determine current week number (01–53)
WEEK_NUM=$(date +%V)

# Determine current quarter (e.g., fy26q3)
CURRENT_QUARTER=$(/opt/ansible/files/common/scripts/determine_quarters.sh | head -n1 | cut -d'=' -f2)

# Determine previous quarter
PREVIOUS_QUARTER=$(/opt/ansible/files/common/scripts/determine_quarters.sh | sed -n '2p' | cut -d'=' -f2)

# If quarter changed → quarterly build
if [[ "$CURRENT_QUARTER" != "$PREVIOUS_QUARTER" ]]; then
    echo "quarterly"
    echo ""        # no week number for quarterly builds
    exit 0
fi

# Otherwise → weekly build
echo "weekly"
echo "$WEEK_NUM"
exit 0
