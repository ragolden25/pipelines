#!/usr/bin/env bash
set -euo pipefail

date +%V
