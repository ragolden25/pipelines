#!/usr/bin/env bash
set -euo pipefail

ASSET_DIR="/opt/ansible/files/common/anchore"

mkdir -p "${ASSET_DIR}/js" "${ASSET_DIR}/css"

echo "Downloading jQuery..."
curl -L -o "${ASSET_DIR}/js/jquery-3.7.1.min.js" \
  https://code.jquery.com/jquery-3.7.1.min.js

echo "Downloading DataTables core JS/CSS..."
curl -L -o "${ASSET_DIR}/js/jquery.dataTables.min.js" \
  https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js

curl -L -o "${ASSET_DIR}/css/jquery.dataTables.min.css" \
  https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css

echo "Downloading Responsive extension..."
curl -L -o "${ASSET_DIR}/js/dataTables.responsive.min.js" \
  https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js

curl -L -o "${ASSET_DIR}/css/responsive.dataTables.min.css" \
  https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css

echo "Downloading Buttons extension..."
curl -L -o "${ASSET_DIR}/js/dataTables.buttons.min.js" \
  https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js

curl -L -o "${ASSET_DIR}/js/buttons.html5.min.js" \
  https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js

curl -L -o "${ASSET_DIR}/css/buttons.dataTables.min.css" \
  https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css

chown -R ansible:ansible $ASSET_DIR

echo "All assets downloaded to ${ASSET_DIR}"
