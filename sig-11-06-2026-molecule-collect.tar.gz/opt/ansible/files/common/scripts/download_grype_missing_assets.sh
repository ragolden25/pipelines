#!/usr/bin/env bash
set -euo pipefail

ASSET_DIR="/opt/ansible/files/common/anchore"

mkdir -p "${ASSET_DIR}/js" "${ASSET_DIR}/css" "${ASSET_DIR}/img"

echo "Downloading DataTables combined bundle (CSS + JS)..."
curl -L -o "${ASSET_DIR}/css/datatables.min.css" \
  https://cdn.datatables.net/v/dt/jq-3.7.0/jszip-3.10.1/dt-2.3.0/b-3.2.3/b-html5-3.2.3/r-3.0.4/datatables.min.css

curl -L -o "${ASSET_DIR}/js/datatables.min.js" \
  https://cdn.datatables.net/v/dt/jq-3.7.0/jszip-3.10.1/dt-2.3.0/b-3.2.3/b-html5-3.2.3/r-3.0.4/datatables.min.js

echo "Downloading JSZip (Excel export dependency)..."
curl -L -o "${ASSET_DIR}/js/jszip.min.js" \
  https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js

echo "Downloading pdfmake (PDF export dependency)..."
curl -L -o "${ASSET_DIR}/js/pdfmake.min.js" \
  https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js

curl -L -o "${ASSET_DIR}/js/vfs_fonts.js" \
  https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js

echo "Downloading Devicon CSS..."
curl -L -o "${ASSET_DIR}/css/devicon.min.css" \
  https://cdn.jsdelivr.net/gh/devicons/devicon@2.16.0/devicon.min.css

echo "Downloading Font Awesome..."
curl -L -o "${ASSET_DIR}/css/fontawesome.min.css" \
  https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css

echo "Downloading Iconify SVGs..."
curl -L -o "${ASSET_DIR}/img/noto-package.svg" \
  https://api.iconify.design/noto:package.svg

curl -L -o "${ASSET_DIR}/img/alpine-linux.svg" \
  https://api.iconify.design/file-icons:alpine-linux.svg

curl -L -o "${ASSET_DIR}/img/excel.svg" \
  https://api.iconify.design/vscode-icons:file-type-excel.svg

curl -L -o "${ASSET_DIR}/img/pdf.svg" \
  https://api.iconify.design/vscode-icons:file-type-pdf2.svg

chown -R ansible:ansible $ASSET_DIR

echo "Missing Grype assets downloaded to ${ASSET_DIR}"

