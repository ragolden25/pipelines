#!/usr/bin/env bash
# extend-calendar.sh - append fiscal years to calendar.env
#
# Fiscal year FYnn runs Oct 1 (previous calendar year) through Sep 30.
# Finds the highest FYnn already in the file and appends the next N years
# in the same format. Makes a timestamped backup before writing.
#
# Usage: extend-calendar.sh [-n YEARS] [-f FILE] [--dry-run]
# -n YEARS number of fiscal years to add (default: 5)
# -f FILE calendar file (default: /opt/ansible/files/common/calendar.env)
# --dry-run print what would be appended, change nothing

set -euo pipefail

years=5
file=/opt/ansible/files/common/calendar.env
dry_run=false

while (( $# )); do
    case "$1" in
        -n) years="$2"; shift 2 ;;
        -f) file="$2"; shift 2 ;;
        --dry-run) dry_run=true; shift ;;
        -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

[[ "$years" =~ ^[1-9][0-9]*$ ]] || { echo "Years must be a positive integer" >&2; exit 1; }
[[ -f "$file" ]] || { echo "File not found: $file" >&2; exit 1; }

# Highest fiscal year present (two-digit suffix, e.g. 32 from FY32Q4_END)
last=$(grep -oE '^FY[0-9]{2}Q[1-4]_(START|END)=' "$file" \
       | sed -E 's/^FY([0-9]{2}).*/\1/' | sort -n | tail -1)
[[ -n "$last" ]] || { echo "No FYnn entries found in $file" >&2; exit 1; }

# The last year must be complete (all 8 keys) before we extend past it
count=$(grep -cE "^FY${last}Q[1-4]_(START|END)=" "$file")
(( count == 8 )) || { echo "FY${last} is incomplete ($count of 8 entries); fix it first" >&2; exit 1; }

last=$((10#$last))
block=""
for (( i = 1; i <= years; i++ )); do
    fy=$((last + i))
    (( fy <= 99 )) || { echo "FY$fy exceeds two-digit format" >&2; exit 1; }
    yy=$(printf '%02d' "$fy")
    full=$((2000 + fy))
    prev=$((full - 1))
    block+=$(cat <<EOF


# ============================
# Fiscal Year $full
# ============================
FY${yy}Q1_START=${prev}-10-01
FY${yy}Q1_END=${prev}-12-31

FY${yy}Q2_START=${full}-01-01
FY${yy}Q2_END=${full}-03-31

FY${yy}Q3_START=${full}-04-01
FY${yy}Q3_END=${full}-06-30

FY${yy}Q4_START=${full}-07-01
FY${yy}Q4_END=${full}-09-30
EOF
)
done

if $dry_run; then
    printf '%s\n' "$block"
    exit 0
fi

backup="${file}.$(date +%Y%m%d-%H%M%S).bak"
cp -p "$file" "$backup"

# Drop trailing blank lines, then append the new block
tmp=$(mktemp "${file}.XXXX")
sed -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$file" > "$tmp"
printf '%s\n' "$block" >> "$tmp"
chmod --reference="$file" "$tmp"
chown --reference="$file" "$tmp" 2>/dev/null || true
mv "$tmp" "$file"

echo "Added FY$(printf '%02d' $((last + 1))) through FY$(printf '%02d' $((last + years))) to $file"
echo "Backup: $backup"
