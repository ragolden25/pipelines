#!/usr/bin/env bash

set -euo pipefail

# =====================================================================
# Grafana Shipping Bundle Builder (Per-image dir → tar → xz)
# Quarter-aware, signature-safe for Docker images
# =====================================================================

DATE="$(date +%d%b%Y | tr '[:upper:]' '[:lower:]')"   # e.g., 18sep2026
SHIP_DIR="/opt/ansible/shipping/grafana/${DATE}"

# Detect quarter dynamically
Q_OUT=$(/opt/ansible/files/common/scripts/determine_quarters.sh)
QUARTER=$(echo "$Q_OUT" | grep '^quarter=' | cut -d= -f2)

if [[ -z "${QUARTER}" || "${QUARTER}" == "unknown" ]]; then
  echo "ERROR: Could not determine quarter."
  exit 2
fi

QUARTER_SRC="/opt/ansible/files/grafana/${QUARTER}"
IMG_SRC="${QUARTER_SRC}/images"
ROLE_ROOT="/opt/ansible/nucleus/roles"
SCRIPT_ROOT="/opt/ansible/scripts"

mkdir -p "${SHIP_DIR}"

INVENTORY="${SHIP_DIR}/inventory.txt"
echo "Inventory of Grafana file transfers on ${DATE}" > "${INVENTORY}"
echo "" >> "${INVENTORY}"

add_inventory() {
  local file="$1"
  local src="$2"
  local dest="$3"
  local size
  size=$(du -h "${file}" | awk '{print $1}')
  echo "${file##*/} (${size})" >> "${INVENTORY}"
  echo " source: ${src}" >> "${INVENTORY}"
  echo " dest: ${dest}" >> "${INVENTORY}"
  echo "" >> "${INVENTORY}"
}

# =====================================================================
# 1. Compress Grafana role → configure_grafana_stack.tar.xz
# =====================================================================

G_ROLE="configure_grafana_stack"
G_SRC="${ROLE_ROOT}/${G_ROLE}"
G_OUT="${SHIP_DIR}/${G_ROLE}.tar.xz"

echo "==> Compressing role: ${G_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${G_ROLE}" | xz -T0 -9e > "${G_OUT}"
add_inventory "${G_OUT}" "${G_SRC}" "${ROLE_ROOT}"

# =====================================================================
# 2. Compress install_docker_python role → install_docker_python.tar.xz
# =====================================================================

IDP_ROLE="install_docker_python"
IDP_SRC="${ROLE_ROOT}/${IDP_ROLE}"
IDP_OUT="${SHIP_DIR}/${IDP_ROLE}.tar.xz"

echo "==> Compressing role: ${IDP_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${IDP_ROLE}" | xz -T0 -9e > "${IDP_OUT}"
add_inventory "${IDP_OUT}" "${IDP_SRC}" "${ROLE_ROOT}"

# =====================================================================
# 3. Ship ALL Grafana images (each image: dir → tar → xz)
# =====================================================================

echo "==> Shipping Grafana images (per-image dir → tar → xz)"

IMG_WORK_DIR="${SHIP_DIR}/images-work"
mkdir -p "${IMG_WORK_DIR}"

for img in "${IMG_SRC}"/*.tar.gz; do
  [[ -e "${img}" ]] || continue

  base="$(basename "${img}")"
  img_name="${base%.tar.gz}"          # e.g. nucleus-grafana-3.1.0
  img_dir="${IMG_WORK_DIR}/${img_name}"

  echo "==> Preparing image: ${base}"
  mkdir -p "${img_dir}"

  # Copy signed .tar.gz untouched into its own directory
  cp "${img}" "${img_dir}/"

  # Tar the directory
  IMG_TAR="${SHIP_DIR}/${img_name}.tar"
  tar -C "${img_dir}" -cf "${IMG_TAR}" .

  # xz the tar
  xz -T0 -9e "${IMG_TAR}"

  add_inventory "${IMG_TAR}.xz" "${img}" "${IMG_SRC}"
done

rm -rf "${IMG_WORK_DIR}"

# =====================================================================
# 4. Optional: include cis_docker.zip
# =====================================================================

CIS_ZIP="${SCRIPT_ROOT}/cis_docker.zip"
if [[ -f "${CIS_ZIP}" ]]; then
  echo "==> Including cis_docker.zip"
  cp "${CIS_ZIP}" "${SHIP_DIR}/cis_docker.zip"
  add_inventory "${SHIP_DIR}/cis_docker.zip" "${CIS_ZIP}" "${SCRIPT_ROOT}"
fi

# =====================================================================
# 4b. Include import-grafana-shipping.sh in the bundle
# =====================================================================

IMPORT_SCRIPT="/opt/ansible/files/common/scripts/import-grafana-shipping.sh"

if [[ -f "${IMPORT_SCRIPT}" ]]; then
  echo "==> Including import-grafana-shipping.sh"
  cp "${IMPORT_SCRIPT}" "${SHIP_DIR}/import-grafana-shipping.sh"
  add_inventory "${SHIP_DIR}/import-grafana-shipping.sh" "${IMPORT_SCRIPT}" "${SCRIPT_ROOT}"
fi

# =====================================================================
# 5. Compress quarter directory (safely including root directory name)
# =====================================================================

QUARTER_OUT="${SHIP_DIR}/${QUARTER}.tar.xz"
echo "==> Creating quarter bundle: ${QUARTER}.tar.xz"

# -C changes to parent folder, targets folder name directly to enforce folder structure on extract
# Explicitly excludes previous runs, images, and backup files left by jq/sed
tar -C "/opt/ansible/files/grafana" \
  --exclude="${QUARTER}/images" \
  --exclude="*.tar.xz" \
  --exclude="*.orig" \
  --exclude="*.old" \
  --exclude="*.tmp" \
  -cf - "${QUARTER}" | xz -T0 -9e > "${QUARTER_OUT}"

add_inventory "${QUARTER_OUT}" "${QUARTER_SRC}" "/opt/ansible/files/grafana"

# =====================================================================
# Summary
# =====================================================================

echo ""
echo "=============================================================="
echo "Grafana shipping bundle created:"
echo "  ${SHIP_DIR}"
echo ""
echo "Files included:"
ls -lh "${SHIP_DIR}"
echo ""
echo "Inventory written to:"
echo "  ${INVENTORY}"
echo "=============================================================="
