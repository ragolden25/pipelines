#!/usr/bin/env bash

set -euo pipefail

# =====================================================================
# Grafana Shipping Importer
# Unxz + untar roles, images, quarter bundle into target locations
# =====================================================================

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 <shipping_dir> <quarter>"
  echo "  e.g.: $0 /opt/ansible/shipping/grafana/22aug2026 fy26q4"
  exit 1
fi

SHIP_DIR="$1"
QUARTER="$2"

ROLE_ROOT="/opt/ansible/nucleus/roles"
GRAFANA_ROOT="/opt/ansible/files/grafana"
QUARTER_DST="${GRAFANA_ROOT}/${QUARTER}"
IMG_DST="${QUARTER_DST}/images"

INVENTORY="${SHIP_DIR}/inventory.txt"

if [[ ! -d "${SHIP_DIR}" ]]; then
  echo "ERROR: Shipping directory not found: ${SHIP_DIR}"
  exit 2
fi

mkdir -p "${ROLE_ROOT}" "${QUARTER_DST}" "${IMG_DST}"

echo "=== Importing Grafana shipping bundle ==="
echo "Shipping dir: ${SHIP_DIR}"
echo "Quarter:      ${QUARTER}"
echo "Inventory:    ${INVENTORY}"
echo ""

if [[ -f "${INVENTORY}" ]]; then
  echo "Inventory contents:"
  cat "${INVENTORY}"
  echo ""
fi

# ---------------------------------------------------------------------
# 1. Import roles (*.tar.xz → roles)
# ---------------------------------------------------------------------

for role_tar_xz in "${SHIP_DIR}"/configure_grafana_stack.tar.xz \
                   "${SHIP_DIR}"/install_docker_python.tar.xz; do
  [[ -f "${role_tar_xz}" ]] || continue

  base="$(basename "${role_tar_xz}")"
  name="${base%.tar.xz}"

  echo "==> Importing role: ${name}"

  tmp_tar="${SHIP_DIR}/${name}.tar"
  cp "${role_tar_xz}" "${tmp_tar}.xz"

  unxz -f "${tmp_tar}.xz"
  tar -C "${ROLE_ROOT}" -xf "${tmp_tar}"
  rm -f "${tmp_tar}"
done

# ---------------------------------------------------------------------
# 2. Import images (<image>.tar.xz → quarter/images)
# ---------------------------------------------------------------------

for img_tar_xz in "${SHIP_DIR}"/*.tar.xz; do
  [[ -f "${img_tar_xz}" ]] || continue

  base="$(basename "${img_tar_xz}")"

  # Skip quarter bundle and roles (handled elsewhere)
  if [[ "${base}" == "${QUARTER}.tar.xz" ]] || \
     [[ "${base}" == "configure_grafana_stack.tar.xz" ]] || \
     [[ "${base}" == "install_docker_python.tar.xz" ]]; then
    continue
  fi

  name="${base%.tar.xz}"
  echo "==> Importing image bundle: ${base}"

  tmp_tar="${SHIP_DIR}/${name}.tar"
  cp "${img_tar_xz}" "${tmp_tar}.xz"

  unxz -f "${tmp_tar}.xz"

  # Extract into a temp dir, then move .tar.gz into IMG_DST
  tmp_dir="${SHIP_DIR}/import-${name}"
  mkdir -p "${tmp_dir}"
  tar -C "${tmp_dir}" -xf "${tmp_tar}"
  rm -f "${tmp_tar}"

  find "${tmp_dir}" -type f -name '*.tar.gz' -exec mv {} "${IMG_DST}/" \;
  rm -rf "${tmp_dir}"
done

# ---------------------------------------------------------------------
# 3. Import quarter bundle (<quarter>.tar.xz → /opt/ansible/files/grafana/<quarter>)
# ---------------------------------------------------------------------

QUARTER_TAR_XZ="${SHIP_DIR}/${QUARTER}.tar.xz"
if [[ -f "${QUARTER_TAR_XZ}" ]]; then
  echo "==> Importing quarter bundle: ${QUARTER_TAR_XZ}"

  tmp_tar="${SHIP_DIR}/${QUARTER}.tar"
  cp "${QUARTER_TAR_XZ}" "${tmp_tar}.xz"

  unxz -f "${tmp_tar}.xz"
  tar -C "${QUARTER_DST}" -xf "${tmp_tar}"
  rm -f "${tmp_tar}"
fi

echo ""
echo "=== Grafana shipping import complete ==="
echo "Roles imported to:      ${ROLE_ROOT}"
echo "Images imported to:     ${IMG_DST}"
echo "Quarter content to:     ${QUARTER_DST}"
