#!/bin/bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Usage: normalize_vuln_csv.sh <vuln.csv>"
    exit 1
fi

INPUT="$1"
OUTPUT="${INPUT%.csv}.normalized.csv"

echo "==> Normalizing vulnerability CSV for IA review"
echo "==> Input:  $INPUT"
echo "==> Output: $OUTPUT"

# Write header
echo '"CVE","Severity","Package","Version","FixState","Exploitability","IA_Justification"' > "$OUTPUT"

# Skip header and process rows
tail -n +2 "$INPUT" | while IFS=',' read -r CVE SEV PKG VER FIX VERSIONS; do

    case "$FIX" in
        "wont-fix")
            FIX_NORM="Upstream: Not Applicable"
            EXPLOIT="Not exploitable in containerized environment"
            JUSTIFY="Upstream does not plan a fix; container isolation, non-privileged runtime, and limited attack surface significantly reduce exploitability."
            ;;

        "not-fixed")
            FIX_NORM="Upstream: Pending"
            EXPLOIT="Not readily exploitable in containerized environment"
            JUSTIFY="Issue exists upstream but typical container runtime constraints (no direct user interaction, restricted filesystem, limited capabilities) reduce practical exploitability."
            ;;

        "fixed")
            FIX_NORM="Fixed"
            EXPLOIT="Resolved"
            JUSTIFY="Patched in the current package version."
            ;;

        *)
            FIX_NORM="Unknown"
            EXPLOIT="Unknown"
            JUSTIFY="No fix information available; requires manual review to determine applicability and risk."
            ;;
    esac

    echo "\"$CVE\",\"$SEV\",\"$PKG\",\"$VER\",\"$FIX_NORM\",\"$EXPLOIT\",\"$JUSTIFY\"" >> "$OUTPUT"

done

echo "==> Normalization complete. Preview:"
head "$OUTPUT"
