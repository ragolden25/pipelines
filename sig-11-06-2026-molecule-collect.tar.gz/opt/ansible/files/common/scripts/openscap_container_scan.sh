#!/bin/bash
set -euo pipefail

IMAGE="$1"
OUTPUT_DIR="$2"
NAME="$3"

mkdir -p "$OUTPUT_DIR"

if [[ -z "$IMAGE" || -z "$OUTPUT_DIR" || -z "$NAME" ]]; then
    echo "Usage: openscap_container_scan.sh <image> <output_dir> <name>"
    exit 1
fi

echo "==> OpenSCAP Container Scan"
echo "==> Image:       $IMAGE"
echo "==> Output Dir:  $OUTPUT_DIR"
echo "==> Safe Name:   $NAME"

# Ensure OpenSCAP is installed
if ! command -v oscap >/dev/null 2>&1; then
    echo "==> OpenSCAP not found. Installing..."
    if command -v dnf >/dev/null 2>&1; then
        dnf install -y openscap-scanner openscap-utils
    elif command -v yum >/dev/null 2>&1; then
        yum install -y openscap-scanner openscap-utils
    else
        echo "ERROR: Neither yum nor dnf found. Cannot install OpenSCAP."
        exit 1
    fi
fi

# OVAL definitions
OVAL_BZ2="/opt/ansible/files/common/oval/oval-definitions-trixie.xml.bz2"
OVAL_XML="/opt/ansible/files/common/oval/oval-definitions-trixie.xml"

if [[ ! -f "$OVAL_XML" ]]; then
    echo "==> Decompressing OVAL definitions"
    bunzip2 -k "$OVAL_BZ2"
fi

# Extract container filesystem
EXTRACT_DIR="/opt/ansible/molecule/scans/tmp/openscap-${NAME}"
mkdir -p "$EXTRACT_DIR"

echo "==> Extracting container filesystem"
CID=$(docker create "$IMAGE")
docker export "$CID" | tar --exclude='dev/*' --no-same-owner --no-same-permissions -C "$EXTRACT_DIR" -xf -
docker rm "$CID"

# Run OpenSCAP scan
RESULTS_XML="${OUTPUT_DIR}/${NAME}-openscap-results.xml"
REPORT_HTML="${OUTPUT_DIR}/${NAME}-openscap-report.html"

echo "==> Running OpenSCAP OVAL scan"
oscap oval eval \
    --results "$RESULTS_XML" \
    --report "$REPORT_HTML" \
    "$OVAL_XML"

# Cleanup
echo "==> Cleaning up extraction directory"
rm -rf "$EXTRACT_DIR"

echo "==> OpenSCAP scan complete"
echo "==> Results XML: $RESULTS_XML"
echo "==> Report HTML: $REPORT_HTML"
