#!/usr/bin/env python3
import os
import re
import sys
import yaml
from graphviz import Digraph

ROLES_DIR = "/opt/ansible/nucleus/roles"

# Simple Left-to-Right layout for top-level stages
dot = Digraph(name="Pipeline_Map", comment="Clean Pipeline Flow", format="png")
dot.attr(rankdir="LR")
dot.attr(nodesep="0.4", ranksep="1.0")

# Clear, uncluttered default styles
dot.attr(
    'node',
    fontname='Helvetica',
    fontsize='10',
    shape='box',
    style='filled,rounded',
    fillcolor='#FFFFFF',
    color='#6B7280'
)
dot.attr('edge', fontname='Helvetica', fontsize='8', color='#4B5563', arrowhead='vee')


def parse_shell_script(script_path, parent_node_id, stage_prefix):
    """Crawls bash script for # STEP lines and hangs them vertically beneath the parent."""
    if not os.path.exists(script_path):
        return

    steps = []
    with open(script_path, "r", errors='ignore') as f:
        for line in f:
            match = re.search(r"#\s*STEP:\s*(.+)", line)
            if match:
                steps.append(match.group(1).strip())

    if not steps:
        return

    prev_step_id = None
    for idx, step in enumerate(steps):
        step_node_id = f"step_{stage_prefix}_{idx}"
        dot.node(
            step_node_id,
            label=f"Step {idx+1}: {step}",
            fillcolor="#D1FAE5",
            color="#10B981"
        ) # Green nodes

        if idx == 0:
            dot.edge(parent_node_id, step_node_id, color="#059669", style="dashed", label="executes")
        else:
            dot.edge(prev_step_id, step_node_id, color="#10B981")

        prev_step_id = step_node_id


def resolve_role_tasks(role_name):
    """Locates the main.yml task entry point for a role inside ROLES_DIR."""
    possible_paths = [
        os.path.join(ROLES_DIR, role_name, "tasks", "main.yml"),
        os.path.join(ROLES_DIR, role_name, "tasks", "main.yaml")
    ]
    for path in possible_paths:
        if os.path.exists(path):
            return path
    return None


def process_subtasks(subtasks, base_dir, parent_id, prefix="sub"):
    """Draws subtasks vertically straight down underneath their parent node."""
    if not isinstance(subtasks, list):
        return

    prev_id = parent_id
    for idx, task in enumerate(subtasks):
        if not isinstance(task, dict) or not task:
            continue

        task_name = task.get("name", f"Subtask {idx + 1}")
        clean_prefix = re.sub(r'\W+', '_', str(prefix))
        clean_name = re.sub(r'\W+', '_', str(task_name))
        node_id = f"sub_{clean_prefix}_{idx}_{clean_name}"

        # Standard subtask node
        dot.node(node_id, label=task_name, fillcolor="#F3F4F6", color="#9CA3AF")
        
        # Connect vertically from previous node in this sub-branch
        dot.edge(prev_id, node_id, color="#6B7280")
        prev_id = node_id

        # Scan for shell execution
        for module in ["shell", "command", "ansible.builtin.shell", "ansible.builtin.command"]:
            if module in task:
                module_content = task[module]
                cmd_string = module_content.get("cmd", "") if isinstance(module_content, dict) else str(module_content)

                script_match = re.search(r"([\w\-/.]+\.(?:sh|py))", cmd_string)
                if script_match:
                    raw_script_path = script_match.group(1)
                    resolved_script = (
                        raw_script_path
                        if os.path.isabs(raw_script_path)
                        else os.path.join(base_dir, raw_script_path)
                    )
                    parse_shell_script(resolved_script, node_id, f"{clean_prefix}_{idx}")


def process_main_pipeline(tasks, base_dir):
    """Processes top-level tasks horizontally and hangs includes/subtasks beneath them."""
    if not isinstance(tasks, list):
        return

    prev_main_id = None

    for idx, task in enumerate(tasks):
        if not isinstance(task, dict) or not task:
            continue

        task_name = task.get("name", f"Stage {idx + 1}")
        clean_name = re.sub(r'\W+', '_', str(task_name))
        main_id = f"main_stage_{idx}_{clean_name}"

        # 1. Handle Include / Import tasks -> Blue Main Headers
        if "include_tasks" in task or "import_tasks" in task:
            dot.node(
                main_id,
                label=f"Stage {idx + 1}: {task_name}",
                fillcolor="#DBEAFE",
                color="#2563EB",
                fontcolor="#1E40AF",
                fontname="Helvetica-Bold"
            )

            nested_file = task.get("include_tasks") or task.get("import_tasks")
            nested_path = (
                nested_file
                if os.path.isabs(nested_file)
                else os.path.join(base_dir, nested_file)
            )

            if os.path.exists(nested_path):
                with open(nested_path, "r") as f:
                    try:
                        nested_tasks = yaml.safe_load(f)
                        # Hang subtasks straight down from this blue stage node
                        process_subtasks(nested_tasks, base_dir, parent_id=main_id, prefix=f"stage_{idx}")
                    except yaml.YAMLError:
                        pass

        # 2. Handle Roles -> Yellow Main Headers
        elif "include_role" in task or "import_role" in task:
            role_dict = task.get("include_role") or task.get("import_role")
            target_role = role_dict.get("name") if isinstance(role_dict, dict) else role_dict

            dot.node(
                main_id,
                label=f"Role: {target_role}",
                fillcolor="#FEF08A",
                color="#CA8A04",
                fontcolor="#854D0E",
                fontname="Helvetica-Bold"
            )

            role_file = resolve_role_tasks(target_role)
            if role_file:
                role_base_dir = os.path.dirname(role_file)
                with open(role_file, "r") as f:
                    try:
                        role_tasks = yaml.safe_load(f)
                        process_subtasks(role_tasks, role_base_dir, parent_id=main_id, prefix=f"role_{target_role}")
                    except yaml.YAMLError:
                        pass

        # 3. Standard Main Tasks -> White Headers
        else:
            dot.node(
                main_id,
                label=task_name,
                fillcolor="#FFFFFF",
                color="#374151",
                fontname="Helvetica-Bold"
            )

        # Connect top-level main stages horizontally across the top ONLY
        if prev_main_id:
            dot.edge(prev_main_id, main_id, color="#2563EB", penwidth="2.0", weight="10")

        prev_main_id = main_id


if __name__ == "__main__":
    playbook_path = "/opt/ansible/nucleus/playbooks/build_grafana_stack.yml"
    target_dir = os.path.dirname(playbook_path)

    if not os.path.exists(playbook_path):
        print(f"Error: Target file '{playbook_path}' cannot be found.")
        sys.exit(1)

    print(f"Parsing deployment source structure: {playbook_path}")
    with open(playbook_path, "r") as f:
        try:
            playbook_data = yaml.safe_load(f)

            if isinstance(playbook_data, list):
                for play in playbook_data:
                    if isinstance(play, dict) and "tasks" in play:
                        process_main_pipeline(play["tasks"], target_dir)

        except yaml.YAMLError as err:
            print(f"CRITICAL Error parsing YAML structure: {err}")
            sys.exit(1)

    output_render_path = "/opt/ansible/files/common/automated_pipeline_architecture"
    dot.render(output_render_path, cleanup=True)
    print(
        f"Pipeline flow schema successfully mapped directly to source definitions at:\n{output_render_path}.png"
    )

