#!/bin/bash
set -euo pipefail

BASE_OVAL_DIR="/opt/ansible/files/common/oval"
BASE_PROV_DIR="/opt/ansible/files"
STACKS=(grafana avocado)
KEEP_DAYS=7

# Determine current quarter
QUARTER_INFO=$(/opt/ansible/files/common/scripts/determine_quarters.sh)
CURRENT_QUARTER=$(echo "$QUARTER_INFO" | grep '^quarter=' | cut -d= -f2)

if [[ -z "$CURRENT_QUARTER" || "$CURRENT_QUARTER" == "unknown" ]]; then
    echo "ERROR: Could not determine current quarter"
    exit 1
fi

echo "Detected quarter: $CURRENT_QUARTER"

OVAL_BZ2="${BASE_OVAL_DIR}/oval-definitions-trixie.xml.bz2"
OVAL_XML="${BASE_OVAL_DIR}/oval-definitions-trixie.xml"

echo "Downloading Trixie OVAL definitions..."
wget -q -O "${OVAL_BZ2}" \
    https://www.debian.org/security/oval/oval-definitions-trixie.xml.bz2

chown ansible:ansible-admin "${OVAL_BZ2}"

echo "Decompressing..."
bunzip2 -f "${OVAL_BZ2}"

# Sync into each stack's quarterly provenance directory
for STACK in "${STACKS[@]}"; do
    TARGET_DIR="${BASE_PROV_DIR}/${STACK}/${CURRENT_QUARTER}/provenance"
    echo "Syncing OVAL XML to: ${TARGET_DIR}"
    mkdir -p "${TARGET_DIR}"
    rsync -avz "${OVAL_XML}" "${TARGET_DIR}/"
done

echo "Trixie OVAL sync complete."
exit 0
