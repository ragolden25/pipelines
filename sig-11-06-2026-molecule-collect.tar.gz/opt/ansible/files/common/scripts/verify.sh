#!/usr/bin/env bash
set -euo pipefail

KEYDIR="/var/lib/containers/gpgkeys"
IMGDIR="/var/lib/containers/images"
PROVDIR="/var/lib/containers/provenance"
LOGDIR="/var/lib/containers/verify"

mkdir -p "$LOGDIR"
LOGFILE="$LOGDIR/verify-$(date +%Y%m%d-%H%M).log"

echo "=== Container Artifact Verification ===" | tee "$LOGFILE"
echo "Log file: $LOGFILE" | tee -a "$LOGFILE"
echo "" | tee -a "$LOGFILE"

# ------------------------------------------------------------
# Import public keys
# ------------------------------------------------------------
echo "[1] Importing public keys..." | tee -a "$LOGFILE"
gpg --import "${KEYDIR}"/* >> "$LOGFILE" 2>&1
echo "    Keys imported." | tee -a "$LOGFILE"
echo "" | tee -a "$LOGFILE"

# ------------------------------------------------------------
# Verify image signatures
# ------------------------------------------------------------
echo "[2] Verifying image signatures..." | tee -a "$LOGFILE"

for sig in "${IMGDIR}"/*.sig; do
    img="${sig%.sig}.tar.gz"
    echo "  - Checking: $(basename "$img")" | tee -a "$LOGFILE"
    if gpg --status-fd 1 --verify "$sig" "$img" >> "$LOGFILE" 2>&1; then
        echo "      ✔ VALID" | tee -a "$LOGFILE"
    else
        echo "      ✘ INVALID" | tee -a "$LOGFILE"
    fi
done

echo "" | tee -a "$LOGFILE"

# ------------------------------------------------------------
# Verify provenance signatures (SBOM, vuln, SCAP, CSV)
# ------------------------------------------------------------
echo "[3] Verifying provenance signatures..." | tee -a "$LOGFILE"

find "$PROVDIR" -type f -name "*.sig" | while read -r sig; do
    base="${sig%.sig}"
    echo "  - Checking: $(basename "$base")" | tee -a "$LOGFILE"
    if gpg --status-fd 1 --verify "$sig" "$base" >> "$LOGFILE" 2>&1; then
        echo "      ✔ VALID" | tee -a "$LOGFILE"
    else
        echo "      ✘ INVALID" | tee -a "$LOGFILE"
    fi
done

echo "" | tee -a "$LOGFILE"

# ------------------------------------------------------------
# Final summary
# ------------------------------------------------------------
echo "=== Verification Complete ===" | tee -a "$LOGFILE"
echo "See log file for full details:" | tee -a "$LOGFILE"
echo "  $LOGFILE" | tee -a "$LOGFILE"
