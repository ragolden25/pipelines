#!/usr/bin/env python3
import os
import re
import sys
import uuid
import yaml
from graphviz import Digraph

# ==========================================================
# CONFIGURATION
# ==========================================================
ROLES_DIR = "/opt/ansible/nucleus/roles"
TARGET_ROLE = "build_grafana_stack" # Replace with your role folder name
OUTPUT_PATH = f"/opt/ansible/files/common/role_{TARGET_ROLE}_architecture"
# ==========================================================

dot = Digraph(name=f"Role_{TARGET_ROLE}", comment=f"Task Flow for Role: {TARGET_ROLE}", format="png")
dot.attr(rankdir="TB")
dot.attr(nodesep="0.5", ranksep="0.8", compound="true")

# Global node and edge aesthetics
dot.attr(
    'node',
    fontname='Helvetica',
    fontsize='10',
    shape='box',
    style='filled,rounded',
    fillcolor='#FFFFFF',
    color='#6B7280'
)
dot.attr('edge', fontname='Helvetica', fontsize='8', color='#4B5563', arrowhead='vee')


def parse_shell_script(script_path, parent_node_id):
    """Crawls shell script for '# STEP:' comments and hangs them vertically beneath the task."""
    if not os.path.exists(script_path):
        return

    steps = []
    with open(script_path, "r", errors='ignore') as f:
        for line in f:
            match = re.search(r"#\s*STEP:\s*(.+)", line)
            if match:
                steps.append(match.group(1).strip())

    if not steps:
        return

    prev_id = parent_node_id
    for idx, step in enumerate(steps):
        step_id = str(uuid.uuid4())
        dot.node(
            step_id,
            label=f"Step {idx + 1}: {step}",
            fillcolor="#D1FAE5",
            color="#10B981",
            fontcolor="#065F46"
        )
        dot.edge(prev_id, step_id, color="#059669", style="dashed", label="executes" if idx == 0 else "")
        prev_id = step_id


def process_subtasks(task_list, base_dir, parent_id):
    """Processes included task files or block tasks in a strict vertical chain under parent."""
    if not isinstance(task_list, list):
        return

    prev_id = parent_id
    for idx, task in enumerate(task_list):
        if not isinstance(task, dict) or not task:
            continue

        task_name = task.get("name", f"Subtask {idx + 1}")
        sub_id = str(uuid.uuid4())

        # Handle nested include_tasks / import_tasks
        if "include_tasks" in task or "import_tasks" in task:
            dot.node(
                sub_id,
                label=f"Include: {task_name}",
                fillcolor="#DBEAFE",
                color="#2563EB",
                fontcolor="#1E40AF",
                fontname="Helvetica-Bold"
            )
            dot.edge(prev_id, sub_id, color="#2563EB")

            inc_file = task.get("include_tasks") or task.get("import_tasks")
            inc_path = inc_file if os.path.isabs(inc_file) else os.path.join(base_dir, inc_file)

            if os.path.exists(inc_path):
                with open(inc_path, "r") as f:
                    try:
                        nested_yaml = yaml.safe_load(f)
                        process_subtasks(nested_yaml, os.path.dirname(inc_path), sub_id)
                    except yaml.YAMLError:
                        pass

        # Handle task blocks
        elif "block" in task:
            dot.node(
                sub_id,
                label=f"Block: {task_name}",
                fillcolor="#F3E8FF",
                color="#9333EA",
                fontcolor="#6B21A8",
                fontname="Helvetica-Bold"
            )
            dot.edge(prev_id, sub_id, color="#9333EA")
            process_subtasks(task["block"], base_dir, sub_id)

        # Standard task node
        else:
            dot.node(sub_id, label=task_name, fillcolor="#F3F4F6", color="#9CA3AF")
            dot.edge(prev_id, sub_id, color="#6B7280")

        prev_id = sub_id

        # Check for shell execution scripts
        for module in ["shell", "command", "ansible.builtin.shell", "ansible.builtin.command"]:
            if module in task:
                mod_content = task[module]
                cmd_str = mod_content.get("cmd", "") if isinstance(mod_content, dict) else str(mod_content)
                match = re.search(r"([\w\-/.]+\.(?:sh|py))", cmd_str)
                if match:
                    raw_path = match.group(1)
                    script_path = raw_path if os.path.isabs(raw_path) else os.path.join(base_dir, raw_path)
                    parse_shell_script(script_path, sub_id)


def parse_role_main(role_name):
    role_tasks_main = os.path.join(ROLES_DIR, role_name, "tasks", "main.yml")
    if not os.path.exists(role_tasks_main):
        role_tasks_main = os.path.join(ROLES_DIR, role_name, "tasks", "main.yaml")

    if not os.path.exists(role_tasks_main):
        print(f"Error: Could not locate tasks/main.yml for role '{role_name}' at {role_tasks_main}")
        sys.exit(1)

    print(f"Parsing main tasks for role [{role_name}]: {role_tasks_main}")
    base_dir = os.path.dirname(role_tasks_main)

    with open(role_tasks_main, "r") as f:
        try:
            main_tasks = yaml.safe_load(f)
        except yaml.YAMLError as e:
            print(f"YAML Parse Error: {e}")
            sys.exit(1)

    if not isinstance(main_tasks, list):
        print("Error: tasks/main.yml must contain a top-level list of tasks.")
        sys.exit(1)

    # Subgraph used strictly to lock top-level main.yml tasks onto a single horizontal rank
    top_spine = Digraph(name="top_spine")
    top_spine.attr(rank="same")

    top_node_ids = []

    for idx, task in enumerate(main_tasks):
        if not isinstance(task, dict) or not task:
            continue

        task_name = task.get("name", f"Main Task {idx + 1}")
        main_id = str(uuid.uuid4())
        top_node_ids.append(main_id)

        # Draw Header Nodes for Main Tasks (Dark Blue Cards)
        dot.node(
            main_id,
            label=f"Main Task {idx + 1}\n{task_name}",
            fillcolor="#1E3A8A",
            fontcolor="#FFFFFF",
            color="#1E40AF",
            shape="box",
            style="filled,rounded",
            fontname="Helvetica-Bold"
        )
        top_spine.node(main_id)

        # 1. Process Included Subtask Files
        if "include_tasks" in task or "import_tasks" in task:
            inc_file = task.get("include_tasks") or task.get("import_tasks")
            inc_path = inc_file if os.path.isabs(inc_file) else os.path.join(base_dir, inc_file)
            if os.path.exists(inc_path):
                with open(inc_path, "r") as f:
                    try:
                        inc_yaml = yaml.safe_load(f)
                        process_subtasks(inc_yaml, os.path.dirname(inc_path), main_id)
                    except yaml.YAMLError:
                        pass

        # 2. Process Blocks
        elif "block" in task:
            process_subtasks(task["block"], base_dir, main_id)

        # 3. Check for direct shell executions on top-level tasks
        for module in ["shell", "command", "ansible.builtin.shell", "ansible.builtin.command"]:
            if module in task:
                mod_content = task[module]
                cmd_str = mod_content.get("cmd", "") if isinstance(mod_content, dict) else str(mod_content)
                match = re.search(r"([\w\-/.]+\.(?:sh|py))", cmd_str)
                if match:
                    raw_path = match.group(1)
                    script_path = raw_path if os.path.isabs(raw_path) else os.path.join(base_dir, raw_path)
                    parse_shell_script(script_path, main_id)

    # Embed the horizontal rank constraint
    dot.subgraph(top_spine)

    # Link top-level main task nodes horizontally left-to-right
    for i in range(len(top_node_ids) - 1):
        dot.edge(
            top_node_ids[i],
            top_node_ids[i + 1],
            color="#2563EB",
            penwidth="2.5",
            constraint="true"
        )


if __name__ == "__main__":
    parse_role_main(TARGET_ROLE)
    dot.render(OUTPUT_PATH, cleanup=True)
    print(f"Role architecture map successfully rendered to:\n{OUTPUT_PATH}.png")

