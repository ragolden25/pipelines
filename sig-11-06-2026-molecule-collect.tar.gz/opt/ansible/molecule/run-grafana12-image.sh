#!/bin/bash
# run-grafana12-image.sh [nucleus|ccop] - image test of the weekly Grafana + Prometheus images (default: nucleus)
# Self-cleaning: on any exit (pass, fail or kill) the scratch folder is emptied and the scenario's
# helper container destroyed. verify.yml's always: block removes the mol-* test containers itself.
export MOL_IMAGE_CLASS="${1:-nucleus}"
source /opt/ansible/molecule/venv/bin/activate
export XDG_CACHE_HOME=/opt/ansible/molecule/cache
SCR=/opt/ansible/molecule/scratch/containers
mkdir -p "$SCR"
# the folder is written by containers (uid 65532), so clean it with a container too
clean() { docker run --rm -v "$SCR":/s "${MOL_BASE_IMAGE:-debian:trixie}" sh -c 'rm -rf /s/* /s/.[!.]* 2>/dev/null; true'; }
cleanup() {
  ( cd /opt/ansible/nucleus/roles/configure_grafana_stack && molecule destroy -s grafana12-image >/dev/null 2>&1 )
  docker rm -f mol-nginx mol-grafana mol-idrac mol-prometheus >/dev/null 2>&1
  docker network rm mol_grafana_net >/dev/null 2>&1
  clean
  true
}
cleanup                                    # start from nothing left by an earlier run
trap cleanup EXIT
cd /opt/ansible/nucleus/roles/configure_grafana_stack || exit 1
LOG=/opt/ansible/molecule/logs/grafana12-image-$MOL_IMAGE_CLASS-$(date +%F-%H%M).log
timeout --kill-after=120 ${MOL_TIMEOUT:-3600} molecule test -s grafana12-image 2>&1 | tee "$LOG"
rc=${PIPESTATUS[0]}
echo "log: $LOG (exit $rc)"
exit $rc
