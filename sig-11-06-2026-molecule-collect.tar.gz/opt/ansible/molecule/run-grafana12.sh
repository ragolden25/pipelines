#!/bin/bash
# run-grafana12.sh - run the grafana12 Molecule scenario; log in /opt/ansible/molecule/logs
# Self-cleaning: the scenario's test container is destroyed on any exit (pass, fail or kill).
# Exits with Molecule's own result, so the dashboard sees real failures.
source /opt/ansible/molecule/venv/bin/activate
export XDG_CACHE_HOME=/opt/ansible/molecule/cache
cd /opt/ansible/nucleus/roles/configure_grafana_stack || exit 1
trap 'molecule destroy -s grafana12 >/dev/null 2>&1; true' EXIT
LOG=/opt/ansible/molecule/logs/grafana12-$(date +%F-%H%M).log
timeout --kill-after=120 ${MOL_TIMEOUT:-3600} molecule test -s grafana12 2>&1 | tee "$LOG"
rc=${PIPESTATUS[0]}
echo "log: $LOG (exit $rc)"
exit $rc
