# Critical Notes on configure_grafana_stack role

## 📂 Purpose
The `configure_grafana_stack` role automates a full containerized monitoring environment using:

Grafana Version: 12.4.11
Prometheus Version: 3.14.0
NGINX Version: 1.31.6

It ensures:

- Datasources are provisioned (`prometheus.yml`)
- Alert rules are UID corrected for datasource mappings
- Dashboards are cleaned, stripped of embedded datasources, UID rewritten, and safely imported
- Plugins and provisioning files are installed with correct ownership/permissions


## ⚙️ Tasks
- Ensure quarter variable is defined
- Ensure log directory exists on control node
- Log start of configure_grafana_stack
- Stop containers
- Remove containers
- Prune volumes
- Prune networks
- Remove container directory
- Recreate container directories with correct UID
- Ensure Grafana plugins provisioning directory exists
- Copy Grafana tarball
- Load Grafana image
- Copy nginx tarball
- Load NGINX image
- Copy prometheus tarball
- Load Prometheus image
- Copy prometheus.yml
- Copy nginx.conf
- Copy mime.types
- Copy options-ssl-nginx.conf
- Copy ssl-dhparams.pem
- Copy server certs
- Copy grafana.conf vhost
- Copy docker-compose.yml
- Create run.sh
- Create stop.sh
- Configure Docker External Firewall by port
- Render grafana.ini
- Start containers
- Copy Grafana plugins tarball
- Extract Grafana plugins
- Remove Grafana plugins tarball
- Copy Prometheus datasource
- Restart Grafana container so that datasources are recognized
- Copy alert rules
- Ensure alert rules owned by grafana user
- Ensure cleaned dashboards directory exists
- Copy raw dashboards to Grafana host clean dir
- Strip id, version, and uid from dashboards
- Ensure dashboards owned by grafana user
- Rewrite Prometheus alert rule datasources to ds-prometheus
- Clean dashboard JSONs for Grafana import
- Rewrite Prometheus dashboard datasource UIDs to ds-prometheus
- Rewrite dashboard titles
- Copy Grafana notification policies
- Copy Grafana contact points
- Copy Grafana dashboard default pointer file
- Ensure Grafana provisioning directories and files owned by grafana
- Restart Grafana container

## 📌 Requirements
- Ansible control node
- Target host connectivity

## 📖 Notes
- Removed influxdb and telegraf because no hardened image available
- Migrated stack to images from Docker Hardened Images (DHI)
- Images updated automatically each quarter via build_grafana_release role

## 🚀 Usage
```yaml
- hosts: configure_grafana_stack
  roles:
    - configure_grafana_stack
```
