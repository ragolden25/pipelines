# configure_guacamole Role

## 📂 Purpose
PRODUCTION USE FOR AUTOMATED DEPLOYMENTS on RHEL8 clients.
Automates configuration for configure_guacamole role.

## ⚙️ Tasks
- Stop all containers
- Remove all containers
- Remove all Docker images
- Remove all Docker volumes
- Remove all Docker networks except defaults
- Remove runtime container directories
- Ensure containers directory exists
- Ensure images directory exists
- Ensure dockerfiles directory exists
- Ensure compose directory exists
- Copy docker-compose.yml
- Create run.sh
- Create stop.sh
- Ensure Guacamole directories exist
- Ensure Postgres directory exists
- Ensure Nginx directories exist
- Create DHI-style nginx temp directories
- Generate DH params file
- Fix Guacamole permissions
- Fix Postgres permissions
- Copy postgresql.conf
- Copy pg_hba.conf
- Fix Nginx permissions
- Copy nginx.conf
- Ensure ssl-dhparams.pem readable by nginx
- Copy mime.types
- Copy guacamole.conf
- Copy cert
- Copy certificate key
- Find nucleus images in avocado files
- Copy nucleus images to target host
- Ensure gpgkeys directory exists
- Copy GPG public key
- Import GPG public key
- Find nucleus signature files
- Copy nucleus signature files to target host
- Verify GPG signatures for all nucleus images
- Fail if any image signature verification failed
- Find hardened nucleus images
- Fail if no nucleus images found
- Load ALL verified nucleus images
- Ensure Guacamole directories exist
- Copy base Guacamole schema
- Copy admin user schema
- Copy Guacamole JDBC extension
- Copy PostgreSQL JDBC driver
- Copy guacamole.properties
- Set ownership for Guacamole directory
- Ensure fonts directory exists for guacd
- Copy DejaVuSansMono.ttf for guacd
- Ensure firewalld Python bindings are installed
- Ensure firewalld is installed
- Ensure firewalld is running
- Allow HTTP/HTTPS
- Add Guacamole-related ports
- Stop existing stack
- Start Postgres service only
- Wait for Postgres to be ready
- Set postgres superuser password
- Create guacuser role
- Create Guacamole database
- Grant privileges on database
- Import base Guacamole schema (001-create-schema.sql)
- Import admin user schema (002-create-admin-user.sql)
- Start full Guacamole stack
- Deploy Docker hardened checks script
- Copy hardened dockerfiles for evaluation by CIS scripts
- reload firewalld

## 📌 Requirements
- Ansible control node
- Target host connectivity

## 📖 Notes
- Generated automatically from tasks.

## 🚀 Usage
```yaml
- hosts: configure_guacamole
  roles:
    - configure_guacamole
```
