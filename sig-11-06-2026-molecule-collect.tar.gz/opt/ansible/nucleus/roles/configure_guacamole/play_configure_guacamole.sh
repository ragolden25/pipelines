#!/bin/bash

ansible-playbook -i /home/ansible/inventory.ini configure_guacamole.yml --vault-password-file ~/vault_pass.txt
