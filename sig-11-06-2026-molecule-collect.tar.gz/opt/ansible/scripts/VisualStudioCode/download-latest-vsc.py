#!/usr/bin/env python3

import requests
import re
import os
import json

BASE_DIR = "/opt/ansible/scripts/VisualStudioCode"

DOWNLOAD_URL = (
    "https://update.code.visualstudio.com/latest/win32-x64/stable"
    "?build=stable&os=win32-x64&format=msi"
)

METADATA_URL = "https://update.code.visualstudio.com/api/update/win32-x64/stable/latest"


def get_filename_from_headers(headers):
    cd = headers.get("Content-Disposition", "")
    match = re.search(r"filename\*\s*=\s*UTF-8''([^;]+)", cd)
    if match:
        return match.group(1).strip().strip('"')
    match = re.search(r'filename="?([^";]+)"?', cd)
    if match:
        return match.group(1).strip()
    return "VSCodeSetup-x64.msi"


def main():
    # Fetch metadata
    r = requests.get(METADATA_URL)
    r.raise_for_status()
    metadata = r.json()

    version = metadata.get("productVersion")
    commit_id = metadata.get("version")

    if not version or not commit_id:
        raise SystemExit("Could not extract version or commit ID from metadata")

    version_dir = os.path.join(BASE_DIR, "versions", version)
    metadata_dir = os.path.join(version_dir, "metadata")

    os.makedirs(metadata_dir, exist_ok=True)

    # Save metadata.json
    metadata_path = os.path.join(metadata_dir, "metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)

    # Save commit.txt
    with open(os.path.join(metadata_dir, "commit.txt"), "w") as f:
        f.write(commit_id)

    # Download MSI
    r = requests.get(DOWNLOAD_URL, stream=True)
    r.raise_for_status()

    # Normalize filename for consistency
    filename = "VSCodeSetup-x64.exe"
    save_path = os.path.join(version_dir, filename)

    with open(save_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)

    print(f"Downloaded VS Code {version} (commit {commit_id})")
    print(f"Saved MSI: {save_path}")


if __name__ == "__main__":
    main()
