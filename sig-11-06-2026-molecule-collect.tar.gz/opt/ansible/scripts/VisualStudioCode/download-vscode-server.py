#!/usr/bin/env python3

import os
import json
import requests

BASE_DIR = "/opt/ansible/scripts/VisualStudioCode"


def download_file(url, dest):
    r = requests.get(url, stream=True)
    r.raise_for_status()
    with open(dest, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)
    print(f"Saved: {dest}")


def main():
    versions_dir = os.path.join(BASE_DIR, "versions")
    versions = sorted(os.listdir(versions_dir))
    if not versions:
        raise SystemExit("No version folders found. Run download-latest-vsc.py first.")

    version = versions[-1]
    version_dir = os.path.join(versions_dir, version)
    metadata_dir = os.path.join(version_dir, "metadata")

    commit_path = os.path.join(metadata_dir, "commit.txt")
    if not os.path.exists(commit_path):
        raise SystemExit("commit.txt missing. Run download-latest-vsc.py first.")

    commit_id = open(commit_path).read().strip()

    # Download server tarball
    url = f"https://update.code.visualstudio.com/commit:{commit_id}/server-linux-x64/stable"
    tarball_path = os.path.join(version_dir, "vscode-server-linux-x64.tar.gz")

    print(f"Downloading VS Code Server for commit {commit_id}")
    download_file(url, tarball_path)


if __name__ == "__main__":
    main()
