#!/bin/bash
set -e

BASE="/opt/ansible/scripts/VisualStudioCode"

echo "=== Running VS Code Offline Build Pipeline ==="

echo "[1/4] Downloading latest VS Code metadata + MSI..."
python3 "$BASE/download-latest-vsc.py"

echo "[2/4] Downloading VS Code Server + PowerShell extension..."
python3 "$BASE/download-vscode-server.py"

echo "[3/4] Downloading all Linux extensions..."
python3 "$BASE/vsc-download-extensions.py"

echo "[4/4] Exporting version folder..."
python3 "$BASE/export-version.py"

echo ""
echo "=== Pipeline Complete ==="
echo "Your export ZIP is ready in:"
ls -1 "$BASE"/*.zip
