#!/usr/bin/env python3

import os
import json
import requests

BASE_DIR = "/opt/ansible/scripts/VisualStudioCode"

# These are the correct extension IDs
EXTENSIONS = [
    "ms-vscode-remote.remote-ssh",
    "redhat.vscode-yaml",
    "redhat.ansible",
    "eamodio.gitlens",
    "vscodevim.vim",
    "ms-vscode.powershell",
    "ms-python.python",
    "ms-python.vscode-pylance"
]

TARGET_PLATFORM = "linux-x64"

API_URL = "https://marketplace.visualstudio.com/_apis/public/gallery/extensionquery"
HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json;api-version=7.1-preview.1"
}


def get_latest_version(publisher, extension):
    payload = {
        "filters": [{
            "criteria": [
                {"filterType": 7, "value": f"{publisher}.{extension}"}
            ]
        }],
        "flags": 914
    }

    r = requests.post(API_URL, headers=HEADERS, data=json.dumps(payload))
    r.raise_for_status()
    data = r.json()

    versions = data["results"][0]["extensions"][0]["versions"]
    return versions[0]["version"]


def try_download(url, dest):
    r = requests.get(url, stream=True)
    if r.status_code != 200:
        return False

    with open(dest, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            f.write(chunk)

    print(f"Saved: {dest}")
    return True


def download_vsix(publisher, extension, version, dest):
    base = (
        f"https://marketplace.visualstudio.com/_apis/public/gallery/"
        f"publishers/{publisher}/vsextensions/{extension}/{version}/vspackage"
    )

    # 1. Try platform-specific
    url_platform = f"{base}?targetPlatform={TARGET_PLATFORM}"
    if try_download(url_platform, dest):
        return

    # 2. Try universal package
    if try_download(base, dest):
        return

    raise Exception(f"Could not download {publisher}.{extension} version {version}")


def main():
    versions_dir = os.path.join(BASE_DIR, "versions")
    versions = sorted(os.listdir(versions_dir))
    if not versions:
        raise SystemExit("No version folders found. Run download-latest-vsc.py first.")

    version = versions[-1]
    version_dir = os.path.join(versions_dir, version)

    ext_dir = os.path.join(version_dir, "extensions")
    os.makedirs(ext_dir, exist_ok=True)

    # NEW STRUCTURE:
    # - extension_ids.json → maps extension → extension ID
    # - extension_versions.json → maps extension → version
    extension_ids = {}
    extension_versions = {}

    for ext in EXTENSIONS:
        publisher, extension = ext.split(".")
        print(f"\n=== Downloading {publisher}.{extension} ===")

        ver = get_latest_version(publisher, extension)
        filename = f"{publisher}.{extension}-{ver}.vsix"
        dest = os.path.join(ext_dir, filename)

        download_vsix(publisher, extension, ver, dest)

        # Store ID and version separately
        extension_ids[ext] = ext
        extension_versions[ext] = ver

    # Save metadata
    metadata_dir = os.path.join(version_dir, "metadata")
    os.makedirs(metadata_dir, exist_ok=True)

    # This is the file your manifest generator reads
    with open(os.path.join(metadata_dir, "extensions.json"), "w") as f:
        json.dump(extension_ids, f, indent=2)

    # Optional: keep versions for reproducibility
    with open(os.path.join(metadata_dir, "extension_versions.json"), "w") as f:
        json.dump(extension_versions, f, indent=2)

    print("\nExtension metadata saved.")


if __name__ == "__main__":
    main()
