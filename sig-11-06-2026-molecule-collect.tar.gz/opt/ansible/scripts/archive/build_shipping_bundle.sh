#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Shipping Bundle Builder (Flat .xz Artifacts)
# Quarter: fy26q4
# =====================================================================

DATE="$(date +%d%b%Y | tr '[:upper:]' '[:lower:]')"   # e.g., 22jul2026
SHIP_DIR="/opt/ansible/shipping/${DATE}"
IMG_SRC="/opt/ansible/files/avocado/fy26q4/images"
ROLE_ROOT="/opt/ansible/nucleus/roles"
SCRIPT_ROOT="/opt/ansible/scripts"

mkdir -p "${SHIP_DIR}"

INVENTORY="${SHIP_DIR}/inventory.txt"
echo "Inventory of file transfers on ${DATE}" > "${INVENTORY}"
echo "" >> "${INVENTORY}"

# =====================================================================
# Helper: write inventory entry
# =====================================================================
add_inventory() {
    local file="$1"
    local src="$2"
    local dest="$3"
    local size
    size=$(du -h "${file}" | awk '{print $1}')

    echo "${file##*/} (${size})" >> "${INVENTORY}"
    echo "  source: ${src}" >> "${INVENTORY}"
    echo "  dest:   ${dest}" >> "${INVENTORY}"
    echo "" >> "${INVENTORY}"
}

# =====================================================================
# 1. Group nucleus images → nucleus-images.tar.xz
# =====================================================================

NUCLEUS_TAR="${SHIP_DIR}/nucleus-images.tar"

echo "==> Creating nucleus-images.tar"
tar -C "${IMG_SRC}" -cf "${NUCLEUS_TAR}" $IMG_SRC/nucleus-*.tar.gz

echo "==> Compressing nucleus-images.tar"
xz -T0 -9e "${NUCLEUS_TAR}"

add_inventory "${NUCLEUS_TAR}.xz" "${IMG_SRC}/nucleus-*.tar.gz" "/opt/ansible/files/avocado/fy26q4/images"

# =====================================================================
# 2. Group ccop images → ccop-images.tar.xz
# =====================================================================

CCOP_TAR="${SHIP_DIR}/ccop-images.tar"

echo "==> Creating ccop-images.tar"
tar -C "${IMG_SRC}" -cf "${CCOP_TAR}" $IMG_SRC/ccop-*.tar.gz

echo "==> Compressing ccop-images.tar"
xz -T0 -9e "${CCOP_TAR}"

add_inventory "${CCOP_TAR}.xz" "${IMG_SRC}/ccop-*.tar.gz" "/opt/ansible/files/avocado/fy26q4/images"

# =====================================================================
# 3. Compress debian13-base-latest.tar.gz → .xz
# =====================================================================

DEBIAN_SRC="${IMG_SRC}/debian13-base-latest.tar.gz"
DEBIAN_OUT="${SHIP_DIR}/debian13-base-latest.tar.gz.xz"

echo "==> Compressing debian13-base-latest.tar.gz"
xz -T0 -9e -c "${DEBIAN_SRC}" > "${DEBIAN_OUT}"

add_inventory "${DEBIAN_OUT}" "${DEBIAN_SRC}" "/opt/ansible/files/avocado/fy26q4/images"

# =====================================================================
# 4. Compress configure_guacamole role → .tar.xz
# =====================================================================

CFG_ROLE="configure_guacamole"
CFG_SRC="${ROLE_ROOT}/${CFG_ROLE}"
CFG_OUT="${SHIP_DIR}/${CFG_ROLE}.tar.xz"

echo "==> Compressing role: ${CFG_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${CFG_ROLE}" | xz -T0 -9e > "${CFG_OUT}"

add_inventory "${CFG_OUT}" "${CFG_SRC}" "/opt/ansible/nucleus/roles"

# =====================================================================
# 5. Compress install_docker_python role → .tar.xz
# =====================================================================

IDP_ROLE="install_docker_python"
IDP_SRC="${ROLE_ROOT}/${IDP_ROLE}"
IDP_OUT="${SHIP_DIR}/${IDP_ROLE}.tar.xz"

echo "==> Compressing role: ${IDP_ROLE}"
tar -C "${ROLE_ROOT}" -cf - "${IDP_ROLE}" | xz -T0 -9e > "${IDP_OUT}"

add_inventory "${IDP_OUT}" "${IDP_SRC}" "/opt/ansible/nucleus/roles"

# =====================================================================
# 6. Scan install_docker_python for external referenced directories
# =====================================================================

scan_install_docker_python_files() {
    local role="install_docker_python"
    local role_dir="${ROLE_ROOT}/${role}"
    local out_dir="${SHIP_DIR}"

    echo "==> Scanning install_docker_python for external referenced directories"

    mapfile -t refs < <(
        grep -RhoE 'src: *[^ ]+|template: *[^ ]+|/opt/ansible/files/[^ ]+' \
            "${role_dir}/tasks" 2>/dev/null \
        | sed -E 's/.*src: *//; s/.*template: *//'
    )

    declare -A dirs_to_ship=()

    for ref in "${refs[@]}"; do
        local f

        if [[ "${ref}" == /* ]]; then
            f="${ref}"
        else
            f="${role_dir}/${ref}"
        fi

        if [[ "${f}" == "${role_dir}"/* ]]; then
            continue
        fi

        if [[ -f "${f}" ]]; then
            local parent
            parent="$(dirname "${f}")"
            dirs_to_ship["${parent}"]=1
        fi
    done

    for d in "${!dirs_to_ship[@]}"; do
        local base="$(basename "${d}")"
        local out="${out_dir}/${role}-${base}.tar.xz"

        echo "==> Shipping external directory: ${d}"
        tar -C "$(dirname "${d}")" -cf - "${base}" | xz -T0 -9e > "${out}"

        add_inventory "${out}" "${d}" "/opt/ansible/files"
    done
}

scan_install_docker_python_files

# =====================================================================
# 7. Optional: include cis_docker.zip
# =====================================================================

CIS_ZIP="${SCRIPT_ROOT}/cis_docker.zip"
if [[ -f "${CIS_ZIP}" ]]; then
    echo "==> Including cis_docker.zip"
    cp "${CIS_ZIP}" "${SHIP_DIR}/cis_docker.zip"
    add_inventory "${SHIP_DIR}/cis_docker.zip" "${CIS_ZIP}" "/opt/ansible/scripts"
fi

# =====================================================================
# Summary
# =====================================================================

echo ""
echo "=============================================================="
echo "Shipping bundle created:"
echo "  ${SHIP_DIR}"
echo ""
echo "Files included:"
ls -lh "${SHIP_DIR}"
echo ""
echo "Inventory written to:"
echo "  ${INVENTORY}"
echo "=============================================================="
