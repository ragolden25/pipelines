#!/usr/bin/env python3

import os, yaml, argparse, shutil, logging
from datetime import datetime

SECTION_SYMBOLS = {
    "purpose": "📂",
    "tasks": "⚙️",
    "requirements": "📌",
    "verification": "✅",
    "notes": "📖",
    "usage": "🚀"
}

# Configure logging with DTG
dtg = datetime.now().strftime("%Y%m%d_%H%M%S")
logfile = f"generate_readmes_{dtg}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(logfile),
        logging.StreamHandler()
    ]
)

def is_generic_readme(path):
    """Detect ansible-galaxy init boilerplate README.md"""
    with open(path) as f:
        content = f.read()
    generic_markers = [
        "Role Name",
        "A brief description of the role goes here.",
        "Requirements",
        "Role Variables",
        "Dependencies",
        "Example Playbook",
        "License",
        "Author Information"
    ]
    return any(marker in content for marker in generic_markers)

def format_readme(sections, output_file):
    lines = [f"# {sections.get('title','README')}\n\n"]
    for key in ["purpose","tasks","requirements","verification","notes","usage"]:
        if key not in sections:
            continue
        symbol = SECTION_SYMBOLS.get(key,"")
        header = key.capitalize()
        lines.append(f"## {symbol} {header}\n")
        content = sections[key]
        if isinstance(content,list):
            for item in content:
                if key=="verification" and isinstance(item,str) and item.startswith("bash:"):
                    cmd=item.replace("bash:","").strip()
                    lines.append("```bash\n"+cmd+"\n```\n")
                elif key=="usage":
                    lines.append("```yaml\n"+item.strip()+"\n```\n")
                else:
                    lines.append(f"- {item}\n")
        elif isinstance(content,dict):
            # Render dicts as bullet list
            for k,v in content.items():
                lines.append(f"- {k}: {v}\n")
        else:
            if key=="usage":
                lines.append("```yaml\n"+str(content).strip()+"\n```\n")
            else:
                lines.append(str(content)+"\n")
        lines.append("\n")
    with open(output_file,"w") as f:
        f.writelines(lines)

def archive_readme(role_path, readme_file):
    archive_dir = os.path.join(role_path, "archive")
    os.makedirs(archive_dir, exist_ok=True)
    shutil.move(readme_file, os.path.join(archive_dir, "README.md.bak"))
    logging.info(f"Archived existing README.md for {os.path.basename(role_path)}")

def evaluate_readme(readme_file, task_names):
    """Check if README.md contains all task names and flag extras"""
    if not os.path.exists(readme_file):
        return False
    with open(readme_file) as f:
        content = f.read()
    missing = [t for t in task_names if t and t not in content]
    extras = []
    for line in content.splitlines():
        if line.strip().startswith("- "):
            candidate = line.strip()[2:]
            if candidate and candidate not in task_names:
                extras.append(candidate)
    if missing:
        logging.warning(f"README.md missing {len(missing)} tasks: {missing}")
    if extras:
        logging.warning(f"README.md has {len(extras)} extra tasks not in main.yml: {extras}")
    if not missing and not extras:
        logging.info(f"README.md matches all {len(task_names)} tasks")
        return True
    return False

def scan_roles(base_dir="/opt/ansible/nucleus/roles"):
    # unchanged from your original
    ...

def process_yaml_file(yaml_file, output_file="README.md"):
    """Generate README.md from a standalone YAML file (dict or list)"""
    try:
        with open(yaml_file) as f:
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError as e:
        logging.error(f"Failed to parse {yaml_file} ({e})")
        return

    if isinstance(data, dict):
        # Rich format with sections
        sections = {}
        for key in ["title","purpose","requirements","tasks","verification","notes","usage"]:
            if key in data:
                sections[key] = data[key]
        logging.info(f"Generating README.md from structured YAML {yaml_file}")
        format_readme(sections, output_file)

    elif isinstance(data, list):
        # Standard Ansible tasks list
        task_names = [t.get("name") for t in data if isinstance(t, dict) and "name" in t]
        sections = {
            "title": f"{os.path.basename(yaml_file)} Tasks",
            "purpose": f"Generated README from {yaml_file}.",
            "tasks": task_names,
            "requirements": ["Ansible control node", "Target host connectivity"],
            "notes": ["Generated automatically from tasks."],
            "usage": f"- hosts: all\n  tasks:\n    - include_tasks: {yaml_file}"
        }
        logging.info(f"Generating README.md from task list {yaml_file}")
        format_readme(sections, output_file)
        if task_names:
            evaluate_readme(output_file, task_names)

if __name__=="__main__":
    parser = argparse.ArgumentParser(description="Generate README.md files for Ansible roles or a single YAML file")
    parser.add_argument("--base-dir", default="/opt/ansible/nucleus/roles",
                        help="Base directory containing Ansible roles")
    parser.add_argument("--yaml-file", help="Generate README.md from a single YAML tasks file")
    parser.add_argument("--output", default="README.md", help="Output README file name")
    args = parser.parse_args()

    if args.yaml_file:
        process_yaml_file(args.yaml_file, args.output)
    else:
        scan_roles(args.base_dir)
