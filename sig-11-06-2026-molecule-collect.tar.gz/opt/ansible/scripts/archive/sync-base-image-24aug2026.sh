#!/bin/bash

set -euo pipefail
umask 022

SERVER_BASE_URL="http://container-forge/images"
WORKDIR="/opt/ansible/tmp"

# Ensure temp workspace exists
mkdir -p "$WORKDIR"

# Determine current quarter
QUARTER_INFO=$(/opt/ansible/files/common/scripts/determine_quarters.sh)
CURRENT_QUARTER=$(echo "$QUARTER_INFO" | grep '^quarter=' | cut -d= -f2)

IMG_DIR="/opt/ansible/files/avocado/${CURRENT_QUARTER}/images"
IMG2_DIR="/opt/ansible/files/grafana/${CURRENT_QUARTER}/images"
PROV_DIR="/opt/ansible/files/avocado/${CURRENT_QUARTER}/provenance"
GRAF_DIR="/opt/ansible/files/grafana/${CURRENT_QUARTER}/provenance"

DF_AVO_DIR="/opt/ansible/files/avocado/${CURRENT_QUARTER}/dockerfiles"
DF_GRAF_DIR="/opt/ansible/files/grafana/${CURRENT_QUARTER}/dockerfiles"

mkdir -p "$IMG_DIR" "$IMG2_DIR" \
         "$PROV_DIR/container-forge" "$GRAF_DIR/container-forge" \
         "$DF_AVO_DIR" "$DF_GRAF_DIR"

echo "[$(date)] Determined current quarter: ${CURRENT_QUARTER}"
echo "[$(date)] Image directory: ${IMG_DIR}"
echo "[$(date)] Provenance directory: ${PROV_DIR}"
echo "[$(date)] Workspace directory: ${WORKDIR}"

# Verify GPG keyring before processing
if ! gpg --list-keys "container-forge" >/dev/null 2>&1; then
    echo "[ERROR] container-forge public key not imported into GPG keyring."
    exit 1
fi

# Format: SUBDIR|TAR_PREFIX|DOCKERFILE_NAME|IMAGE_NAME
TARGETS=(
    "debian13-base|debian13-base-latest|Dockerfile.debian13.slim|container-forge/debian13-slim"
    "debian13-go|debian13-go-latest|Dockerfile.debian13.go|container-forge/debian13-go"
    "debian13-node20|debian13-node20-latest|Dockerfile.debian13.node20|container-forge/debian13-node20"
    "debian13-node22|debian13-node22-latest|Dockerfile.debian13.node22|container-forge/debian13-node22"
    "debian13-distroless|debian13-distroless-latest|Dockerfile.debian13.distroless|container-forge/debian13-distroless"
)

for TARGET in "${TARGETS[@]}"; do
    IFS="|" read -r SUBDIR TAR_PREFIX DF_NAME IMG_NAME <<< "$TARGET"

    echo "========================================================="
    echo "[$(date)] Processing target image: ${SUBDIR}"
    echo "========================================================="

    BASE_URL="${SERVER_BASE_URL}/${SUBDIR}"

    IMAGE_URL="${BASE_URL}/${TAR_PREFIX}.tar.gz"
    TAR_SIG_URL="${BASE_URL}/${TAR_PREFIX}.tar.gz.asc"
    DIGEST_SIG_URL="${BASE_URL}/digest-latest.digest.asc"

    if ! wget -q --spider "${DIGEST_SIG_URL}"; then
        DIGEST_SIG_URL="${BASE_URL}/${SUBDIR}-latest.digest.asc"
        [[ "$SUBDIR" == "debian13-go" ]] && DIGEST_SIG_URL="${BASE_URL}/debian13-go-latest.digest.asc"
        [[ "$SUBDIR" == "debian13-node20" ]] && DIGEST_SIG_URL="${BASE_URL}/debian13-node20-latest.digest.asc"
        [[ "$SUBDIR" == "debian13-node22" ]] && DIGEST_SIG_URL="${BASE_URL}/debian13-node22-latest.digest.asc"
        [[ "$SUBDIR" == "debian13-distroless" ]] && DIGEST_SIG_URL="${BASE_URL}/debian13-distroless-latest.digest.asc"
    fi

    DIGEST_URL="${BASE_URL}/digest-latest.txt"
    DOCKERFILE_URL="${BASE_URL}/${DF_NAME}"

    TMP_IMG="${WORKDIR}/${TAR_PREFIX}.tar.gz"
    TMP_TAR_SIG="${WORKDIR}/${TAR_PREFIX}.tar.gz.asc"
    TMP_DIGEST_SIG="${WORKDIR}/${SUBDIR}-latest.digest.asc"
    TMP_DIGEST="${WORKDIR}/${SUBDIR}-digest-latest.txt"
    TMP_DOCKERFILE="${WORKDIR}/${DF_NAME}"

    echo "[$(date)] Downloading artifacts for ${SUBDIR}..."
    wget -q -O "$TMP_IMG" "$IMAGE_URL"
    wget -q -O "$TMP_TAR_SIG" "$TAR_SIG_URL"
    wget -q -O "$TMP_DIGEST_SIG" "$DIGEST_SIG_URL"
    wget -q -O "$TMP_DIGEST" "$DIGEST_URL"
    wget -q -O "$TMP_DOCKERFILE" "$DOCKERFILE_URL"

    chmod 644 "$TMP_IMG" "$TMP_TAR_SIG" "$TMP_DIGEST_SIG" "$TMP_DIGEST" "$TMP_DOCKERFILE"

    echo "[$(date)] Verifying tarball signature for ${SUBDIR}..."
    gpg --verify "$TMP_TAR_SIG" "$TMP_IMG"

    echo "[$(date)] Verifying digest signature for ${SUBDIR}..."
    gpg --verify "$TMP_DIGEST_SIG" "$TMP_DIGEST"

    echo "[$(date)] Verifying digest matches downloaded tarball..."
    ACTUAL_DIGEST=$(sha256sum "$TMP_IMG" | awk '{print $1}')
    EXPECTED_DIGEST=$(cat "$TMP_DIGEST")

    if [[ "$ACTUAL_DIGEST" != "$EXPECTED_DIGEST" ]]; then
        echo "[ERROR] Digest mismatch on ${SUBDIR} — refusing to load image."
        exit 1
    fi

    echo "[$(date)] All GPG + digest checks passed for ${SUBDIR}."

    VERIFY_LOG="${PROV_DIR}/verify-${SUBDIR}-latest.log"

    {
        echo "Verification Timestamp: $(date)"
        echo "Target Image: $SUBDIR"
        echo "Verified Image File: $TMP_IMG"
        echo "Verified Tarball Signature: $TMP_TAR_SIG"
        echo "Verified Digest Signature: $TMP_DIGEST_SIG"
        echo "Verified Digest File: $TMP_DIGEST"
        echo
        echo "Container-FORGE Key Fingerprint:"
        gpg --fingerprint "container-forge"
        echo
        echo "Digest Expected: $EXPECTED_DIGEST"
        echo "Digest Actual: $ACTUAL_DIGEST"
        echo
        echo "Result: VERIFIED OK"
    } | tee "$VERIFY_LOG"

    chown ansible:ansible "$VERIFY_LOG"
    chmod 644 "$VERIFY_LOG"

    cp "$VERIFY_LOG" "${GRAF_DIR}/verify-${SUBDIR}-latest.log"

    echo "[$(date)] Loading ${IMG_NAME}:latest into local Docker host..."
    docker load -i "$TMP_IMG"
    docker tag "${IMG_NAME}:latest" "${IMG_NAME}:protected"

    echo "[$(date)] Tagged ${IMG_NAME}:protected successfully."

    cp "$TMP_IMG" "$IMG_DIR/"
    cp "$TMP_IMG" "$IMG2_DIR/"

    cp "$TMP_TAR_SIG" "$PROV_DIR/container-forge/"
    cp "$TMP_DIGEST_SIG" "$PROV_DIR/container-forge/"
    cp "$TMP_DIGEST" "$PROV_DIR/container-forge/"

    cp "$TMP_TAR_SIG" "$GRAF_DIR/container-forge/"
    cp "$TMP_DIGEST_SIG" "$GRAF_DIR/container-forge/"
    cp "$TMP_DIGEST" "$GRAF_DIR/container-forge/"

    cp "$TMP_DOCKERFILE" "$DF_AVO_DIR/$DF_NAME"
    cp "$TMP_DOCKERFILE" "$DF_GRAF_DIR/$DF_NAME"

    chown -R ansible:ansible "$DF_AVO_DIR/$DF_NAME" "$DF_GRAF_DIR/$DF_NAME"

    rm -f "$TMP_IMG" "$TMP_TAR_SIG" "$TMP_DIGEST_SIG" "$TMP_DIGEST" "$TMP_DOCKERFILE"

    echo "[$(date)] Successfully processed and delivered ${SUBDIR}."
done

echo "========================================================="
echo "[$(date)] Full sync completed for debian13-base, debian13-go, debian13-node20, debian13-node22, and debian13-distroless."
echo "========================================================="
