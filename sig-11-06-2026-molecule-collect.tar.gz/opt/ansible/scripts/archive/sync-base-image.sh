#!/bin/bash

set -euo pipefail
umask 022

BASE_URL="http://container-forge/images/debian13-base"

IMAGE_URL="$BASE_URL/debian13-base-latest.tar.gz"
TAR_SIG_URL="$BASE_URL/debian13-base-latest.tar.gz.asc"
DIGEST_SIG_URL="$BASE_URL/debian13-base-latest.digest.asc"
DIGEST_URL="$BASE_URL/digest-latest.txt"

WORKDIR="/opt/ansible/tmp"

TMP_IMG="${WORKDIR}/debian13-base-latest.tar.gz"
TMP_TAR_SIG="${WORKDIR}/debian13-base-latest.tar.gz.asc"
TMP_DIGEST_SIG="${WORKDIR}/debian13-base-latest.digest.asc"
TMP_DIGEST="${WORKDIR}/digest-latest.txt"

# NEW: Dockerfile pull
DOCKERFILE_URL="http://192.168.110.214/images/debian13-base/Dockerfile"
TMP_DOCKERFILE="${WORKDIR}/Dockerfile.debian13-base"

# Ensure workspace exists
mkdir -p "$WORKDIR"

# Determine current quarter
QUARTER_INFO=$(/opt/ansible/files/common/scripts/determine_quarters.sh)
CURRENT_QUARTER=$(echo "$QUARTER_INFO" | grep '^quarter=' | cut -d= -f2)

IMG_DIR="/opt/ansible/files/avocado/${CURRENT_QUARTER}/images"
IMG2_DIR="/opt/ansible/files/grafana/${CURRENT_QUARTER}/images"
PROV_DIR="/opt/ansible/files/avocado/${CURRENT_QUARTER}/provenance"
GRAF_DIR="/opt/ansible/files/grafana/${CURRENT_QUARTER}/provenance"

# NEW: Dockerfile directories
DF_AVO_DIR="/opt/ansible/files/avocado/${CURRENT_QUARTER}/dockerfiles"
DF_GRAF_DIR="/opt/ansible/files/grafana/${CURRENT_QUARTER}/dockerfiles"

mkdir -p "$IMG_DIR" "$IMG2_DIR" "$PROV_DIR" "$GRAF_DIR" "$DF_AVO_DIR" "$DF_GRAF_DIR"

echo "[$(date)] Determined current quarter: ${CURRENT_QUARTER}"
echo "[$(date)] Image directory: ${IMG_DIR}"
echo "[$(date)] Provenance directory: ${PROV_DIR}"
echo "[$(date)] Workspace directory: ${WORKDIR}"

# ---------------------------------------------------------
# DOWNLOAD IMAGE + SIGNATURES
# ---------------------------------------------------------

wget -q -O "$TMP_IMG"        "$IMAGE_URL"
wget -q -O "$TMP_TAR_SIG"    "$TAR_SIG_URL"
wget -q -O "$TMP_DIGEST_SIG" "$DIGEST_SIG_URL"
wget -q -O "$TMP_DIGEST"     "$DIGEST_URL"

chmod 644 "$TMP_IMG" "$TMP_TAR_SIG" "$TMP_DIGEST_SIG" "$TMP_DIGEST"

echo "[$(date)] Downloaded base image + all signature files."

# ---------------------------------------------------------
# GPG VERIFICATION
# ---------------------------------------------------------

if ! gpg --list-keys "container-forge" >/dev/null 2>&1; then
    echo "[ERROR] container-forge public key not imported."
    exit 1
fi

echo "[$(date)] Verifying tarball signature..."
gpg --verify "$TMP_TAR_SIG" "$TMP_IMG"

echo "[$(date)] Verifying digest signature..."
gpg --verify "$TMP_DIGEST_SIG" "$TMP_DIGEST"

echo "[$(date)] Verifying digest matches tarball..."
ACTUAL_DIGEST=$(sha256sum "$TMP_IMG" | awk '{print $1}')
EXPECTED_DIGEST=$(cat "$TMP_DIGEST")

if [[ "$ACTUAL_DIGEST" != "$EXPECTED_DIGEST" ]]; then
    echo "[ERROR] Digest mismatch — refusing to load image."
    exit 1
fi

echo "[$(date)] All GPG + digest checks passed."

# ---------------------------------------------------------
# RECORD VERIFICATION RESULTS
# ---------------------------------------------------------

VERIFY_LOG="${PROV_DIR}/verify-debian13-base-latest.log"

{
    echo "Verification Timestamp: $(date)"
    echo "Verified Image: $TMP_IMG"
    echo "Verified Tarball Signature: $TMP_TAR_SIG"
    echo "Verified Digest Signature: $TMP_DIGEST_SIG"
    echo "Verified Digest File: $TMP_DIGEST"
    echo
    echo "Container-FORGE Key Fingerprint:"
    gpg --fingerprint "container-forge"
    echo
    echo "Digest Expected: $EXPECTED_DIGEST"
    echo "Digest Actual:   $ACTUAL_DIGEST"
    echo
    echo "Result: VERIFIED OK"
} | tee "$VERIFY_LOG"

chown ansible:ansible "$VERIFY_LOG"
chmod 644 "$VERIFY_LOG"

echo "[$(date)] Verification record written to: $VERIFY_LOG"

# ---------------------------------------------------------
# SAFE TO LOAD IMAGE NOW
# ---------------------------------------------------------

docker load -i "$TMP_IMG"
docker tag container-forge/debian13-slim:latest container-forge/debian13-slim:protected

echo "[$(date)] Loaded and tagged protected Debian 13 base image."

# ---------------------------------------------------------
# DELIVER IMAGE ARTIFACTS
# ---------------------------------------------------------

# Guacamole
cp "$TMP_IMG"        "$IMG_DIR/"
cp "$TMP_TAR_SIG"    "$PROV_DIR/container-forge"
cp "$TMP_DIGEST_SIG" "$PROV_DIR/container-forge"
cp "$TMP_DIGEST"     "$PROV_DIR/container-forge"

# Grafana
cp "$TMP_IMG"        "$IMG2_DIR/"
cp "$TMP_TAR_SIG"    "$GRAF_DIR/container-forge"
cp "$TMP_DIGEST_SIG" "$GRAF_DIR/container-forge"
cp "$TMP_DIGEST"     "$GRAF_DIR/container-forge"

echo "[$(date)] Delivered base image + signatures to quarterly directories."

# ---------------------------------------------------------
# NEW: DELIVER DOCKERFILE FOR SAST
# ---------------------------------------------------------

echo "[$(date)] Downloading Debian 13 base Dockerfile for SAST..."
wget -q -O "$TMP_DOCKERFILE" "$DOCKERFILE_URL"
chmod 644 "$TMP_DOCKERFILE"

cp "$TMP_DOCKERFILE" "$DF_AVO_DIR/Dockerfile.debian13.slim"
cp "$TMP_DOCKERFILE" "$DF_GRAF_DIR/Dockerfile.debian13.slim"

chown ansible:ansible "$DF_AVO_DIR/Dockerfile.debian13.slim" "$DF_GRAF_DIR/Dockerfile.debian13.slim"

echo "[$(date)] Delivered Debian 13 slim Dockerfile to SAST directories."

# ---------------------------------------------------------
# CLEANUP
# ---------------------------------------------------------

rm -f "$TMP_IMG" "$TMP_TAR_SIG" "$TMP_DIGEST_SIG" "$TMP_DIGEST" "$TMP_DOCKERFILE"

echo "[$(date)] Sync complete."
