# CIS Docker Benchmark Scanner

## 📂 Purpose
The `cis_docker` project provides a modular, host level compliance scanner
that evaluates a Linux system and its Docker environment against the
CIS Docker Benchmark. The scanner produces a timestamped CSV report
containing PASS/FAIL/NA results, evidence, and a summary header suitable
for IA review and long term archival.

The design mirrors your existing Nomad style compliance tooling:
- predictable output
- no external dependencies
- modular section scripts
- clean CSV for ingestion
- host, image, and runtime inspection


## ⚙️ Tasks
- {'name': 'Section 1 — Linux Host Configuration', 'description': 'Performs host level checks including filesystem layout, group membership,\nand audit rule validation. Uses wrapper functions to ensure compatibility\nwith `set -euo pipefail`. FAIL results indicate missing audit rules that\ncan be remediated via Ansible (e.g., tasks/audits.yml).\n'}
- {'name': 'Section 2 — Docker Daemon Configuration', 'description': 'Inspects daemon settings using `docker info` and configuration files.\nValidates logging drivers, storage drivers, TLS settings, and daemon.json\nparameters. Produces PASS/FAIL/NA based on host configuration.\n'}
- {'name': 'Section 3 — Docker Daemon Filesystem Permissions', 'description': 'Validates ownership and permissions of Docker binaries, configuration\nfiles, and directories. Ensures root ownership and restrictive modes\n(e.g., 600/644). Uses stat based checks with safe fallbacks.\n'}
- {'name': 'Section 4 — Image & Build File Configuration', 'description': 'Performs deep inspection of all local Docker images using:\n  - docker inspect\n  - docker create\n  - docker exec\nIncludes universal OS detection (Debian, RHEL, Alpine, BusyBox, Distroless)\nand checks for:\n  - USER instruction\n  - HEALTHCHECK\n  - setuid/setgid files\n  - unnecessary packages\nNon scriptable CI/CD dependent controls are marked NA.\n'}
- {'name': 'Section 5 — Container Runtime Configuration', 'description': 'Inspects all running containers for runtime security posture:\n  - privileged mode\n  - host network usage\n  - sensitive mounts\n  - memory/CPU limits\n  - read only rootfs\n  - seccomp profile\n  - capabilities\n  - exposed devices\n  - privileged ports\nUses docker inspect and docker exec with safe fallbacks.\n'}
- {'name': 'Section 6 — Docker Operations', 'description': 'Evaluates operational practices such as image sprawl, container sprawl,\nand unused resources. Uses docker CLI queries with NA fallbacks when\nDocker is not installed.\n'}
- {'name': 'Section 7 — Docker Swarm Configuration', 'description': 'Checks Swarm mode status. In environments where Swarm is not used,\nall controls are marked NA with clear justification.\n'}

## 📌 Requirements
- Bash (POSIX compatible)
- Docker Engine installed and running
- auditd installed (for Section 1 PASS results)
- read/exec access to Docker images and containers
- Linux host (Debian, RHEL, Alpine, BusyBox, Distroless supported)

## ✅ Verification
After running the scanner, verify:
  - The CSV file exists in the cis_docker directory
  - The summary header includes PASS/FAIL/NA counts
  - Each section appended rows in the expected format:
      control_id,description,status,evidence
  - No ANSI color codes or formatting artifacts appear in the CSV
  - Section 1 audit checks reflect your Ansible audit rules


## 📖 Notes
- The scanner is intentionally dependency free and does not require Python.
- All checks are host level; no CI/CD pipeline is required.
- Section 4 and 5 include OS aware logic to handle Debian, RHEL, Alpine,
  BusyBox, and Distroless images without breaking under `set -euo pipefail`.
- Section 1 FAIL results can be remediated by adding audit rules to your
  install_docker_python role (e.g., tasks/audits.yml).
- The CSV output is designed for IA ingestion and long term compliance
  tracking.


## 🚀 Usage
```yaml
Run the main orchestrator script:

    ./cis_main.sh

The script:
  - detects the host OS, kernel, Docker version, and hostname
  - runs all section scripts (1–7)
  - aggregates results into a timestamped CSV file:
      docker_cis_report-<hostname>-<YYYYMMDD-HHMM>.csv
  - writes a summary header with PASS/FAIL/NA counts
  - appends all section results in CSV format

No arguments are required. The scanner is intentionally self contained.
```

