#!/usr/bin/env bash

set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- Host metadata ---
HOSTNAME_SHORT=$(hostname 2>/dev/null || echo "unknown-host")
OS_PRETTY_NAME=$(source /etc/os-release 2>/dev/null && echo "${PRETTY_NAME:-Unknown}")
KERNEL_VERSION=$(uname -r)
DOCKER_VERSION=$(docker --version 2>/dev/null || echo "docker not installed")
GENERATED_AT=$(date "+%Y-%m-%d %H:%M:%S %Z")

# --- DTG for filename ---
DTG=$(date "+%Y%m%d-%H%M")
OUTFILE="docker_cis_report-${HOSTNAME_SHORT}-${DTG}.csv"
OUTPATH="${DIR}/${OUTFILE}"

echo "Generating CIS Docker Benchmark report:"
echo "  Host: $HOSTNAME_SHORT"
echo "  File: $OUTPATH"
echo ""

# --- Run all section scripts (they generate their own CSVs) ---
bash "$DIR/section1_linux_host.sh"
bash "$DIR/section2_daemon_config.sh"
bash "$DIR/section3_daemon_files.sh"
bash "$DIR/section4_images.sh"
bash "$DIR/section5_runtime.sh"
bash "$DIR/section6_operations.sh"
bash "$DIR/section7_swarm.sh"

# --- Merge all section CSVs ---
TMPFILE=$(mktemp)

# Write header once
echo "control_id,description,status,evidence" > "$TMPFILE"

# Append each section CSV (skip header rows)
for f in /opt/cis/results/section*.csv; do
    tail -n +2 "$f" >> "$TMPFILE"
done

# --- Compute summary counts (quote-safe) ---
PASS_COUNT=$(awk -F',' 'NR>1 {s=$3; gsub(/"/,"",s); if (s=="PASS") c++} END{print c+0}' "$TMPFILE")
FAIL_COUNT=$(awk -F',' 'NR>1 {s=$3; gsub(/"/,"",s); if (s=="FAIL") c++} END{print c+0}' "$TMPFILE")
NA_COUNT=$(awk -F','   'NR>1 {s=$3; gsub(/"/,"",s); if (s=="NA")   c++} END{print c+0}' "$TMPFILE")
TOTAL_COUNT=$((PASS_COUNT + FAIL_COUNT + NA_COUNT))

# --- Compute overall score ---
SCORE=$(awk -v p="$PASS_COUNT" -v f="$FAIL_COUNT" 'BEGIN {
    if ((p+f)==0) printf "0.00";
    else printf "%.2f", (p/(p+f))*100;
}')

# --- Capture docker ps and docker images for context ---
DOCKER_PS=$(docker ps --format '{{.ID}} {{.Image}} {{.Names}}' 2>/dev/null || echo "docker ps failed")
DOCKER_IMAGES=$(docker images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null || echo "docker images failed")

# --- Write header block (commented) ---
{
    echo "# Hostname: $HOSTNAME_SHORT"
    echo "# OS: $OS_PRETTY_NAME"
    echo "# Kernel: $KERNEL_VERSION"
    echo "# Docker Version: $DOCKER_VERSION"
    echo "# Generated: $GENERATED_AT"
    echo "#"
    echo "# --- Running Containers (docker ps) ---"
    while IFS= read -r line; do
        echo "# $line"
    done <<< "$DOCKER_PS"
    echo "#"
    echo "# --- Images Present (docker images) ---"
    while IFS= read -r line; do
        echo "# $line"
    done <<< "$DOCKER_IMAGES"
    echo "#"
    echo "# --- CIS Docker Benchmark Summary ---"
    echo "# Total Controls Evaluated: $TOTAL_COUNT"
    echo "# PASS: $PASS_COUNT"
    echo "# FAIL: $FAIL_COUNT"
    echo "# NA: $NA_COUNT"
    echo "# Overall Score: ${SCORE}%"
    echo "# ------------------------------------"
    echo "control_id,description,status,evidence"
} > "$OUTPATH"

# Append merged CIS rows
tail -n +2 "$TMPFILE" >> "$OUTPATH"
rm -f "$TMPFILE"

echo "CIS Docker Benchmark report complete."
echo "Saved to: $OUTPATH"
