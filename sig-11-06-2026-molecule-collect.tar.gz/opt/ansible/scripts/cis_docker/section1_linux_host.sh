#!/usr/bin/env bash

set -euo pipefail

CSV_OUT="/opt/cis/results/section1.csv"
mkdir -p "$(dirname "$CSV_OUT")"

write_csv() {
    local control="$1"
    local description="$2"
    local result="$3"
    local evidence="$4"

    if [[ "$evidence" =~ ^= ]]; then
        evidence="equals ${evidence:1}"
    fi

    printf '"%s","%s","%s","%s"\n' \
        "$control" "$description" "$result" "$evidence" >> "$CSV_OUT"
}

echo '"control","description","result","evidence"' > "$CSV_OUT"

# -------------------------------
# Helper: load audit rules (RHEL 8/9)
# -------------------------------
load_audit_rules() {
    local combined=""

    if [[ -f /etc/audit/audit.rules ]]; then
        combined+="$(cat /etc/audit/audit.rules 2>/dev/null)"
        combined+=$'\n'
    fi

    for f in /etc/audit/rules.d/*.rules; do
        [[ -f "$f" ]] && combined+="$(cat "$f")"$'\n'
    done

    echo "$combined"
}

AUDIT_RULES="$(load_audit_rules)"

audit_rule_present() {
    local path="$1"
    echo "$AUDIT_RULES" | grep -qE "\-w[[:space:]]+$path"
}

audit_rule_evidence() {
    local path="$1"
    echo "$AUDIT_RULES" | grep -E "\-w[[:space:]]+$path" || echo "no audit rule found"
}

AUDIT_MODE=$(auditctl -s 2>/dev/null | awk '/enabled/ {print $2}')

if [[ "$AUDIT_MODE" == "2" ]]; then
    write_csv "1.0.0" "Audit system is immutable" "NA" \
    "auditctl -s shows enabled=2; audit rules cannot be added until reboot"
fi

# -------------------------------
# 1.1.1 Ensure a separate partition for containers has been created
# -------------------------------
check_container_partition() {
    local control="1.1.1"
    local description="Ensure a separate partition for containers has been created"

    if findmnt /var/lib/docker >/dev/null 2>&1; then
        write_csv "$control" "$description" "PASS" "/var/lib/docker is a separate mount: $(findmnt -no SOURCE /var/lib/docker)"
    else
        write_csv "$control" "$description" "FAIL" "/var/lib/docker is not a separate mount"
    fi
}

# -------------------------------
# 1.1.2 Ensure only trusted users control Docker daemon
# -------------------------------
check_docker_group() {
    local control="1.1.2"
    local description="Ensure only trusted users are allowed to control Docker daemon"

    local members
    members=$(getent group docker | awk -F: '{print $4}')

    if [[ -z "$members" ]]; then
        write_csv "$control" "$description" "PASS" "docker group has no members"
    else
        write_csv "$control" "$description" "PASS" "docker group members: $members"
    fi
}

# -------------------------------
# 1.1.3 Ensure auditing is configured for Docker daemon
# -------------------------------
check_audit_docker_daemon() {
    local control="1.1.3"
    local description="Ensure auditing is configured for Docker daemon"

    local path="/usr/bin/dockerd"

    if [[ ! -f "$path" ]]; then
        write_csv "$control" "$description" "NA" "$path not present on host"
        return
    fi

    if audit_rule_present "$path"; then
        write_csv "$control" "$description" "PASS" "$(audit_rule_evidence "$path")"
    else
        write_csv "$control" "$description" "FAIL" "No audit rule for $path"
    fi
}

# -------------------------------
# 1.1.4 → 1.1.18 Audit checks for Docker files
# -------------------------------
audit_paths=(
    "/run/containerd"
    "/var/lib/docker"
    "/etc/docker"
    "/lib/systemd/system/docker.service"
    "/run/containerd/containerd.sock"
    "/var/run/docker.sock"
    "/etc/default/docker"
    "/etc/docker/daemon.json"
    "/etc/containerd/config.toml"
    "/etc/sysconfig/docker"
    "/usr/bin/containerd"
    "/usr/bin/containerd-shim"
    "/usr/bin/containerd-shimrunc-v1"
    "/usr/bin/containerd-shimrunc-v2"
    "/usr/bin/runc"
)

audit_controls=(
    "1.1.4"
    "1.1.5"
    "1.1.6"
    "1.1.7"
    "1.1.8"
    "1.1.9"
    "1.1.10"
    "1.1.11"
    "1.1.12"
    "1.1.13"
    "1.1.14"
    "1.1.15"
    "1.1.16"
    "1.1.17"
    "1.1.18"
)

audit_descriptions=(
    "Audit /run/containerd"
    "Audit /var/lib/docker"
    "Audit /etc/docker"
    "Audit docker.service"
    "Audit containerd.sock"
    "Audit docker.sock"
    "Audit /etc/default/docker"
    "Audit daemon.json"
    "Audit containerd config"
    "Audit /etc/sysconfig/docker"
    "Audit containerd binary"
    "Audit containerd-shim"
    "Audit containerd-shimrunc-v1"
    "Audit containerd-shimrunc-v2"
    "Audit runc binary"
)

check_audit_paths() {
    for i in "${!audit_paths[@]}"; do
        local path="${audit_paths[$i]}"
        local control="${audit_controls[$i]}"
        local description="${audit_descriptions[$i]}"

        if [[ ! -e "$path" ]]; then
            write_csv "$control" "$description" "NA" "$path not present on host"
            continue
        fi

        if audit_rule_present "$path"; then
            write_csv "$control" "$description" "PASS" "$(audit_rule_evidence "$path")"
        else
            write_csv "$control" "$description" "FAIL" "No audit rule for $path"
        fi
    done
}

# -------------------------------
# 1.2.1 Ensure container host is hardened
# -------------------------------
check_host_hardened() {
    local control="1.2.1"
    local description="Ensure the container host has been hardened"

    if [[ -f "/etc/ssh/sshd_config" ]] && \
       grep -Eq "^PermitRootLogin (no|prohibit-password)" /etc/ssh/sshd_config; then
        write_csv "$control" "$description" "PASS" "Host hardening detected: PermitRootLogin $(grep -E '^PermitRootLogin' /etc/ssh/sshd_config | awk '{print $2}')"
    else
        write_csv "$control" "$description" "FAIL" "Host hardening not detected: PermitRootLogin no|prohibit-password missing"
    fi
}

# -------------------------------
# 1.2.2 Ensure Docker version is up to date
# -------------------------------
check_docker_version() {
    local control="1.2.2"
    local description="Ensure Docker version is up to date"

    local version
    version=$(docker --version 2>/dev/null || echo "docker not installed")

    write_csv "$control" "$description" "PASS" "$version"
}

# -------------------------------
# Run all checks
# -------------------------------
check_container_partition
check_docker_group
check_audit_docker_daemon
check_audit_paths
check_host_hardened
check_docker_version

echo "Section 1 complete: $CSV_OUT"
