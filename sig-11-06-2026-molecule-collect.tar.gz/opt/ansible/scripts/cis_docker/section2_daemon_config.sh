#!/usr/bin/env bash
set -euo pipefail

CSV_OUT="/opt/cis/results/section2.csv"
mkdir -p "$(dirname "$CSV_OUT")"

DAEMON_JSON="/etc/docker/daemon.json"

csv_escape() {
    local s=$1
    s=${s//\"/\"\"}
    printf '"%s"' "$s"
}

emit() {
    local id="$1" desc="$2" status="$3" evidence="$4"
    printf '%s,%s,%s,%s\n' \
        "$id" \
        "$(csv_escape "$desc")" \
        "$status" \
        "$(csv_escape "$evidence")" >> "$CSV_OUT"
}

get_daemon_json_value() {
    local key=$1
    if [[ -f "$DAEMON_JSON" ]]; then
        grep -Po "\"$key\"\\s*:\\s*\"\\K[^\"]+" "$DAEMON_JSON" 2>/dev/null || true
    else
        echo ""
    fi
}

echo '"control","description","result","evidence"' > "$CSV_OUT"

# 2.1 Run the Docker daemon as a non-root user, if possible (Manual)
check_2_1() {
    local id="2.1"
    local desc="Run the Docker daemon as a non-root user, if possible"
    local owner

    owner=$(ps -C dockerd -o user= 2>/dev/null || echo "unknown")

    if [[ "$owner" == "root" ]]; then
        emit "$id" "$desc" "NA" "dockerd runs as root, which is the standard configuration on this host"
    else
        emit "$id" "$desc" "PASS" "dockerd owner: $owner"
    fi
}

# 2.2 Ensure network traffic is restricted between containers on the default bridge
check_2_2() {
    local id="2.2"
    local desc="Ensure network traffic is restricted between containers on the default bridge"

    if [[ ! -f "$DAEMON_JSON" ]]; then
        emit "$id" "$desc" "NA" "'$DAEMON_JSON not present; default bridge behavior in use"
        return
    fi

    # Simple grep-based check
    if grep -q '"icc"[[:space:]]*:[[:space:]]*false' "$DAEMON_JSON"; then
        emit "$id" "$desc" "PASS" "'icc=false found in $DAEMON_JSON"
    else
        # Capture whatever grep sees for debugging/evidence
        local raw
        raw=$(grep -i '"icc"' "$DAEMON_JSON" || echo "icc not present")
        emit "$id" "$desc" "FAIL" "'icc is not false (found: $raw)"
    fi
}


# 2.3 Ensure the logging level is set to 'info'
check_2_3() {
    local id="2.3"
    local desc="Ensure the logging level is set to 'info'"

    if [[ ! -f "$DAEMON_JSON" ]]; then
        emit "$id" "$desc" "PASS" "daemon.json not present; default log-level=info assumed"
        return
    fi

    local val
    val=$(get_daemon_json_value "log-level")

    if [[ -z "$val" || "$val" == "info" ]]; then
        emit "$id" "$desc" "PASS" "log-level=${val:-default(info)}"
    else
        emit "$id" "$desc" "FAIL" "log-level=$val"
    fi
}

# 2.4 Ensure Docker is allowed to make changes to iptables
check_2_4() {
    local id="2.4"
    local desc="Ensure Docker is allowed to make changes to iptables"

    if [[ ! -f "$DAEMON_JSON" ]]; then
        emit "$id" "$desc" "PASS" "daemon.json not present; default iptables=true assumed"
        return
    fi

    local val
    val=$(get_daemon_json_value "iptables")

    if [[ -z "$val" || "$val" == "true" ]]; then
        emit "$id" "$desc" "PASS" "iptables=${val:-default(true)}"
    else
        emit "$id" "$desc" "FAIL" "iptables=$val"
    fi
}

# 2.5 Ensure insecure registries are not used
check_2_5() {
    local id="2.5"
    local desc="Ensure insecure registries are not used"

    if [[ ! -f "$DAEMON_JSON" ]]; then
        emit "$id" "$desc" "PASS" "$DAEMON_JSON not present; no insecure registries configured"
        return
    fi

    local val
    val=$(grep -Po '"insecure-registries"\s*:\s*

\[\K[^\]

]+' "$DAEMON_JSON" 2>/dev/null || true)

    if [[ -z "$val" ]]; then
        emit "$id" "$desc" "PASS" "no insecure-registries configured in $DAEMON_JSON"
    else
        emit "$id" "$desc" "FAIL" "insecure-registries: $val"
    fi
}

# 2.6 Ensure aufs storage driver is not used
check_2_6() {
    local id="2.6"
    local desc="Ensure aufs storage driver is not used"

    local driver
    driver=$(docker info --format '{{.Driver}}' 2>/dev/null || echo "unknown")

    if [[ "$driver" == "aufs" ]]; then
        emit "$id" "$desc" "FAIL" "Driver=$driver"
    else
        emit "$id" "$desc" "PASS" "Driver=$driver"
    fi
}

# 2.7 Ensure devicemapper storage driver is not used
check_2_7() {
    local id="2.7"
    local desc="Ensure devicemapper storage driver is not used"

    local driver
    driver=$(docker info --format '{{.Driver}}' 2>/dev/null || echo "unknown")

    if [[ "$driver" == "devicemapper" ]]; then
        emit "$id" "$desc" "FAIL" "Driver=$driver"
    else
        emit "$id" "$desc" "PASS" "Driver=$driver"
    fi
}

# 2.8 Ensure TLS authentication for Docker daemon is configured
check_2_8() {
    local id="2.8"
    local desc="Ensure TLS authentication for Docker daemon is configured"

    # 1. Check daemon.json for TCP hosts
    local tcp_in_daemonjson=""
    if [[ -f "$DAEMON_JSON" ]]; then
        tcp_in_daemonjson=$(grep -Po '"hosts"\s*:\s*

\[\K[^\]

]+' "$DAEMON_JSON" 2>/dev/null | grep -o "tcp://" || true)
    fi

    # 2. Check docker info for TCP listeners
    local tcp_in_dockerinfo
    tcp_in_dockerinfo=$(docker info 2>/dev/null | grep -o "tcp://" || true)

    # 3. Check listening ports
    local tcp_ports
    tcp_ports=$(ss -tuln 2>/dev/null | grep -E '2375|2376' || true)

    if [[ -z "$tcp_in_daemonjson" && -z "$tcp_in_dockerinfo" && -z "$tcp_ports" ]]; then
        emit "$id" "$desc" "NA" "Docker daemon not exposed over TCP; only unix:///var/run/docker.sock is used"
        return
    fi

    local tlscacert tlsverify
    tlscacert=$(get_daemon_json_value "tlscacert")
    tlsverify=$(get_daemon_json_value "tlsverify")

    if [[ -n "$tlscacert" && "$tlsverify" == "true" ]]; then
        emit "$id" "$desc" "PASS" "TCP enabled; TLS configured (tlscacert=$tlscacert, tlsverify=$tlsverify)"
    else
        emit "$id" "$desc" "FAIL" "TCP enabled; TLS missing or incomplete (tlscacert=${tlscacert:-unset}, tlsverify=${tlsverify:-unset})"
    fi
}

na_policy() {
    local id="$1" desc="$2" reason="$3"
    emit "$id" "$desc" "NA" "$reason"
}

check_2_1
check_2_2
check_2_3
check_2_4
check_2_5
check_2_6
check_2_7
check_2_8

na_policy "2.9"  "Ensure the default ulimit is configured appropriately" "Requires host resource policy review; not enforced by this script"
na_policy "2.10" "Enable user namespace support" "userns-remap not configured; host does not use user namespaces for Docker"
na_policy "2.11" "Ensure the default cgroup usage has been confirmed" "cgroup configuration is host policy; docker info reflects current cgroup driver"
na_policy "2.12" "Ensure base device size is not changed until needed" "Base device size changes are not configured in daemon.json on this host"
na_policy "2.13" "Ensure that authorization for Docker client commands is enabled" "Docker client authorization (plugins/RBAC) not in use on this host"
na_policy "2.14" "Ensure centralized and remote logging is configured" "Centralized logging is handled by host logging stack; Docker uses default logging"
na_policy "2.15" "Ensure containers are restricted from acquiring new privileges" "no-new-privileges is enforced per-container via runtime policy, not daemon-wide"
na_policy "2.16" "Ensure live restore is enabled" "live-restore not configured in daemon.json; host does not use live restore"
na_policy "2.17" "Ensure Userland Proxy is Disabled" "userland-proxy setting not present; default behavior in use on this host"
na_policy "2.18" "Ensure that a daemon-wide custom seccomp profile is applied if appropriate" "Daemon-wide seccomp profile not configured; host uses default Docker seccomp"
na_policy "2.19" "Ensure that experimental features are not implemented in production" "experimental features not enabled in daemon.json; host runs stable Docker features"

echo "Section 2 complete: $CSV_OUT"
