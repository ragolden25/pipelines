#!/usr/bin/env bash
set -euo pipefail

CSV_OUT="/opt/cis/results/section3.csv"
mkdir -p "$(dirname "$CSV_OUT")"

csv_escape() {
    local s=$1
    s=${s//\"/\"\"}
    printf '"%s"' "$s"
}

check_owner() {
    local path="$1" expected="$2"

    if [[ ! -e "$path" ]]; then
        echo "NA|$path does not exist"
        return
    fi

    local owner
    owner=$(stat -c %U:%G "$path" 2>/dev/null || echo "unknown")

    if [[ "$owner" == "$expected" ]]; then
        echo "PASS|$path owner=$owner"
    else
        echo "FAIL|$path owner=$owner expected=$expected"
    fi
}

check_mode_max() {
    local path="$1" max="$2"

    if [[ ! -e "$path" ]]; then
        echo "NA|$path does not exist"
        return
    fi

    local mode
    mode=$(stat -c %a "$path" 2>/dev/null || echo "unknown")

    if [[ "$mode" =~ ^[0-9]+$ ]] && (( mode <= max )); then
        echo "PASS|$path mode=$mode"
    else
        echo "FAIL|$path mode=$mode expected<=${max}"
    fi
}

emit() {
    local id="$1" desc="$2" result="$3"
    local status=${result%%|*}
    local evidence=${result#*|}

    printf '%s,%s,%s,%s\n' \
        "$id" \
        "$(csv_escape "$desc")" \
        "$status" \
        "$(csv_escape "$evidence")" >> "$CSV_OUT"
}

echo '"control","description","result","evidence"' > "$CSV_OUT"

emit "3.1"  "Ensure docker.service file ownership is set to root:root" \
    "$(check_owner "/lib/systemd/system/docker.service" "root:root")"

emit "3.2"  "Ensure docker.service file permissions are appropriately set" \
    "$(check_mode_max "/lib/systemd/system/docker.service" 644)"

emit "3.3"  "Ensure docker.socket file ownership is set to root:root" \
    "$(check_owner "/lib/systemd/system/docker.socket" "root:root")"

emit "3.4"  "Ensure docker.socket file permissions are set to 644 or more restrictive" \
    "$(check_mode_max "/lib/systemd/system/docker.socket" 644)"

emit "3.5"  "Ensure /etc/docker directory ownership is set to root:root" \
    "$(check_owner "/etc/docker" "root:root")"

emit "3.6"  "Ensure /etc/docker directory permissions are set to 755 or more restrictive" \
    "$(check_mode_max "/etc/docker" 755)"

emit "3.7"  "Ensure registry certificate file ownership is set to root:root" \
    "$(check_owner "/etc/docker/certs.d" "root:root")"

emit "3.8"  "Ensure registry certificate file permissions are set to 444 or more restrictive" \
    "$(check_mode_max "/etc/docker/certs.d" 444)"

emit "3.9"  "Ensure TLS CA certificate file ownership is set to root:root" \
    "$(check_owner "/etc/docker/certs.d/ca.crt" "root:root")"

emit "3.10" "Ensure TLS CA certificate file permissions are set to 444 or more restrictive" \
    "$(check_mode_max "/etc/docker/certs.d/ca.crt" 444)"

emit "3.11" "Ensure Docker server certificate file ownership is set to root:root" \
    "$(check_owner "/etc/docker/certs.d/server.crt" "root:root")"

emit "3.12" "Ensure Docker server certificate file permissions are set to 444 or more restrictive" \
    "$(check_mode_max "/etc/docker/certs.d/server.crt" 444)"

emit "3.13" "Ensure Docker server certificate key file ownership is set to root:root" \
    "$(check_owner "/etc/docker/certs.d/server.key" "root:root")"

emit "3.14" "Ensure Docker server certificate key file permissions are set to 400" \
    "$(check_mode_max "/etc/docker/certs.d/server.key" 400)"

emit "3.15" "Ensure Docker socket file ownership is set to root:docker" \
    "$(check_owner "/var/run/docker.sock" "root:docker")"

emit "3.16" "Ensure Docker socket file permissions are set to 660 or more restrictive" \
    "$(check_mode_max "/var/run/docker.sock" 660)"

emit "3.17" "Ensure daemon.json file ownership is set to root:root" \
    "$(check_owner "/etc/docker/daemon.json" "root:root")"

emit "3.18" "Ensure daemon.json file permissions are set to 644 or more restrictive" \
    "$(check_mode_max "/etc/docker/daemon.json" 644)"

emit "3.19" "Ensure /etc/default/docker file ownership is set to root:root" \
    "$(check_owner "/etc/default/docker" "root:root")"

emit "3.20" "Ensure /etc/default/docker file permissions are set to 644 or more restrictive" \
    "$(check_mode_max "/etc/default/docker" 644)"

emit "3.21" "Ensure /etc/sysconfig/docker file permissions are set to 644 or more restrictive" \
    "$(check_mode_max "/etc/sysconfig/docker" 644)"

emit "3.22" "Ensure /etc/sysconfig/docker file ownership is set to root:root" \
    "$(check_owner "/etc/sysconfig/docker" "root:root")"

emit "3.23" "Ensure Containerd socket file ownership is set to root:root" \
    "$(check_owner "/run/containerd/containerd.sock" "root:root")"

emit "3.24" "Ensure Containerd socket file permissions are set to 660 or more restrictive" \
    "$(check_mode_max "/run/containerd/containerd.sock" 660)"

echo "Section 3 complete: $CSV_OUT"
