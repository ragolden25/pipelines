#!/usr/bin/env bash
set -euo pipefail

CSV_OUT="/opt/cis/results/section4.csv"
mkdir -p "$(dirname "$CSV_OUT")"

DOCKERFILES_DIR="/var/lib/containers/dockerfiles"
IMAGES_DIR="/var/lib/containers/images"
PROVENANCE_DIR="/var/lib/containers/provenance"

csv_escape() {
    local s=$1
    s=${s//\"/\"\"}
    printf '"%s"' "$s"
}

emit() {
    printf '%s,%s,%s,%s\n' \
        "$1" \
        "$(csv_escape "$2")" \
        "$3" \
        "$(csv_escape "$4")" >> "$CSV_OUT"
}

echo '"control","description","result","evidence"' > "$CSV_OUT"

# Map image name to hardened Dockerfile path
get_dockerfile_path() {
    local image="$1"
    local name

    # Strip repo prefix and version to get component name
    # e.g. nucleus/guacamole:1.6.0 -> guacamole
    name="${image##*/}"        # guacamole:1.6.0
    name="${name%%:*}"         # guacamole

    case "$name" in
        guacamole)
            echo "${DOCKERFILES_DIR}/Dockerfile.guacamole.hardened"
            ;;
        guacd)
            echo "${DOCKERFILES_DIR}/Dockerfile.guacd.hardened"
            ;;
        nginx)
            echo "${DOCKERFILES_DIR}/Dockerfile.nginx.hardened"
            ;;
        postgres)
            echo "${DOCKERFILES_DIR}/Dockerfile.postgres.hardened"
            ;;
        *)
            echo ""
            ;;
    esac
}

# Map image name to tar/tar.gz filenames
get_tar_names() {
    local image="$1"
    local name version base

    base="${image##*/}"        # guacamole:1.6.0
    name="${base%%:*}"         # guacamole
    version="${base##*:}"      # 1.6.0

    # Special case for base debian13 image
    if [[ "$name" == "debian13-image" ]]; then
        echo "debian13-image-latest.tar debian13-image-latest.tar.gz"
        return
    fi

    echo "nucleus-${name}-${version}.tar nucleus-${name}-${version}.tar.gz"
}

# 4.1 Ensure a user for the container has been created
check_4_1() {
    local image="$1"
    local user
    user=$(docker image inspect "$image" --format '{{.Config.User}}' 2>/dev/null || echo "")

    if [[ -z "$user" || "$user" == "root" ]]; then
        echo "FAIL|[$image] Image runs as root (no USER instruction)"
    else
        echo "PASS|[$image] Image user: $user"
    fi
}

# 4.2 Trusted base images
check_4_2() {
    local image="$1"
    local repo
    repo="${image%%:*}"

    if [[ "$repo" == "debian13-image" || "$repo" == nucleus/* ]]; then
        echo "PASS|[$image] Image built from trusted base (${repo})"
    else
        echo "FAIL|[$image] Image base not in trusted set (${repo})"
    fi
}

# 4.3 Unnecessary packages (still NA for now)
check_4_3() {
    local image="$1"
    echo "NA|[$image] Package analysis requires SBOM policy; not enforced on this host"
}

# 4.4 Image scanning (NA placeholder)
check_4_4() {
    local image="$1"
    echo "NA|[$image] Vulnerability scanning evaluated via external Grype reports; not enforced in this script"
}

# 4.5 Docker Content Trust (NA)
check_4_5() {
    local image="$1"
    echo "NA|[$image] Docker Content Trust not used; GPG-based provenance enforced instead"
}

# 4.6 HEALTHCHECK instructions
check_4_6() {
    local image="$1"
    local health
    health=$(docker image inspect "$image" --format '{{json .Config.Healthcheck}}' 2>/dev/null)

    if [[ "$health" == "null" || -z "$health" ]]; then
        echo "NA|[$image] Image has no HEALTHCHECK; environment does not use orchestrators that act on health status"
    else
        echo "PASS|[$image] HEALTHCHECK present: $health"
    fi
}

# 4.7 Update instructions in Dockerfile
check_4_7() {
    local image="$1"
    local df
    df=$(get_dockerfile_path "$image")

    if [[ -z "$df" || ! -f "$df" ]]; then
        echo "NA|[$image] Hardened Dockerfile not available; cannot evaluate update instructions"
        return
    fi

    if grep -qiE 'apt-get\s+update|yum\s+update|dnf\s+update' "$df"; then
        echo "FAIL|[$image] Dockerfile uses update instructions (apt/yum/dnf update)"
    else
        echo "PASS|[$image] Dockerfile does not use update instructions alone"
    fi
}

# 4.8 Ensure setuid/setgid permissions are removed
check_4_8() {
    local image="$1"
    local output

    output=$(docker run --rm --entrypoint /usr/bin/find "$image" / -perm /6000 2>/dev/null || true)

    if [[ -z "$output" ]]; then
        echo "PASS|[$image] No setuid/setgid files found"
    else
        echo "FAIL|[$image] Setuid/setgid files found: $output"
    fi
}

# 4.9 COPY vs ADD in Dockerfile
check_4_9() {
    local image="$1"
    local df
    df=$(get_dockerfile_path "$image")

    if [[ -z "$df" || ! -f "$df" ]]; then
        echo "NA|[$image] Hardened Dockerfile not available; cannot evaluate COPY vs ADD"
        return
    fi

    if grep -qE '^[[:space:]]*ADD[[:space:]]' "$df"; then
        echo "FAIL|[$image] Dockerfile uses ADD; COPY should be used instead"
    else
        echo "PASS|[$image] Dockerfile uses COPY (no ADD instructions found)"
    fi
}

# 4.10 Secrets in Dockerfiles
check_4_10() {
    local image="$1"
    local df
    df=$(get_dockerfile_path "$image")

    if [[ -z "$df" || ! -f "$df" ]]; then
        echo "NA|[$image] Hardened Dockerfile not available; cannot evaluate secrets"
        return
    fi

    if grep -qiE 'password|secret|token|PRIVATE KEY' "$df"; then
        echo "FAIL|[$image] Potential secrets detected in Dockerfile (password/secret/token/key)"
    else
        echo "PASS|[$image] No obvious secrets detected in Dockerfile"
    fi
}

# 4.11 Verified packages (NA placeholder)
check_4_11() {
    local image="$1"
    echo "NA|[$image] Package verification enforced by build pipeline; not evaluated in this script"
}

# 4.12 Signed artifacts (GPG verification)
check_4_12() {
    local image="$1"
    local tar targz
    read -r tar targz <<< "$(get_tar_names "$image")"

    local tar_path="${IMAGES_DIR}/${tar}"
    local tar_gz_path="${IMAGES_DIR}/${targz}"
    local tar_sig="${PROVENANCE_DIR}/${tar}.asc"
    local tar_gz_sig="${PROVENANCE_DIR}/${targz}.asc"

    local have_tar_sig="no"
    local have_targz_sig="no"
    local tar_ok="no"
    local targz_ok="no"
    local evidence=""

    if [[ -f "$tar_gz_sig" && -f "$tar_gz_path" ]]; then
        have_targz_sig="yes"
        if gpg --verify "$tar_gz_sig" "$tar_gz_path" >/dev/null 2>&1; then
            targz_ok="yes"
        else
            targz_ok="no"
        fi
    fi

    if [[ -f "$tar_sig" && -f "$tar_path" ]]; then
        have_tar_sig="yes"
        if gpg --verify "$tar_sig" "$tar_path" >/dev/null 2>&1; then
            tar_ok="yes"
        else
            tar_ok="no"
        fi
    fi

    if [[ "$have_tar_sig" == "no" && "$have_targz_sig" == "no" ]]; then
        echo "NA|[$image] No GPG signatures found for tar or tar.gz in provenance directory"
        return
    fi

    if [[ "$tar_ok" == "yes" || "$targz_ok" == "yes" ]]; then
        evidence="tar_sig_present=${have_tar_sig},tar_sig_valid=${tar_ok}; tar_gz_sig_present=${have_targz_sig},tar_gz_sig_valid=${targz_ok}"
        echo "PASS|[$image] GPG signatures valid for one or more artifacts: ${evidence}"
    else
        evidence="tar_sig_present=${have_tar_sig},tar_sig_valid=${tar_ok}; tar_gz_sig_present=${have_targz_sig},tar_gz_sig_valid=${targz_ok}"
        echo "FAIL|[$image] GPG signatures present but invalid: ${evidence}"
    fi
}

run_image_checks() {
    local id desc image func result status evidence

    id="$1"
    desc="$2"
    image="$3"
    func="$4"

    result=$($func "$image")
    status=${result%%|*}
    evidence=${result#*|}

    emit "$id" "$desc" "$status" "$evidence"
}

# Enumerate ALL images on the host
IMAGES=$(docker images --format '{{.Repository}}:{{.Tag}}')

for image in $IMAGES; do
    run_image_checks "4.1"  "Ensure a user for the container has been created" "$image" check_4_1
    run_image_checks "4.2"  "Ensure containers use only trusted base images" "$image" check_4_2
    run_image_checks "4.3"  "Ensure unnecessary packages are not installed" "$image" check_4_3
    run_image_checks "4.4"  "Ensure images are scanned and rebuilt to include security patches" "$image" check_4_4
    run_image_checks "4.5"  "Ensure Docker Content Trust is enabled" "$image" check_4_5
    run_image_checks "4.6"  "Ensure HEALTHCHECK instructions exist" "$image" check_4_6
    run_image_checks "4.7"  "Ensure update instructions are not used alone in Dockerfiles" "$image" check_4_7
    run_image_checks "4.8"  "Ensure setuid/setgid permissions are removed" "$image" check_4_8
    run_image_checks "4.9"  "Ensure COPY is used instead of ADD" "$image" check_4_9
    run_image_checks "4.10" "Ensure secrets are not stored in Dockerfiles" "$image" check_4_10
    run_image_checks "4.11" "Ensure only verified packages are installed" "$image" check_4_11
    run_image_checks "4.12" "Ensure all signed artifacts are validated" "$image" check_4_12
done

echo "Section 4 complete: $CSV_OUT"
