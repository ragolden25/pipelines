#!/usr/bin/env bash
set -euo pipefail

CSV_OUT="/opt/cis/results/section5.csv"
mkdir -p "$(dirname "$CSV_OUT")"

csv_escape() {
    local s=$1
    s=${s//\"/\"\"}
    printf '"%s"' "$s"
}

emit() {
    printf '%s,%s,%s,%s\n' \
        "$1" \
        "$(csv_escape "$2")" \
        "$3" \
        "$(csv_escape "$4")" >> "$CSV_OUT"
}

# --- Write header row ---
echo '"control","description","result","evidence"' > "$CSV_OUT"

# --- Add docker ps snapshot (commented) ---
{
    echo "# --- Running Containers (docker ps) ---"
    docker ps --format '{{.ID}} {{.Image}} {{.Names}}' | while read -r line; do
        echo "# $line"
    done
    echo "#"
} >> "$CSV_OUT"

# Enumerate all running containers
containers=$(docker ps --format '{{.ID}} {{.Image}} {{.Names}}')

while read -r cid image name; do
    [[ -z "$cid" ]] && continue

    # 5.1 Ensure swarm mode is not enabled
    swarm=$(docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null || echo "unknown")
    if [[ "$swarm" == "inactive" ]]; then
        emit "5.1" "Ensure swarm mode is not enabled ($name)" "PASS" \
            "Swarm mode inactive (LocalNodeState=inactive)"
    else
        emit "5.1" "Ensure swarm mode is not enabled ($name)" "FAIL" \
            "Swarm mode active: $swarm"
    fi

    # 5.4 Ensure Linux kernel capabilities are restricted
    caps=$(docker inspect "$cid" --format '{{json .HostConfig.CapAdd}}')
    if [[ "$caps" == "null" || "$caps" == "[]" ]]; then
        emit "5.4" "Ensure Linux kernel capabilities are restricted ($name)" "PASS" \
            "No additional capabilities configured"
    else
        emit "5.4" "Ensure Linux kernel capabilities are restricted ($name)" "FAIL" \
            "Capabilities added: $caps"
    fi

    # 5.5 Ensure privileged containers are not used
    priv=$(docker inspect "$cid" --format '{{.HostConfig.Privileged}}')
    if [[ "$priv" == "false" ]]; then
        emit "5.5" "Ensure privileged containers are not used ($name)" "PASS" \
            "Privileged=false"
    else
        emit "5.5" "Ensure privileged containers are not used ($name)" "FAIL" \
            "Container is privileged"
    fi

    # 5.6 Ensure sensitive host directories are not mounted
    mounts=$(docker inspect "$cid" --format '{{json .Mounts}}')
    if echo "$mounts" | grep -qE '"Source":"/(etc|root|var/lib/docker)"'; then
        emit "5.6" "Ensure sensitive host directories are not mounted ($name)" "FAIL" \
            "Sensitive directories mounted: $mounts"
    else
        emit "5.6" "Ensure sensitive host directories are not mounted ($name)" "PASS" \
            "No sensitive directories mounted"
    fi

    # 5.7 Ensure sshd is not run within containers
    sshd=$(docker exec "$cid" sh -c 'ps aux 2>/dev/null | grep sshd | grep -v grep' || true)
    if [[ "$sshd" == *"executable file not found"* ]]; then
        emit "5.7" "Ensure sshd is not run within containers ($name)" "PASS" \
            "Container has no shell; sshd cannot run"
    elif [[ -n "$sshd" ]]; then
        emit "5.7" "Ensure sshd is not run within containers ($name)" "FAIL" \
            "sshd detected: $sshd"
    else
        emit "5.7" "Ensure sshd is not run within containers ($name)" "PASS" \
            "No sshd process detected"
    fi

    # 5.8 Ensure privileged ports are not mapped
    ports=$(docker inspect "$cid" --format '{{json .NetworkSettings.Ports}}')
    if echo "$ports" | grep -qE '"HostPort":"([0-9]|[1-9][0-9]|[1-9][0-9][0-9])"'; then
        emit "5.8" "Ensure privileged ports are not mapped ($name)" "FAIL" \
            "Privileged ports mapped: $ports"
    else
        emit "5.8" "Ensure privileged ports are not mapped ($name)" "PASS" \
            "No privileged ports mapped"
    fi

    # 5.9 NA
    emit "5.9" "Ensure only needed ports are open ($name)" "NA" \
        "Requires application-specific policy"

    # 5.10 Ensure host network namespace is not shared
    netmode=$(docker inspect "$cid" --format '{{.HostConfig.NetworkMode}}')
    if [[ "$netmode" == "host" ]]; then
        emit "5.10" "Ensure host network namespace is not shared ($name)" "FAIL" \
            "NetworkMode=host"
    else
        emit "5.10" "Ensure host network namespace is not shared ($name)" "PASS" \
            "NetworkMode=$netmode"
    fi

    # 5.11 Ensure memory usage is limited
    mem=$(docker inspect "$cid" --format '{{.HostConfig.Memory}}')
    if [[ "$mem" == "0" ]]; then
        emit "5.11" "Ensure memory usage is limited ($name)" "FAIL" \
            "Memory=0 (no limit)"
    else
        emit "5.11" "Ensure memory usage is limited ($name)" "PASS" \
            "Memory limit: $mem"
    fi

    # 5.12 Ensure CPU priority is set
    cpu=$(docker inspect "$cid" --format '{{.HostConfig.CpuShares}}')
    if [[ "$cpu" == "0" ]]; then
        emit "5.12" "Ensure CPU priority is set ($name)" "FAIL" \
            "CpuShares=0 (no limit)"
    else
        emit "5.12" "Ensure CPU priority is set ($name)" "PASS" \
            "CpuShares=$cpu"
    fi

    # 5.13 Ensure root filesystem is read-only
    ro=$(docker inspect "$cid" --format '{{.HostConfig.ReadonlyRootfs}}')
    if [[ "$ro" == "true" ]]; then
        emit "5.13" "Ensure root filesystem is read-only ($name)" "PASS" \
            "ReadonlyRootfs=true"
    else
        emit "5.13" "Ensure root filesystem is read-only ($name)" "FAIL" \
            "ReadonlyRootfs=false"
    fi

    # 5.14 Ensure incoming traffic is bound to specific interface
    if echo "$ports" | grep -q '"HostIp":"0.0.0.0"'; then
        emit "5.14" "Ensure incoming traffic is bound to specific interface ($name)" "FAIL" \
            "Bound to all interfaces: $ports"
    else
        emit "5.14" "Ensure incoming traffic is bound to specific interface ($name)" "PASS" \
            "Bound to specific interface(s): $ports"
    fi

    # 5.15 Ensure host PID namespace is not shared
    pidmode=$(docker inspect "$cid" --format '{{.HostConfig.PidMode}}')
    if [[ -z "$pidmode" ]]; then
        emit "5.15" "Ensure host PID namespace is not shared ($name)" "PASS" \
            "PID namespace not shared"
    else
        emit "5.15" "Ensure host PID namespace is not shared ($name)" "FAIL" \
            "PidMode=$pidmode"
    fi

    # 5.27 NA
    emit "5.27" "Ensure container health is checked at runtime ($name)" "NA" \
        "Standalone Docker cannot act on health status"

    # 5.28 NA
    emit "5.28" "Ensure latest image version is used ($name)" "NA" \
        "Requires CI/CD image lifecycle management"

    # 5.32 Ensure docker.sock is not mounted
    if echo "$mounts" | grep -q 'docker.sock'; then
        emit "5.32" "Ensure docker.sock is not mounted ($name)" "FAIL" \
            "docker.sock mounted: $mounts"
    else
        emit "5.32" "Ensure docker.sock is not mounted ($name)" "PASS" \
            "docker.sock not mounted"
    fi

done <<< "$containers"

echo "Section 5 complete: $CSV_OUT"
