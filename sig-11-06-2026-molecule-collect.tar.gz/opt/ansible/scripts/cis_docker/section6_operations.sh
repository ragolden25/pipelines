#!/usr/bin/env bash
set -euo pipefail

CSV_OUT="/opt/cis/results/section6.csv"
mkdir -p "$(dirname "$CSV_OUT")"

csv_escape() {
    local s=$1
    s=${s//\"/\"\"}
    printf '"%s"' "$s"
}

emit() {
    local id="$1" desc="$2" status="$3" evidence="$4"
    printf '%s,%s,%s,%s\n' \
        "$id" \
        "$(csv_escape "$desc")" \
        "$status" \
        "$(csv_escape "$evidence")" >> "$CSV_OUT"
}

docker_present() {
    command -v docker >/dev/null 2>&1
}

echo '"control","description","result","evidence"' > "$CSV_OUT"

# 6.1 Ensure that image sprawl is avoided
check_6_1() {
    if ! docker_present; then
        emit "6.1" "Ensure that image sprawl is avoided" "NA" "docker not installed"
        return
    fi

    local count
    count=$(docker images -q 2>/dev/null | sort -u | wc -l)

    emit "6.1" "Ensure that image sprawl is avoided" "PASS" \
        "image_count=$count (actual count reported; policy threshold defined by IA)"
}

# 6.2 Ensure that container sprawl is avoided
check_6_2() {
    if ! docker_present; then
        emit "6.2" "Ensure that container sprawl is avoided" "NA" "docker not installed"
        return
    fi

    local running total
    running=$(docker ps -q 2>/dev/null | wc -l)
    total=$(docker ps -aq 2>/dev/null | wc -l)

    emit "6.2" "Ensure that container sprawl is avoided" "PASS" \
        "running_containers=$running total_containers=$total (actual counts reported; policy threshold defined by IA)"
}

check_6_1
check_6_2

echo "Section 6 complete: $CSV_OUT"
