#!/usr/bin/env bash
set -euo pipefail

CSV_OUT="/opt/cis/results/section7.csv"
mkdir -p "$(dirname "$CSV_OUT")"

csv_escape() {
    local s=$1
    s=${s//\"/\"\"}
    printf '"%s"' "$s"
}

emit() {
    local id="$1" desc="$2" status="$3" evidence="$4"
    printf '%s,%s,%s,%s\n' \
        "$id" \
        "$(csv_escape "$desc")" \
        "$status" \
        "$(csv_escape "$evidence")" >> "$CSV_OUT"
}

echo '"control","description","result","evidence"' > "$CSV_OUT"

# Detect Swarm state
SWARM_STATE=$(docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null || echo "unknown")

emit_na() {
    local id="$1" desc="$2"
    emit "$id" "$desc" "NA" "Swarm mode is $SWARM_STATE on this host"
}

# Section 7 controls (all NA when Swarm is inactive)
emit_na "7.1" "Ensure minimum number of manager nodes"
emit_na "7.2" "Ensure swarm services are bound to a specific host interface"
emit_na "7.3" "Ensure overlay networks are encrypted"
emit_na "7.4" "Ensure secret management commands are used"
emit_na "7.5" "Ensure swarm manager is run in auto-lock mode"
emit_na "7.6" "Ensure auto-lock key is rotated"
emit_na "7.7" "Ensure node certificates are rotated"
emit_na "7.8" "Ensure CA certificates are rotated"
emit_na "7.9" "Ensure management plane traffic is separated"

echo "Section 7 complete: $CSV_OUT"
