#!/bin/bash
set -euo pipefail

BASE="/opt/ansible/files/grafana-stack"
GRAFANA_DIR="$BASE/grafana"

echo "=== Grafana Stack Cleanup ==="
echo "Target directory: $BASE"
echo

# Directories to remove entirely (dead experiments)
REMOVE_DIRS=(
  "$BASE/redfish"
  "$BASE/redfish-build"
  "$BASE/ipmi"
  "$BASE/cisco"
  "$BASE/archive"
)

# Remove unused certs inside grafana/ (you source certs from nginx)
REMOVE_CERTS=(
  "$GRAFANA_DIR/certs"
)

# Remove stale tarballs and binaries
REMOVE_FILES=(
  "$GRAFANA_DIR/*.tar.gz"
  "$GRAFANA_DIR/*.msi"
  "$BASE/influxdb/*.tar.gz"
  "$BASE/nginx/*.tar.gz"
  "$BASE/prometheus/*.tar.gz"
  "$BASE/telegraf/*.tar.gz"
)

echo "The following directories will be removed:"
printf '  - %s\n' "${REMOVE_DIRS[@]}"
echo
echo "The following unused cert directories will be removed:"
printf '  - %s\n' "${REMOVE_CERTS[@]}"
echo
echo "The following stale tarballs/binaries will be removed:"
printf '  - %s\n' "${REMOVE_FILES[@]}"
echo

read -p "Proceed with cleanup? (yes/no): " CONFIRM
if [[ "$CONFIRM" != "yes" ]]; then
    echo "Aborted."
    exit 1
fi

echo
echo "=== Removing directories ==="
for d in "${REMOVE_DIRS[@]}"; do
    if [[ -d "$d" ]]; then
        echo "Removing directory: $d"
        rm -rf "$d"
    fi
done

echo
echo "=== Removing unused cert directories ==="
for c in "${REMOVE_CERTS[@]}"; do
    if [[ -d "$c" ]]; then
        echo "Removing cert directory: $c"
        rm -rf "$c"
    fi
done

echo
echo "=== Removing stale files ==="
shopt -s nullglob
for pattern in "${REMOVE_FILES[@]}"; do
    for f in $pattern; do
        echo "Removing file: $f"
        rm -f "$f"
    done
done
shopt -u nullglob

echo
echo "Cleanup complete."
