#!/bin/bash

set -e

echo "=== Searching for stray .dockerignore files ==="
find /opt/ansible -type f -name ".dockerignore" | tee /tmp/dockerignore_list.txt

echo
echo "=== Searching for nested fy26q3 directories ==="
find /opt/ansible -type d -path "*/fy26q3/fy26q3/*" | tee /tmp/fy26q3_nested_list.txt

echo
echo "=== Summary ==="
echo "Found $(wc -l < /tmp/dockerignore_list.txt) .dockerignore files"
echo "Found $(wc -l < /tmp/fy26q3_nested_list.txt) nested fy26q3 directories"

echo
read -p "Proceed with deletion? (yes/no): " CONFIRM

if [[ "$CONFIRM" != "yes" ]]; then
    echo "Aborted."
    exit 1
fi

echo
echo "=== Deleting .dockerignore files ==="
while read -r FILE; do
    [[ -z "$FILE" ]] && continue
    echo "Deleting $FILE"
    rm -f "$FILE"
done < /tmp/dockerignore_list.txt

echo
echo "=== Deleting nested fy26q3 directories ==="
while read -r DIR; do
    [[ -z "$DIR" ]] && continue
    echo "Deleting directory $DIR"
    rm -rf "$DIR"
done < /tmp/fy26q3_nested_list.txt

echo
echo "=== Cleanup complete ==="
