#!/usr/bin/env python3
import os
import yaml
import subprocess

DEFAULT_ROLE_BASE = "/opt/ansible/nucleus/roles"
GENERIC_BASE = "/home/ansible"
GENERATE_READMES = "/home/ansible/bin/generate-readmes.py"


def prompt_list(section_name):
    items = []
    print(f"\nEnter {section_name} items (blank line to finish):")
    while True:
        val = input("- ")
        if not val.strip():
            break
        items.append(val.strip())
    return items


def collect_overrides(name_hint=None):
    overrides = {}

    # Purpose
    purpose = input("Purpose (one line description): ").strip()
    if purpose:
        overrides["purpose"] = purpose

    # Tasks
    tasks = prompt_list("Tasks")
    if tasks:
        overrides["tasks"] = tasks

    # Requirements
    reqs = prompt_list("Requirements")
    if reqs:
        overrides["requirements"] = reqs

    # Verification
    verifs = prompt_list("Verification steps (prefix commands with 'bash:'):")
    if verifs:
        overrides["verification"] = verifs

    # Notes
    notes = prompt_list("Notes")
    if notes:
        overrides["notes"] = notes

    # Usage Section
    print("\nSelect a usage example type:")
    print("1) Bash example")
    print("2) YAML example")
    print("3) Python example")
    print("4) PowerShell example")
    print("5) Manual entry")
    choice = input("Choice [1-5]: ").strip()

    usage_block = ""

    if choice == "1":
        usage_block = """\
```bash
./generate-readmes.py --yaml-file readme_overrides.yaml --output README.md
```"""

    elif choice == "2":
        usage_block = """\
```yaml
- hosts: all
  tasks:
    - include_tasks: readme_overrides.yaml
```"""

    elif choice == "3":
        usage_block = """\
```python
import subprocess
subprocess.run([
    "./generate-readmes.py",
    "--yaml-file", "readme_overrides.yaml",
    "--output", "README.md"
])
```"""

    elif choice == "4":
        usage_block = """\
```powershell
python .\\generate-readmes.py --yaml-file readme_overrides.yaml --output README.md
```"""

    else:
        print("\nEnter Usage Example (end with blank line):")
        usage_lines = []
        while True:
            line = input()
            if not line.strip():
                break
            usage_lines.append(line)
        usage_block = "\n".join(usage_lines)

    if usage_block:
        overrides["usage"] = usage_block

    key_name = name_hint or input("Name key for overrides (role/project name): ").strip()
    return key_name, overrides


def main():
    is_role = input("Is this an Ansible role? [y/N]: ").strip().lower() in ("y", "yes")

    if is_role:
        base_dir = input(f"Base directory for roles [{DEFAULT_ROLE_BASE}]: ").strip()
        if not base_dir:
            base_dir = DEFAULT_ROLE_BASE

        role = input("Role name (e.g., configure_esxi): ").strip()
        role_path = os.path.join(base_dir, role)
        if not os.path.exists(role_path):
            print(f"Role directory {role_path} does not exist.")
            return

        key_name, overrides = collect_overrides(name_hint=role)
        filename = os.path.join(role_path, "readme_overrides.yaml")

    else:
        readme_dir_name = input("Directory name for README context (e.g., guac_docs): ").strip()
        if not readme_dir_name:
            print("Directory name is required for non-role projects.")
            return

        target_dir = os.path.join(GENERIC_BASE, readme_dir_name)
        os.makedirs(target_dir, exist_ok=True)

        key_name, overrides = collect_overrides(name_hint=readme_dir_name)
        filename = os.path.join(target_dir, "readme_overrides.yaml")

    # Write overrides file
    with open(filename, "w") as f:
        yaml.dump({key_name: overrides}, f, sort_keys=False)

    print(f"\nOverride file written to {filename}")

    # Optionally run generate-readmes.py
    run_gen = input("Run generate-readmes.py to create README.md now? [y/N]: ").strip().lower()
    if run_gen in ("y", "yes"):
        output_readme = os.path.join(os.path.dirname(filename), "README.md")
        cmd = [GENERATE_READMES, "--yaml-file", filename, "--output", output_readme]
        print(f"Executing: {' '.join(cmd)}")
        try:
            subprocess.run(cmd, check=True)
            print(f"README.md generated at {output_readme}")
        except Exception as e:
            print(f"Failed to run generate-readmes.py: {e}")


if __name__ == "__main__":
    main()
