#!/usr/bin/env bash
set -euo pipefail

BASE="/opt/ansible/files/grafana-stack"
STACK="${BASE}"
TARGET="${BASE}/fy26q1"

echo "Creating fy26q1 seed directory at: ${TARGET}"
mkdir -p "${TARGET}"

echo "Copying baseline stack files..."

rsync -av \
  --exclude "*.tar.gz" \
  --exclude "container*" \
  --exclude "*.env" \
  --exclude "versions.env" \
  --exclude "__pycache__" \
  --exclude "*.pyc" \
  --exclude "*.log" \
  --exclude "*.tmp" \
  --exclude "*.bak" \
  "${STACK}/" "${TARGET}/"

echo "fy26q1 seed directory created successfully."

