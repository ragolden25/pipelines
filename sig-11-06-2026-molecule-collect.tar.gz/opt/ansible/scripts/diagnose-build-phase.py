#!/usr/bin/env python3
import os
import subprocess
import json
from pathlib import Path

CONTAINERS = {
    "guacd": {
        "build_dir": "/opt/ansible/files/build/guacd/fy26q3",
        "dockerfile": "/opt/ansible/files/build/guacd/fy26q3/Dockerfile",
        "scripts_dir": "/opt/ansible/files/build/guacd/fy26q3/scripts",
        "expected_tag_prefix": "nucleus/guacd"
    },
    "guacamole": {
        "build_dir": "/opt/ansible/files/build/guacamole/fy26q3",
        "dockerfile": "/opt/ansible/files/build/guacamole/fy26q3/Dockerfile",
        "scripts_dir": "/opt/ansible/files/build/guacamole/fy26q3/scripts",
        "expected_tag_prefix": "nucleus/guacamole"
    }
}

REPORT = {}

def run(cmd):
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = proc.communicate()
        return proc.returncode, out.strip(), err.strip()
    except Exception as e:
        return 1, "", str(e)

def check_dir(path):
    return os.path.isdir(path)

def check_file(path):
    return os.path.isfile(path)

def check_scripts(path):
    if not os.path.isdir(path):
        return False, "scripts directory missing", []
    missing = []
    not_exec = []
    for f in os.listdir(path):
        full = os.path.join(path, f)
        if not os.path.isfile(full):
            continue
        if not os.access(full, os.X_OK):
            not_exec.append(f)
    return True, None, not_exec

def get_local_images():
    rc, out, err = run(["docker", "images", "--format", "{{.Repository}}:{{.Tag}}"])
    if rc != 0:
        return []
    return out.splitlines()

def analyze_container(name, cfg):
    result = {}

    # 1. Build directory
    result["build_dir_exists"] = check_dir(cfg["build_dir"])

    # 2. Dockerfile
    result["dockerfile_exists"] = check_file(cfg["dockerfile"])

    # 3. Scripts directory + executability
    scripts_ok, scripts_err, not_exec = check_scripts(cfg["scripts_dir"])
    result["scripts_dir_exists"] = scripts_ok
    result["scripts_dir_error"] = scripts_err
    result["non_executable_scripts"] = not_exec

    # 4. Check for build logs
    build_log = os.path.join(cfg["build_dir"], "build.log")
    if check_file(build_log):
        with open(build_log) as f:
            log = f.read()
        result["build_log_exists"] = True
        result["build_log_contains_error"] = ("error" in log.lower() or "failed" in log.lower())
    else:
        result["build_log_exists"] = False
        result["build_log_contains_error"] = None

    # 5. Check actual built images
    images = get_local_images()
    result["local_images"] = images

    # 6. Check expected tag
    expected = cfg["expected_tag_prefix"]
    matching = [i for i in images if i.startswith(expected)]
    result["matching_tags"] = matching

    REPORT[name] = result

def main():
    for name, cfg in CONTAINERS.items():
        analyze_container(name, cfg)
    print(json.dumps(REPORT, indent=4))

if __name__ == "__main__":
    main()
