#!/usr/bin/env python3
import os
import subprocess
import json
from pathlib import Path

# -----------------------------
# CONFIGURATION
# -----------------------------
CONTAINERS = {
    "guacd": {
        "version_file": "/opt/ansible/files/build/guacd/fy26q3/VERSION",
        "build_dir": "/opt/ansible/files/build/guacd/fy26q3",
        "image_prefix": "nucleus/guacd"
    },
    "guacamole": {
        "version_file": "/opt/ansible/files/build/guacamole/fy26q3/VERSION",
        "build_dir": "/opt/ansible/files/build/guacamole/fy26q3",
        "image_prefix": "nucleus/guacamole"
    }
}

REPORT = {}


def run(cmd):
    """Run a shell command and return (rc, stdout, stderr)."""
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        out, err = proc.communicate()
        return proc.returncode, out.strip(), err.strip()
    except Exception as e:
        return 1, "", str(e)


def check_version_file(path):
    if not os.path.exists(path):
        return False, "VERSION file missing"
    try:
        with open(path) as f:
            version = f.read().strip()
        return True, version
    except Exception as e:
        return False, f"Error reading VERSION: {e}"


def check_image_exists(image):
    rc, out, err = run(["docker", "images", "--format", "{{.Repository}}:{{.Tag}}"])
    if rc != 0:
        return False, f"Docker error: {err}"
    return image in out.splitlines(), None


def check_save_possible(image, build_dir):
    """Check if docker save *would* work."""
    test_path = os.path.join(build_dir, "diag-test-save.tar")
    rc, out, err = run(["docker", "save", image, "-o", test_path])
    if os.path.exists(test_path):
        os.remove(test_path)
    if rc != 0:
        return False, err
    return True, None


def analyze_container(name, cfg):
    result = {}

    # -----------------------------
    # 1. DETECTION
    # -----------------------------
    ok, version = check_version_file(cfg["version_file"])
    result["version_file_ok"] = ok
    result["version"] = version if ok else None

    if not ok:
        REPORT[name] = result
        return

    image_tag = f"{cfg['image_prefix']}:{version}"
    result["expected_image"] = image_tag

    # -----------------------------
    # 2. PULL / BUILD CHECK
    # -----------------------------
    exists, err = check_image_exists(image_tag)
    result["image_exists_locally"] = exists
    result["image_error"] = err

    # -----------------------------
    # 3. SAVE CHECK
    # -----------------------------
    if exists:
        ok, err = check_save_possible(image_tag, cfg["build_dir"])
        result["save_possible"] = ok
        result["save_error"] = err
    else:
        result["save_possible"] = False
        result["save_error"] = "Image does not exist locally"

    REPORT[name] = result


def main():
    for name, cfg in CONTAINERS.items():
        analyze_container(name, cfg)

    print(json.dumps(REPORT, indent=4))


if __name__ == "__main__":
    main()
