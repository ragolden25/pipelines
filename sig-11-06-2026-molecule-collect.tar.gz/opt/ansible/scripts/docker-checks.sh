#!/bin/bash
set -e

# Images to check (add/remove as needed)
IMAGES=(
  "nucleus/guacamole:1.6.0"
  "nucleus/guacd:1.6.0"
  "nucleus/postgres:18.4"
  "nucleus/nginx:1.31.2"
)

TEST_IMAGE="nucleus/guacamole:1.6.0"
TEST_CONTAINER="guac-test"
DB_HOST="<db-host>"     # <-- replace with actual host
DB_PORT="5432"
PROXY_URL="https://guac.nuc2.scires.com"

echo "=== SELinux Mode Check ==="
getenforce

echo "=== SELinux AVC Denial Check (recent) ==="
sudo ausearch -m avc -ts recent || echo "No recent AVC denials."

echo
echo "=== Per-Image Non-root Execution Check ==="
for img in "${IMAGES[@]}"; do
  echo -n "$img: "
  docker inspect "$img" | jq -r '.[0].Config.User'
done

echo
echo "=== Per-Image Capability Drop Check ==="
for img in "${IMAGES[@]}"; do
  echo "--- $img ---"
  CID=$(docker run -d "$img" sleep infinity)
  docker inspect "$CID" | jq -r '.[0].HostConfig.CapDrop'
  docker rm -f "$CID" >/dev/null
done

echo
echo "=== Per-Image Shell / Package Manager Check ==="
for img in "${IMAGES[@]}"; do
  echo "--- $img ---"

  # Check if /bin/sh exists
  if docker run --rm "$img" sh -c "exit 0" >/dev/null 2>&1; then
    docker run --rm "$img" sh -c '
      for bin in bash sh apt dpkg; do
        which $bin && echo "$bin FOUND" || echo "$bin not found";
      done
    '
  else
    echo "No shell present in $img"
  fi
done

echo
echo "=== Per-Image Compiler / Debugger Check ==="
for img in "${IMAGES[@]}"; do
  echo "--- $img ---"

  if docker run --rm "$img" sh -c "exit 0" >/dev/null 2>&1; then
    docker run --rm "$img" sh -c '
      for bin in gcc g++ make strace gdb apk yum dnf rpm; do
        which $bin && echo "$bin FOUND (unexpected)" || echo "$bin not found";
      done
    '
  else
    echo "No shell present — skipping compiler/debugger check"
  fi
done

echo
echo "=== Port 8080 Conflict Check ==="
PORT_8080_CONTAINER=$(docker ps --format '{{.Names}} {{.Ports}}' | grep '0.0.0.0:8080' | awk '{print $1}')

if [ -n "$PORT_8080_CONTAINER" ]; then
  echo "Port 8080 is in use by: $PORT_8080_CONTAINER"
  echo "Stopping $PORT_8080_CONTAINER..."
  docker stop "$PORT_8080_CONTAINER"
else
  echo "Port 8080 is free."
fi

echo
echo "=== Start Test Container ==="
docker rm -f "$TEST_CONTAINER" >/dev/null 2>&1 || true
docker run -d --name "$TEST_CONTAINER" -p 8080:8080 "$TEST_IMAGE"
sleep 5

echo
echo "=== Tomcat Startup Check ==="
docker logs "$TEST_CONTAINER" | grep -Ei \
  "Starting service|Servlet engine|Deploying web application|ProtocolHandler|Server initialization" \
  || echo "Tomcat startup message not found."

echo
echo "=== Guacamole Webapp Check (HTTP) ==="
curl -I http://localhost:8080/guacamole || echo "Guacamole webapp not reachable."

echo
echo "=== Database Connectivity Check ==="
nc -zv "$DB_HOST" "$DB_PORT" && echo "DB reachable." || echo "DB NOT reachable!"

echo
echo "=== Reverse Proxy Check (HTTPS, no SSL verify) ==="
curl -k -I "$PROXY_URL" || echo "Reverse proxy not reachable."

echo
echo "=== Cleanup ==="
docker rm -f "$TEST_CONTAINER" >/dev/null 2>&1 || true

if [ -n "$PORT_8080_CONTAINER" ]; then
  echo "Restarting original container: $PORT_8080_CONTAINER"
  docker start "$PORT_8080_CONTAINER"
fi

echo
echo "=== Validation Complete ==="
