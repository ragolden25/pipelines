#!/usr/bin/env bash
set -euo pipefail

echo "=== Weekly Docker Cleanup ==="

# Remove unused images, containers, networks, and build cache
docker system prune -af --volumes

echo "Docker cleanup complete."
