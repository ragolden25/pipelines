#!/bin/bash
# download_ansible_wheels.sh — Download all Python wheels for offline Ansible installation
# Skips RHEL system packages (cockpit, pycairo, PyGObject, rpm, selinux, etc.)
# Usage:
#   ./download_ansible_wheels.sh /path/to/requirements.txt [output_dir]

set -euo pipefail

REQ_FILE=${1:-}
OUTPUT_DIR=${2:-~/ansible_wheels}

if [[ -z "${REQ_FILE}" || ! -f "${REQ_FILE}" ]]; then
  echo "Usage: $0 /path/to/requirements.txt [output_dir]"
  exit 1
fi

TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
DOWNLOAD_DIR="${OUTPUT_DIR}/wheels_${TIMESTAMP}"
ARCHIVE="${OUTPUT_DIR}/ansible_wheels_${TIMESTAMP}.tar.gz"
LOG_FILE="${OUTPUT_DIR}/download_log_${TIMESTAMP}.txt"
FILTERED_REQ="/tmp/requirements_filtered_${TIMESTAMP}.txt"
SKIP_FILE="/tmp/pip_skiplist.txt"

# ------------------------------------------------------------
# System-provided Python modules to skip (RPM-installed on RHEL)
# ------------------------------------------------------------
cat > "${SKIP_FILE}" <<'EOF'
cockpit
dasbus
dbus-python
gpg
libcomps
nftables
perf
psutil
pykickstart
python-linux-procfs
pyinotify
pyudev
pycairo
PyGObject
rpm
selinux
sepolicy
setools
setroubleshoot
sos
subscription-manager
systemd-python
EOF

mkdir -p "${DOWNLOAD_DIR}" "${OUTPUT_DIR}"

echo "=== Preparing filtered requirements file ==="
cp "${REQ_FILE}" "${FILTERED_REQ}"

# Remove comments and blanks
sed -i '/^#/d;/^$/d' "${FILTERED_REQ}"

# Drop system packages and local @file:// paths
while read -r skip_pkg; do
  sed -i "/^${skip_pkg}==/d" "${FILTERED_REQ}"
  sed -i "/^${skip_pkg} @/d" "${FILTERED_REQ}"
done < "${SKIP_FILE}"

echo "Filtered requirements saved as ${FILTERED_REQ}"
echo

echo "=== Downloading Python wheels for offline Ansible environment ==="
echo "Requirements file: ${FILTERED_REQ}"
echo "Download directory: ${DOWNLOAD_DIR}"
echo "Log file: ${LOG_FILE}"
echo

python3 -m pip install --upgrade pip wheel > /dev/null 2>&1 || true

pip download --no-deps -r "${FILTERED_REQ}" -d "${DOWNLOAD_DIR}" 2>&1 | tee "${LOG_FILE}"

echo
echo "Creating archive ${ARCHIVE} ..."
tar -czvf "${ARCHIVE}" -C "${OUTPUT_DIR}" "wheels_${TIMESTAMP}"

echo
echo "✅ Wheel download complete!"
echo "Archive ready for transfer: $(realpath "${ARCHIVE}")"
echo
echo "To copy to offline system:"
echo "  scp ${ARCHIVE} root@newcontrol:/tmp/"
echo
echo "Then install on the offline server with:"
echo "  /opt/ansible/install_ansible_wheels_offline.sh /tmp/$(basename "${ARCHIVE}") ${REQ_FILE}"
