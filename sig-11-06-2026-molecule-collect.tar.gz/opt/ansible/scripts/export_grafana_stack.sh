#!/bin/bash
set -euo pipefail

# Modes:
#   rsync  - push to deployment server
#   gzip   - create local/deployment gzip artifact
MODE="${1:-rsync}"

# Enforce privilege model
if [ "${MODE}" = "rsync" ]; then
    if [ "$(id -u)" -eq 0 ]; then
        echo "ERROR: rsync mode cannot be run as root."
        exit 1
    fi
elif [ "${MODE}" = "gzip" ]; then
    if [ "$(id -u)" -ne 0 ]; then
        echo "ERROR: gzip mode must be run as root."
        exit 1
    fi
else
    echo "Unknown mode: ${MODE}"
    exit 1
fi

# Detect if running on deployment server (hard-coded IP)
if hostname -I | grep -q "192.168.110.250"; then
    IS_DEPLOYMENT=true
else
    IS_DEPLOYMENT=false
fi

# Common constants (non-path)
DTG=$(date +"%Y%m%d-%H%M%S")
ARCHIVE_NAME="configure_grafana_stack-${DTG}.tar.gz"

# --------------------------------------------------------------------
# Helper: copy only allowed content into staging (paths are literal)
# --------------------------------------------------------------------
copy_allowed_content() {
    # Clean staging
    rm -rf /opt/ansible/export_tmp
    mkdir -p /opt/ansible/export_tmp/nucleus/playbooks
    mkdir -p /opt/ansible/export_tmp/nucleus/roles
    mkdir -p /opt/ansible/export_tmp/scripts
    mkdir -p /opt/ansible/export_tmp/grafana

    # Playbooks
    cp -p /opt/ansible/nucleus/playbooks/configure_grafana_stack.yml \
          /opt/ansible/export_tmp/nucleus/playbooks/
    cp -p /opt/ansible/nucleus/playbooks/play_configure_grafana_stack.sh \
          /opt/ansible/export_tmp/nucleus/playbooks/

    # Role: configure_grafana_stack ONLY
    cp -a /opt/ansible/nucleus/roles/configure_grafana_stack \
          /opt/ansible/export_tmp/nucleus/roles/

    # Role: install_docker_python ONLY
    cp -a /opt/ansible/nucleus/roles/install_docker_python \
          /opt/ansible/export_tmp/nucleus/roles/

    # Script
    cp -p /opt/ansible/scripts/docker_cis_remediate.sh \
          /opt/ansible/export_tmp/scripts/

    # Inventory file
    cp -p /home/ansible/inventory.ini /opt/ansible/export_tmp/

    # Grafana current quarter (minus docker-compose.yml.j2)
    rsync -av \
        --exclude="docker-compose.yml.j2" \
        /opt/ansible/files/grafana/current/ \
        /opt/ansible/export_tmp/grafana/
}

# --------------------------------------------------------------------
# Deployment server mode: gzip artifact only
# --------------------------------------------------------------------
if [ "${IS_DEPLOYMENT}" = true ]; then
    echo "Running on deployment server. Creating gzip artifact only."

    copy_allowed_content

    tar -czf /opt/ansible/files/${ARCHIVE_NAME} -C /opt/ansible/export_tmp .
    echo "Created: /opt/ansible/files/${ARCHIVE_NAME}"

    rm -rf /opt/ansible/export_tmp
    exit 0
fi

# --------------------------------------------------------------------
# Control node mode
# --------------------------------------------------------------------
echo "Running on Ansible control node."

if [ "${MODE}" = "rsync" ]; then
    echo "Performing rsync export to deployment server..."

    # -----------------------------
    # Non-destructive syncs (no --delete)
    # -----------------------------

    # Playbooks
    rsync -av \
        /opt/ansible/nucleus/playbooks/configure_grafana_stack.yml \
        ansible@192.168.110.250:/opt/ansible/nucleus/playbooks/

    rsync -av \
        /opt/ansible/nucleus/playbooks/play_configure_grafana_stack.sh \
        ansible@192.168.110.250:/opt/ansible/nucleus/playbooks/

    # Script
    rsync -av \
        /opt/ansible/scripts/docker_cis_remediate.sh \
        ansible@192.168.110.250:/opt/ansible/scripts/

    # Inventory
    rsync -av \
        /home/ansible/inventory.ini \
        ansible@192.168.110.250:/home/ansible/

    # -----------------------------
    # STRICTLY BOUNDED DESTRUCTIVE SYNCs
    # Only these two roles, nothing else.
    # -----------------------------

    # Role: configure_grafana_stack
    rsync -av --delete \
        /opt/ansible/nucleus/roles/configure_grafana_stack/ \
        ansible@192.168.110.250:/opt/ansible/nucleus/roles/configure_grafana_stack/

    # Role: install_docker_python
    rsync -av --delete \
        /opt/ansible/nucleus/roles/install_docker_python/ \
        ansible@192.168.110.250:/opt/ansible/nucleus/roles/install_docker_python/

    echo "Restoring ansible-admin group ownership on control node..."
    chgrp -R ansible-admin /opt/ansible/nucleus || true
    chgrp -R ansible-admin /opt/ansible/scripts || true
    chgrp -R ansible-admin /opt/ansible/files || true

    echo "Rsync export complete."
    exit 0
fi

# --------------------------------------------------------------------
# Control node gzip mode
# --------------------------------------------------------------------
if [ "${MODE}" = "gzip" ]; then
    echo "Performing gzip export on control node..."

    copy_allowed_content

    echo "Applying ansible-admin group ownership on control node..."
    chgrp -R ansible-admin /opt/ansible/export_tmp || true

    tar -czf /opt/ansible/files/${ARCHIVE_NAME} -C /opt/ansible/export_tmp .
    echo "Created: /opt/ansible/files/${ARCHIVE_NAME}"

    rm -rf /opt/ansible/export_tmp
    exit 0
fi
