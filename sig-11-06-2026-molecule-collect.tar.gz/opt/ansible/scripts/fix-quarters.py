#!/usr/bin/env python3
import re
from pathlib import Path

# Files to patch
MAIN_YML = Path("/opt/ansible/nucleus/roles/build_guac_release/tasks/main.yml")
DEFAULTS_YML = Path("/opt/ansible/nucleus/roles/build_guac_release/defaults/main.yml")
PLAYBOOK = Path("/opt/ansible/nucleus/playbooks/build_guac_release.yml")

def patch_main_yml():
    text = MAIN_YML.read_text()

    # Insert normalization block at top if missing
    norm_block = (
        "- name: Normalize quarter variables from any source\n"
        " set_fact:\n"
        " quarter: \"{{ quarter | regex_replace('^quarter=', '') }}\"\n"
        " previous_quarter: \"{{ previous_quarter | regex_replace('^previous_quarter=', '') }}\"\n"
        " when:\n"
        " - quarter is defined\n"
        " - previous_quarter is defined\n\n"
    )

    if "Normalize quarter variables" not in text:
        text = norm_block + text

    # Fix stdout_lines parsing
    text = re.sub(
        r"quarter:\s*\"{{ quarter_info.stdout_lines\[0\] }}\"",
        "quarter: \"{{ quarter_info.stdout_lines[0].split('=')[1] }}\"",
        text,
    )
    text = re.sub(
        r"previous_quarter:\s*\"{{ quarter_info.stdout_lines\[1\] }}\"",
        "previous_quarter: \"{{ quarter_info.stdout_lines[1].split('=')[1] }}\"",
        text,
    )

    MAIN_YML.write_text(text)
    print("[OK] Patched main.yml")


def patch_defaults_yml():
    if not DEFAULTS_YML.exists():
        print("[SKIP] defaults/main.yml not found")
        return

    text = DEFAULTS_YML.read_text()
    new = re.sub(r"(?m)^.*quarter.*$", "", text)
    DEFAULTS_YML.write_text(new)
    print("[OK] Removed quarter from defaults")


def patch_playbook():
    if not PLAYBOOK.exists():
        print("[SKIP] build_guac_release.yml not found")
        return

    text = PLAYBOOK.read_text()
    new = re.sub(r"(?m)^.*quarter.*$", "", text)
    PLAYBOOK.write_text(new)
    print("[OK] Removed quarter from wrapper playbook")


def main():
    print("=== Applying quarter normalization patches ===")
    patch_main_yml()
    patch_defaults_yml()
    patch_playbook()
    print("=== Done ===")


if __name__ == "__main__":
    main()
