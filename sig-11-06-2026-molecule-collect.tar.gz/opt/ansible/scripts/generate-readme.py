#!/usr/bin/env python3

import os, yaml, argparse, shutil, logging, hashlib
from datetime import datetime

SECTION_SYMBOLS = {
    "purpose": "📂",
    "tasks": "⚙️",
    "requirements": "📌",
    "verification": "✅",
    "notes": "📖",
    "usage": "🚀"
}

# Configure logging with DTG
dtg = datetime.now().strftime("%Y%m%d_%H%M%S")
logfile = f"generate_readmes_{dtg}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(logfile),
        logging.StreamHandler()
    ]
)

# ---------------------------------------------------------------------------
# Generic-README detection (checksum-based)
# ---------------------------------------------------------------------------
# Confirmed via sha256sum against two independently-generated
# `ansible-galaxy init` README.md files (2026-09-29) - byte-identical.
# If ansible-galaxy is ever upgraded and its init template text changes,
# this simply stops matching (fails closed: skips instead of overwriting).
# Re-run sha256sum on a fresh init'd role's README.md and update this value
# if that ever happens.
GENERIC_README_SHA256 = "cc751d75266f757a38189f15d54e548dc87706f14a39756995c27b49eaca8a07"


def is_generic_readme(path):
    """True only if the file is an untouched ansible-galaxy init README.md."""
    with open(path, "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()
    return digest == GENERIC_README_SHA256


# ---------------------------------------------------------------------------
# Task collection: expands block/rescue/always and include_tasks/import_tasks
# ---------------------------------------------------------------------------
INCLUDE_KEYS = (
    "include_tasks", "import_tasks",
    "ansible.builtin.include_tasks", "ansible.builtin.import_tasks",
)
BLOCK_KEYS = ("block", "rescue", "always")


def collect_tasks(task_list, base_dir):
    """Recursively walk a list of Ansible tasks, returning a tree of
    {"name": ..., "children": [...]}.

    - block/rescue/always tasks nest their inner tasks as children instead
      of being silently dropped (the old flat name-only scan missed these
      entirely).
    - include_tasks/import_tasks (plain or FQCN form) are resolved relative
      to base_dir and their tasks recursively pulled in as children, so a
      phase-based role (main.yml -> stage-environment.yml, db-import.yml,
      ...) documents its real task detail instead of just the four
      top-level include_tasks names.
    """
    collected = []
    if not isinstance(task_list, list):
        return collected

    for t in task_list:
        if not isinstance(t, dict):
            continue
        name = t.get("name")

        # block / rescue / always are sibling keys on the same task item
        has_block_keys = False
        nested_children = []
        for key in BLOCK_KEYS:
            if key in t and isinstance(t[key], list):
                has_block_keys = True
                nested_children.extend(collect_tasks(t[key], base_dir))
        if has_block_keys:
            collected.append({"name": name or "(block)", "children": nested_children})
            continue

        # include_tasks / import_tasks
        include_target = None
        for key in INCLUDE_KEYS:
            if key in t:
                val = t[key]
                include_target = val if isinstance(val, str) else (val or {}).get("file")
                break

        if include_target:
            include_path = os.path.join(base_dir, include_target)
            children = []
            if os.path.exists(include_path):
                try:
                    with open(include_path) as f:
                        sub_tasks = yaml.safe_load(f) or []
                    children = collect_tasks(sub_tasks, base_dir)
                except yaml.YAMLError as e:
                    logging.warning(f"Failed to parse included file {include_path}: {e}")
            else:
                logging.warning(f"Included tasks file not found: {include_path}")
            collected.append({"name": name or include_target, "children": children})
            continue

        if name:
            collected.append({"name": name, "children": []})

    return collected


def flatten_task_names(nodes):
    """Flatten a task tree back into a plain list of names, for drift
    comparison in evaluate_readme()."""
    names = []
    for n in nodes:
        names.append(n["name"])
        names.extend(flatten_task_names(n["children"]))
    return names


def render_task_tree(nodes, indent=0):
    """Render a task tree as nested Markdown bullets."""
    lines = []
    prefix = "  " * indent
    for n in nodes:
        lines.append(f"{prefix}- {n['name']}\n")
        if n["children"]:
            lines.extend(render_task_tree(n["children"], indent + 1))
    return lines


# ---------------------------------------------------------------------------
# README rendering
# ---------------------------------------------------------------------------
def format_readme(sections, output_file):
    lines = [f"# {sections.get('title','README')}\n\n"]

    for key in ["purpose", "tasks", "requirements", "verification", "notes", "usage"]:
        if key not in sections:
            continue

        symbol = SECTION_SYMBOLS.get(key, "")
        header = key.capitalize()
        lines.append(f"## {symbol} {header}\n")
        content = sections[key]

        if key == "tasks" and isinstance(content, list) and content and isinstance(content[0], dict) and "children" in content[0]:
            # Task tree (from collect_tasks)
            lines.extend(render_task_tree(content))

        elif isinstance(content, list):
            for item in content:
                if key == "verification" and isinstance(item, str) and item.startswith("bash:"):
                    cmd = item.replace("bash:", "").strip()
                    lines.append("```bash\n" + cmd + "\n```\n")
                elif key == "usage":
                    lines.append("```yaml\n" + item.strip() + "\n```\n")
                else:
                    lines.append(f"- {item}\n")

        elif isinstance(content, dict):
            for k, v in content.items():
                lines.append(f"- {k}: {v}\n")

        else:
            if key == "usage":
                lines.append("```yaml\n" + str(content).strip() + "\n```\n")
            else:
                lines.append(str(content) + "\n")

        lines.append("\n")

    with open(output_file, "w") as f:
        f.writelines(lines)


def archive_readme(role_path, readme_file):
    """Move an existing README.md into <role>/archive/ before it gets
    overwritten, tagged with the run's date-time-group so repeated runs
    don't clobber earlier backups."""
    archive_dir = os.path.join(role_path, "archive")
    os.makedirs(archive_dir, exist_ok=True)
    backup_name = f"README.md.{dtg}.bak"
    shutil.move(readme_file, os.path.join(archive_dir, backup_name))
    logging.info(f"Archived existing README.md for {os.path.basename(role_path)} -> archive/{backup_name}")


def _extract_tasks_section(content):
    """Return only the lines under the '## ... Tasks' header, up to the
    next '## ' header. Scoping to just this section keeps evaluate_readme
    from flagging Requirements/Notes/Usage bullets as bogus extra tasks."""
    lines = content.splitlines()
    section_lines = []
    in_tasks = False
    for line in lines:
        if line.startswith("## "):
            in_tasks = "tasks" in line.lower()
            continue
        if in_tasks:
            section_lines.append(line)
    return "\n".join(section_lines)


def evaluate_readme(readme_file, task_names):
    """Check if README.md's Tasks section contains all task names and
    flag extras, scoped to that section only."""
    if not os.path.exists(readme_file):
        return False

    with open(readme_file) as f:
        content = f.read()

    tasks_section = _extract_tasks_section(content)

    missing = [t for t in task_names if t and t not in tasks_section]
    extras = []

    for line in tasks_section.splitlines():
        stripped = line.strip()
        if stripped.startswith("- "):
            candidate = stripped[2:]
            if candidate and candidate not in task_names:
                extras.append(candidate)

    if missing:
        logging.warning(f"README.md missing {len(missing)} tasks: {missing}")
    if extras:
        logging.warning(f"README.md has {len(extras)} extra tasks not in main.yml: {extras}")

    if not missing and not extras:
        logging.info(f"README.md matches all {len(task_names)} tasks")
        return True

    return False


def scan_roles(base_dir="/opt/ansible/nucleus/roles"):
    generated = 0
    skipped = 0
    warnings = 0

    for role in os.listdir(base_dir):
        role_path = os.path.join(base_dir, role)
        tasks_dir = os.path.join(role_path, "tasks")
        tasks_file = os.path.join(tasks_dir, "main.yml")
        readme_file = os.path.join(role_path, "README.md")
        overrides_file = os.path.join(role_path, "readme_overrides.yaml")

        if not os.path.exists(tasks_file):
            logging.info(f"Skipping {role}: no tasks/main.yml found")
            skipped += 1
            continue

        # Load tasks
        try:
            with open(tasks_file) as f:
                tasks = yaml.safe_load(f) or []
        except yaml.YAMLError as e:
            logging.error(f"{role}: failed to parse tasks/main.yml ({e})")
            tasks = []
            warnings += 1

        if not isinstance(tasks, list):
            logging.warning(f"{role}: tasks file did not parse to a list")
            tasks = []
            warnings += 1

        # Recursively expand block/rescue/always and include_tasks/import_tasks
        task_tree = collect_tasks(tasks, tasks_dir)
        task_names = flatten_task_names(task_tree)

        # Base sections
        sections = {
            "title": f"{role} Role",
            "purpose": f"Automates configuration for {role}.",
            "tasks": task_tree,
            "requirements": ["Ansible control node", "Target host connectivity"],
            "notes": ["Generated automatically from tasks."],
            "usage": f"- hosts: {role}\n  roles:\n    - {role}"
        }

        # Load overrides
        if os.path.exists(overrides_file):
            with open(overrides_file) as f:
                overrides = yaml.safe_load(f) or {}
            if role in overrides:
                for k, v in overrides[role].items():
                    sections[k] = v

        # >>> TEMPLATE OVERRIDE PATCH <<<
        if "template" in sections:
            if os.path.exists(readme_file):
                archive_readme(role_path, readme_file)
            logging.info(f"Writing template README.md for {role}")
            with open(readme_file, "w") as f:
                f.write(sections["template"])
            generated += 1
            continue

        # If README missing or generic, generate
        if not os.path.exists(readme_file) or is_generic_readme(readme_file):
            if os.path.exists(readme_file):
                archive_readme(role_path, readme_file)
            logging.info(f"Generating README.md for {role}")
            format_readme(sections, readme_file)
            if task_names:
                evaluate_readme(readme_file, task_names)
            generated += 1
            continue

        # Otherwise skip
        logging.info(f"Skipping {role}: README.md already customized")
        skipped += 1

    # Summary
    print("\n=== SUMMARY ===")
    print(f"Generated: {generated}")
    print(f"Skipped:   {skipped}")
    print(f"Warnings:  {warnings}")


def process_yaml_file(yaml_file, output_file="README.md"):
    """Generate README.md from a standalone YAML file (dict or list)"""
    try:
        with open(yaml_file) as f:
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError as e:
        logging.error(f"Failed to parse {yaml_file} ({e})")
        return

    base_dir = os.path.dirname(os.path.abspath(yaml_file))

    if isinstance(data, dict):
        sections = {}
        for key in ["title", "purpose", "requirements", "tasks", "verification", "notes", "usage"]:
            if key in data:
                sections[key] = data[key]
        logging.info(f"Generating README.md from structured YAML {yaml_file}")
        format_readme(sections, output_file)

    elif isinstance(data, list):
        task_tree = collect_tasks(data, base_dir)
        task_names = flatten_task_names(task_tree)
        sections = {
            "title": f"{os.path.basename(yaml_file)} Tasks",
            "purpose": f"Generated README from {yaml_file}.",
            "tasks": task_tree,
            "requirements": ["Ansible control node", "Target host connectivity"],
            "notes": ["Generated automatically from tasks."],
            "usage": f"- hosts: all\n  tasks:\n    - include_tasks: {yaml_file}"
        }
        logging.info(f"Generating README.md from task list {yaml_file}")
        format_readme(sections, output_file)
        if task_names:
            evaluate_readme(output_file, task_names)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate README.md files for Ansible roles or a single YAML file")
    parser.add_argument("--base-dir", default="/opt/ansible/nucleus/roles",
                        help="Base directory containing Ansible roles")
    parser.add_argument("--yaml-file", help="Generate README.md from a single YAML tasks file")
    parser.add_argument("--output", default="README.md", help="Output README file name")
    args = parser.parse_args()

    if args.yaml_file:
        process_yaml_file(args.yaml_file, args.output)
    else:
        scan_roles(args.base_dir)
