#!/bin/bash
set -euo pipefail

ARCHIVE="$1"

if [ -z "${ARCHIVE:-}" ]; then
    echo "Usage: $0 <archive.tar.gz>"
    exit 1
fi

DTG=$(date +"%Y%m%d-%H%M%S")
STAGE_BASE="/opt/ansible/files/import_work"
STAGE="${STAGE_BASE}/${DTG}"

echo "Staging import in: $STAGE"
mkdir -p "$STAGE"

echo "Extracting $ARCHIVE..."
tar -xzf "$ARCHIVE" -C "$STAGE"

echo "Syncing into filesystem root..."
rsync -av "$STAGE/" "/"

echo "Fixing permissions for /opt/ansible..."
chown -R ansible:ansible /opt/ansible

echo "Import complete."
