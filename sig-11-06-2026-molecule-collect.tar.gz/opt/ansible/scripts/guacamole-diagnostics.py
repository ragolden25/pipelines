#!/usr/bin/env python3
import os
import re
import subprocess
from pathlib import Path

# ============================================================
# CONFIGURATION
# ============================================================
ROLE_PATH = Path("/opt/ansible/nucleus/roles/build_guac_release")
FILES_DIR = Path("/opt/ansible/files")
LOG_DIR = Path("/home/ansible")
PLAYBOOK_PATH = Path("/opt/ansible/nucleus/playbooks/build_guac_release.yml")

STAGES = [
    ("Determine quarter", r"Determine quarter automatically"),
    ("Normalize quarter vars", r"Normalize quarter variables"),
    ("Create directories", r"Create and seed quarterly directories"),
    ("Clean quarter directory", r"Clean new quarter directory"),
    ("Detect versions", r"Detect component versions"),
    ("Generate metadata", r"Generate metadata files"),
    ("Build images", r"Build images"),
    ("Pull images", r"Pull images"),
    ("Save images", r"Save built images"),
    ("Render compose/env", r"Render docker-compose.yml and .env"),
    ("Set permissions", r"Normalize permissions"),
]

ERROR_PATTERNS = [
    r"FAILED!",
    r"fatal:",
    r"ERROR",
    r"rc=[1-9]",
    r"Traceback",
]

SCRIPT_PATTERNS = [
    r"cmd:\s*\"([^\"]+\.sh[^\"]*)\"",
    r"cmd:\s*'([^']+\.sh[^']*)'",
    r"command:\s*\"([^\"]+\.sh[^\"]*)\"",
    r"command:\s*'([^']+\.sh[^']*)'",
    r"shell:\s*\"([^\"]+\.sh[^\"]*)\"",
    r"shell:\s*'([^']+\.sh[^']*)'",
    r"scripts/([A-Za-z0-9_\-\.]+\.sh)",
]

TEMPLATE_PATTERNS = [
    r"src:\s*\"([^\"]+\.j2)\"",
    r"src:\s*'([^']+\.j2)'",
]

INCLUDE_PATTERNS = [
    r"include_tasks:\s*([A-Za-z0-9_\-\.]+\.yml)",
    r"import_tasks:\s*([A-Za-z0-9_\-\.]+\.yml)",
]

# ============================================================
# LOG ANALYSIS
# ============================================================
def load_latest_log():
    logs = sorted(LOG_DIR.glob("build_guac_release*.log"))
    return logs[-1] if logs else None

def read_lines(path):
    return path.read_text().splitlines()

def find_first_error(lines):
    for i, line in enumerate(lines):
        for pat in ERROR_PATTERNS:
            if re.search(pat, line, re.IGNORECASE):
                return i, line
    return None, None

def detect_stages(lines):
    hits = []
    for stage_name, pattern in STAGES:
        for i, line in enumerate(lines):
            if re.search(pattern, line):
                hits.append((stage_name, i))
                break
    return hits

def print_error_context(lines, idx, context=20):
    print("\n=== ERROR CONTEXT ===")
    start = max(0, idx - context)
    end = min(len(lines), idx + context)
    for i in range(start, end):
        prefix = ">> " if i == idx else "   "
        print(f"{prefix}{lines[i]}")

# ============================================================
# TASK FILE SCANNING
# ============================================================
def scan_task_file(path):
    text = path.read_text()
    scripts, templates, includes = [], [], []

    for pat in SCRIPT_PATTERNS:
        scripts += [m.strip() for m in re.findall(pat, text)]

    for pat in TEMPLATE_PATTERNS:
        templates += [m.strip() for m in re.findall(pat, text)]

    for pat in INCLUDE_PATTERNS:
        includes += [m.strip() for m in re.findall(pat, text)]

    return scripts, templates, includes

def validate_path(base, rel):
    p = Path(rel)
    if p.is_absolute():
        return p.exists(), p
    else:
        return (base / p).exists(), (base / p)

# ============================================================
# SCRIPT VALIDATION
# ============================================================
def validate_script(path):
    results = {
        "exists": path.exists(),
        "executable": False,
        "shebang": False,
        "no_crlf": False,
        "has_set_e": False,
        "has_exit_0": False,
    }

    if not path.exists():
        return results

    mode = path.stat().st_mode
    results["executable"] = bool(mode & 0o111)

    text = path.read_text(errors="ignore")

    results["shebang"] = text.startswith("#!")
    results["no_crlf"] = "\r\n" not in text
    results["has_set_e"] = "set -e" in text
    results["has_exit_0"] = "exit 0" in text

    return results

# ============================================================
# DOCKERFILE VALIDATION
# ============================================================
def validate_dockerfile(path):
    results = {
        "exists": path.exists(),
        "valid_from": False,
        "valid_copy": True,
        "valid_entrypoint": False,
    }

    if not path.exists():
        return results

    text = path.read_text()

    results["valid_from"] = bool(re.search(r"^FROM\s+\S+", text, re.MULTILINE))

    for match in re.findall(r"COPY\s+(\S+)", text):
        src = path.parent / match
        if not src.exists():
            results["valid_copy"] = False

    results["valid_entrypoint"] = "ENTRYPOINT" in text or "CMD" in text

    return results

# ============================================================
# TEMPLATE VALIDATION
# ============================================================
def validate_template(path):
    results = {
        "exists": path.exists(),
        "syntax_ok": True,
    }

    if not path.exists():
        return results

    text = path.read_text()

    if text.count("{{") != text.count("}}"):
        results["syntax_ok"] = False

    return results

# ============================================================
# versions.env VALIDATION
# ============================================================
def validate_versions_env(path):
    results = {
        "exists": path.exists(),
        "no_empty_values": True,
        "no_duplicates": True,
    }

    if not path.exists():
        return results

    lines = path.read_text().splitlines()
    seen = set()

    for line in lines:
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        if key in seen:
            results["no_duplicates"] = False
        seen.add(key)
        if not val.strip():
            results["no_empty_values"] = False

    return results

# ============================================================
# DIRECTORY STRUCTURE VALIDATION
# ============================================================
def validate_directories():
    results = {}
    for d in [
        "/opt/ansible/files/avocado",
        "/opt/ansible/files/build/guacamole",
        "/opt/ansible/files/build/guacd",
    ]:
        p = Path(d)
        results[d] = p.exists()
    return results

# ============================================================
# ANSIBLE SYNTAX VALIDATION
# ============================================================
def validate_ansible_syntax():
    try:
        result = subprocess.run(
            ["ansible-playbook", "--syntax-check", str(PLAYBOOK_PATH)],
            capture_output=True,
            text=True
        )
        return {
            "rc": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except Exception as e:
        return {"rc": 1, "stderr": str(e)}

# ============================================================
# MAIN
# ============================================================
def main():
    print("\n=== FULL DIAGNOSTIC: build_guac_release ===")

    # --------------------------------------------------------
    # LOG ANALYSIS
    # --------------------------------------------------------
    log_path = load_latest_log()
    if not log_path:
        print("[!] No log files found in /home/ansible")
        return

    print(f"\nUsing log: {log_path}")
    lines = read_lines(log_path)

    stage_hits = detect_stages(lines)
    print("\n=== PIPELINE STAGES EXECUTED ===")
    for stage, line_no in stage_hits:
        print(f" - {stage} (line {line_no})")

    missing = [s for s, _ in STAGES if s not in {x[0] for x in stage_hits}]
    if missing:
        print("\n=== MISSING STAGES ===")
        for m in missing:
            print(f" - {m}")

    idx, err = find_first_error(lines)
    if err:
        print(f"\n=== FIRST ERROR FOUND ===\nLine {idx}: {err}")
        print_error_context(lines, idx)
    else:
        print("\n=== NO ERRORS FOUND ===")

    # --------------------------------------------------------
    # ROLE INTEGRITY CHECK
    # --------------------------------------------------------
    print("\n=== ROLE INTEGRITY CHECK ===")

    all_scripts, all_templates, all_includes = [], [], []

    for task_file in ROLE_PATH.glob("tasks/*.yml"):
        print(f"\nScanning: {task_file.name}")
        scripts, templates, includes = scan_task_file(task_file)
        all_scripts += scripts
        all_templates += templates
        all_includes += includes

    print("\n=== SCRIPT REFERENCES ===")
    for s in sorted(set(all_scripts)):
        exists, full = validate_path(FILES_DIR, s)
        print(f" - {s} → {full} [{'OK' if exists else 'MISSING'}]")

    print("\n=== TEMPLATE REFERENCES ===")
    for t in sorted(set(all_templates)):
        exists, full = validate_path(FILES_DIR, t)
        print(f" - {t} → {full} [{'OK' if exists else 'MISSING'}]")

    print("\n=== INCLUDE TASK REFERENCES ===")
    for inc in sorted(set(all_includes)):
        inc_path = ROLE_PATH / "tasks" / inc
        print(f" - {inc} → {inc_path} [{'OK' if inc_path.exists() else 'MISSING'}]")

    print("\n=== EXECUTABLE CHECK ===")
    for s in sorted(set(all_scripts)):
        exists, full = validate_path(FILES_DIR, s)
        if exists:
            mode = full.stat().st_mode
            print(f" - {full} executable: {bool(mode & 0o111)}")
        else:
            print(f" - {s} → missing")

    # --------------------------------------------------------
    # DOCKERFILE VALIDATION
    # --------------------------------------------------------
    print("\n=== DOCKERFILE VALIDATION ===")
    dockerfiles = [
        FILES_DIR / "build/guacamole/Dockerfile",
        FILES_DIR / "build/guacd/Dockerfile",
        FILES_DIR / "build/nginx/Dockerfile",
        FILES_DIR / "build/postgres/Dockerfile",
    ]

    for df in dockerfiles:
        res = validate_dockerfile(df)
        print(f"\nDockerfile: {df}")
        for k, v in res.items():
            print(f" - {k}: {v}")

    # --------------------------------------------------------
    # TEMPLATE VALIDATION
    # --------------------------------------------------------
    print("\n=== TEMPLATE VALIDATION ===")
    for t in sorted(set(all_templates)):
        exists, full = validate_path(FILES_DIR, t)
        res = validate_template(full)
        print(f"\nTemplate: {full}")
        for k, v in res.items():
            print(f" - {k}: {v}")

    # --------------------------------------------------------
    # versions.env VALIDATION
    # --------------------------------------------------------
    print("\n=== versions.env VALIDATION ===")
    versions_path = FILES_DIR / "avocado/current/versions.env"
    res = validate_versions_env(versions_path)
    for k, v in res.items():
        print(f" - {k}: {v}")

    # --------------------------------------------------------
    # DIRECTORY STRUCTURE VALIDATION
    # --------------------------------------------------------
    print("\n=== DIRECTORY STRUCTURE VALIDATION ===")
    dirs = validate_directories()
    for d, ok in dirs.items():
        print(f" - {d}: {'OK' if ok else 'MISSING'}")

    # --------------------------------------------------------
    # ANSIBLE SYNTAX VALIDATION
    # --------------------------------------------------------
    print("\n=== ANSIBLE SYNTAX CHECK ===")
    syntax = validate_ansible_syntax()
    print(f"Return code: {syntax['rc']}")
    print(syntax["stdout"])
    print(syntax["stderr"])

    print("\n=== DIAGNOSTIC COMPLETE ===\n")


if __name__ == "__main__":
    main()
