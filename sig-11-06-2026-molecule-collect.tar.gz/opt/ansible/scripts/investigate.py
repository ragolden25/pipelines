import os
import yaml

def is_yaml_file(filename):
    return filename.endswith(('.yml', '.yaml'))

def load_yaml(path):
    try:
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    except Exception:
        return None

def scan_ansible_tree(root_dir):
    result = {
        'playbooks': [],
        'roles': {},
        'group_vars': [],
        'host_vars': [],
        'other_vars': []
    }

    for dirpath, dirnames, filenames in os.walk(root_dir):
        rel_path = os.path.relpath(dirpath, root_dir)

        # Skip hidden dirs
        if any(part.startswith('.') for part in rel_path.split(os.sep)):
            continue

        # Playbooks (outside roles/, vars/, etc.)
        if 'roles' not in rel_path and 'vars' not in rel_path:
            for file in filenames:
                if is_yaml_file(file):
                    full_path = os.path.join(rel_path, file)
                    result['playbooks'].append(full_path)

        # Roles
        parts = rel_path.split(os.sep)
        if len(parts) >= 2 and parts[0] == 'roles':
            role_name = parts[1]
            if role_name not in result['roles']:
                result['roles'][role_name] = {'tasks': [], 'handlers': [], 'vars': [], 'templates': [], 'files': []}

            for file in filenames:
                full_path = os.path.join(rel_path, file)
                if 'tasks' in rel_path:
                    result['roles'][role_name]['tasks'].append(full_path)
                elif 'handlers' in rel_path:
                    result['roles'][role_name]['handlers'].append(full_path)
                elif 'vars' in rel_path:
                    result['roles'][role_name]['vars'].append(full_path)
                elif 'templates' in rel_path:
                    result['roles'][role_name]['templates'].append(full_path)
                elif 'files' in rel_path:
                    result['roles'][role_name]['files'].append(full_path)

        # Vars
        if 'group_vars' in rel_path:
            for file in filenames:
                if is_yaml_file(file):
                    result['group_vars'].append(os.path.join(rel_path, file))
        elif 'host_vars' in rel_path:
            for file in filenames:
                if is_yaml_file(file):
                    result['host_vars'].append(os.path.join(rel_path, file))
        elif 'vars' in rel_path:
            for file in filenames:
                if is_yaml_file(file):
                    result['other_vars'].append(os.path.join(rel_path, file))

    return result

def print_summary(data):
    print("\n📘 Playbooks:")
    for pb in sorted(data['playbooks']):
        print(f"  - {pb}")

    print("\n📦 Roles:")
    for role, contents in data['roles'].items():
        print(f"  - {role}")
        for key, files in contents.items():
            print(f"    • {key}: {len(files)} files")

    print("\n📂 Group Vars:")
    for gv in sorted(data['group_vars']):
        print(f"  - {gv}")

    print("\n📂 Host Vars:")
    for hv in sorted(data['host_vars']):
        print(f"  - {hv}")

    print("\n📂 Other Vars:")
    for ov in sorted(data['other_vars']):
        print(f"  - {ov}")

if __name__ == "__main__":
    root = '/opt/ansible'
    summary = scan_ansible_tree(root)
    print_summary(summary)
