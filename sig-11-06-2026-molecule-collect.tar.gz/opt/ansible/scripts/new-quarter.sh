#!/usr/bin/env bash
#
# new-quarter.sh
#
# Thin gate script, meant to be cron'd (e.g. daily). Each run cheaply
# checks whether the fiscal quarter has rolled over. If it hasn't, it
# exits immediately and touches nothing. If it has, it triggers both
# stack build-and-release scripts, which each handle their own
# directory creation (via their role's "Create and seed quarterly
# directories" task), build, scan, sign, and provenance logging.
#
# Before the Guacamole build, this script also stages the guacd source
# tarballs (guacamole-server-*.tar.gz and sources/*) from the previous
# quarter and verifies them, because the role's seed task does not
# carry *.tar.gz files forward. Large saved image exports
# (*guacd-*.tar.gz) are deliberately not copied.
#
# Do NOT cron play_build_grafana_stack.sh / play_build_guac_release.sh
# directly - they rebuild unconditionally on every invocation. This
# script is what keeps them from running once nothing has changed.

set -uo pipefail

# ---------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------
GRAFANA_BUILD_BASE="/opt/ansible/build/grafana_stack"
GRAFANA_DELIVERY_BASE="/opt/ansible/files/grafana"

GUAC_BUILD_BASE="/opt/ansible/build"
GUAC_DELIVERY_BASE="/opt/ansible/files/avocado"
GUACD_BUILD_BASE="${GUAC_BUILD_BASE}/guacd"

PLAYBOOK_DIR="/opt/ansible/nucleus/playbooks"
LOG_DIR="/opt/ansible/logs"

GRAFANA_PLAY="${PLAYBOOK_DIR}/play_build_grafana_stack.sh"
GUAC_PLAY="${PLAYBOOK_DIR}/play_build_guac_release.sh"

cd "${PLAYBOOK_DIR}" || { echo "ERROR: cannot cd to ${PLAYBOOK_DIR}" >&2; exit 1; }

# ---------------------------------------------------------------------
# Determine current/previous quarter (same source play_build_*.sh use)
# ---------------------------------------------------------------------
eval "$(/opt/ansible/files/common/scripts/determine_quarters.sh)"

echo "Detected quarter: ${quarter}"
echo "Previous quarter: ${previous_quarter}"

if [[ "${quarter}" == "${previous_quarter}" ]]; then
    echo "No quarter change detected (still ${quarter}). Nothing to do."
    exit 0
fi

echo "New quarter detected: ${previous_quarter} -> ${quarter}"

# ---------------------------------------------------------------------
# Ensure top-level stack directories exist.
#
# The per-quarter build/delivery subdirectories (and their component
# subfolders: grafana/prometheus/nginx/idrac, guacamole/guacd/postgres/
# nginx) are created by each role's own "Create and seed quarterly
# directories" task. This only guards the parent paths so that task
# never fails looking for a missing top-level directory on a fresh host.
# ---------------------------------------------------------------------
mkdir -p "${GRAFANA_BUILD_BASE}" "${GRAFANA_DELIVERY_BASE}"
mkdir -p "${GUAC_BUILD_BASE}" "${GUAC_DELIVERY_BASE}"

# ---------------------------------------------------------------------
# Orchestrator log
# ---------------------------------------------------------------------
start_time=$(date +%F-%T)
logfile="${LOG_DIR}/new-quarter-${quarter}-${start_time}.log"

log() { echo "$*" | tee -a "$logfile"; }

log "=== New-quarter run started at ${start_time} (${previous_quarter} -> ${quarter}) ==="

overall_status=0

# ---------------------------------------------------------------------
# Stage guacd source tarballs from the previous quarter.
#
# Copies guacamole-server-*.tar.gz and everything in sources/ into the
# new quarter's guacd directory (never overwriting files already there),
# then verifies every *.tar.gz.sha256 present. Returns non-zero if a
# required source is missing or a checksum fails, so the Guacamole
# build is skipped with a clear message instead of a Docker COPY error.
# ---------------------------------------------------------------------
stage_guacd_sources() {
    local prev_dir="${GUACD_BUILD_BASE}/${previous_quarter,,}"
    local cur_dir="${GUACD_BUILD_BASE}/${quarter,,}"
    local f name copied=0 missing=0

    if [[ ! -d "${prev_dir}" ]]; then
        log "!!! Previous guacd directory not found: ${prev_dir} !!!"
        return 1
    fi

    mkdir -p "${cur_dir}/sources" || return 1

    shopt -s nullglob

    # Top-level source tarball(s) - matches guacamole-server-*, not image exports
    for f in "${prev_dir}"/guacamole-server-*.tar.gz; do
        name="${f##*/}"
        if [[ ! -e "${cur_dir}/${name}" ]]; then
            cp -p "${f}" "${cur_dir}/" && { log "Staged ${name}"; copied=$((copied + 1)); }
        fi
    done

    # Everything in sources/ (e.g. freerdp-*.tar.gz)
    for f in "${prev_dir}"/sources/*; do
        [[ -f "${f}" ]] || continue
        name="${f##*/}"
        if [[ ! -e "${cur_dir}/sources/${name}" ]]; then
            cp -p "${f}" "${cur_dir}/sources/" && { log "Staged sources/${name}"; copied=$((copied + 1)); }
        fi
    done

    log "guacd sources staged: ${copied} file(s) copied from ${previous_quarter,,}"

    # Required files must now exist
    local required=( "${cur_dir}"/guacamole-server-*.tar.gz )
    if (( ${#required[@]} == 0 )); then
        log "!!! No guacamole-server-*.tar.gz in ${cur_dir} !!!"
        missing=1
    fi
    local srcs=( "${cur_dir}"/sources/* )
    if (( ${#srcs[@]} == 0 )); then
        log "!!! ${cur_dir}/sources is empty !!!"
        missing=1
    fi

    # Verify checksums wherever a .sha256 file exists
    local sumfile
    for sumfile in "${cur_dir}"/*.tar.gz.sha256 "${cur_dir}"/sources/*.sha256; do
        if ( cd "${sumfile%/*}" && sha256sum -c --quiet "${sumfile##*/}" ) >>"$logfile" 2>&1; then
            log "Checksum OK: ${sumfile##*/}"
        else
            log "!!! Checksum FAILED: ${sumfile} !!!"
            missing=1
        fi
    done

    shopt -u nullglob
    return "${missing}"
}

# ---------------------------------------------------------------------
# Run Grafana build
# ---------------------------------------------------------------------
log "--- Running ${GRAFANA_PLAY} ---"
"${GRAFANA_PLAY}" 2>&1 | tee -a "$logfile"
grafana_status=${PIPESTATUS[0]}
if [[ "${grafana_status}" -ne 0 ]]; then
    log "!!! Grafana build reported failure (exit ${grafana_status}) !!!"
    overall_status=1
fi

# ---------------------------------------------------------------------
# Run Guacamole build (only if its sources staged cleanly)
# ---------------------------------------------------------------------
log "--- Staging guacd sources ---"
if stage_guacd_sources; then
    log "--- Running ${GUAC_PLAY} ---"
    "${GUAC_PLAY}" 2>&1 | tee -a "$logfile"
    guac_status=${PIPESTATUS[0]}
    if [[ "${guac_status}" -ne 0 ]]; then
        log "!!! Guacamole build reported failure (exit ${guac_status}) !!!"
        overall_status=1
    fi
else
    log "!!! Guacamole build SKIPPED: guacd sources missing or failed verification !!!"
    overall_status=1
fi

# ---------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------
end_time=$(date +%F-%T)
log "=== New-quarter run finished at ${end_time} ==="

if [[ "${overall_status}" -eq 0 ]]; then
    log "=== Both builds completed successfully for quarter ${quarter} ==="
else
    log "=== One or more builds FAILED for quarter ${quarter} - see ${logfile} ==="
fi

exit "${overall_status}"
