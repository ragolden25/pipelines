# Common Git Errors & Fixes

## 📂 Purpose
- Provide a reliable, offline-ready reference for resolving frequent Git errors.
- Support isolated networks and multi-VM workflows where external documentation is unavailable.
- Offer deterministic, repeatable fixes for common Git failure states.

## ⚙️ Tasks
- Resolve push rejections caused by non-fast-forward updates.
- Fix unmerged file states during rebase or merge operations.
- Handle branch divergence between local and remote.
- Correct update rejections caused by missing remote commits.
- Address conflicts without visible markers.
- Exit editors invoked during rebase operations.
- Recover from fast-forward failures.
- Merge unrelated histories when necessary.
- Complete or abort unfinished merges.
- Repair upstream branch mismatches.
- Resolve ambiguous HEAD errors.
- Remove stale Git lock files.
- Diagnose bad revision errors.
- Correct repository path issues.

## 📌 Requirements
- Git installed on the workstation or VM.
- Local clone of the affected repository.
- Basic familiarity with terminal usage.

## ✅ Verification
- {'bash': 'git status'}
- {'bash': 'git branch -vv'}
- {'bash': 'git log --oneline'}

## 📖 Notes
- These fixes assume a single-maintainer workflow where force-with-lease is safe.
- Always run `git status` before taking corrective action.
- Many errors occur after rebasing; expect to use `git push --force-with-lease`.
- Stale lock files often appear after interrupted Git operations.
- Divergence errors are normal when working across multiple VMs.

