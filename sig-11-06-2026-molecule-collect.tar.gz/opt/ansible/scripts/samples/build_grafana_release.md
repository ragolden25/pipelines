# build_grafana_release

## 📂 Purpose
This role generates a complete, deterministic, version-locked artifact set
for a quarterly Grafana stack release. It runs **only on the Ansible control node**
and does not deploy containers. The output is used by the
`deliver_grafana_release` role to create the quarterly GitLab branch.


## ⚙️ Tasks
- Create quarterly directory structure
- Detect container versions and write versions.env
- Render docker-compose.yml from Jinja template
- Copy provisioning files into the quarterly directory
- Validate required files and directories exist
- Freeze all artifacts for the quarterly release

## 📌 Requirements
- Ansible control node with access to /opt/ansible/files/grafana-stack
- Defined quarterly identifier (e.g., FY26Q2)
- Base image variables for Grafana, Prometheus, InfluxDB, Telegraf, and Nginx
- Provisioning templates present in grafana-stack/grafana and grafana-stack/<quarter>

## ✅ Verification
```bash
ls -R /opt/ansible/files/grafana-stack/<quarter>
```
```bash
cat /opt/ansible/files/grafana-stack/<quarter>/versions.env
```
```bash
cat /opt/ansible/files/grafana-stack/<quarter>/docker-compose.yml
```
- Ensure provisioning directory contains dashboards, datasources, and alerting configs
- Confirm no missing variables in rendered templates

## 📖 Notes
This role does not install Docker, Python, or deploy any containers.
It is strictly a build-time artifact generator for quarterly Grafana releases.
All runtime deployment is handled by `deliver_grafana_release`.


## 🚀 Usage
```yaml
- hosts: localhost
  gather_facts: false
  roles:
    - role: build_grafana_release
      vars:
        quarter: "FY26Q2"
        grafana_image: "grafana/grafana"
        prometheus_image: "prom/prometheus"
        influxdb_image: "influxdb"
        telegraf_image: "telegraf"
        nginx_image: "nginx"
        grafana_admin_user: "admin"
        grafana_admin_password: "admin"
```

