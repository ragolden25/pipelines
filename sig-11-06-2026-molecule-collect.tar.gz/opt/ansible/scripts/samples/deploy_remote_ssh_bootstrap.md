# deploy_remote_ssh_bootstrap

## 📂 Purpose
Distribute the Remote SSH Bootstrap PowerShell 7 script to Windows workstations
and provide a Start Menu shortcut for easy access. The script prepares a Linux
host for VS Code Remote-SSH by generating SSH keys if needed, retrieving the
VS Code server tarball from the internal repository, and deploying it to the
user's Linux home directory. This role does not execute the script; it only
installs it for user-driven execution.


## ⚙️ Tasks
- Create the directory used to store company automation scripts.
- Copy the remote-ssh-bootstrap-pwsh7.ps1 script to the workstation.
- Create a Start Menu folder under "Company Tools".
- Add a Start Menu shortcut that launches the script using PowerShell 7.
- Ensure the shortcut uses pwsh.exe so the script always runs under PowerShell 7.


## 📌 Requirements
- PowerShell 7 must already be installed on the workstation.
- The remote-ssh-bootstrap-pwsh7.ps1 script must be placed in the role’s `files/` directory.
- WinRM must be enabled on the target hosts.
- Users must have SSH access to the Linux hosts they intend to bootstrap.
- The internal VS Code repository must be reachable from the workstation when the script is executed.


## 📖 Notes
- The script is intended for manual execution by developers.
- The role does not run the script automatically.
- The script handles SSH key generation, manifest retrieval, tarball download,
  and VS Code server deployment to ~/.vscode-server/bin/<commit>.
- The Start Menu shortcut ensures the script is easy to find and always runs under PowerShell 7.
- This role is part of the workstation bootstrap chain but is executed by the user, not Ansible.


## 🚀 Usage
```yaml
Example playbook:

```yaml
- hosts: windows
  roles:
    - deploy_remote_ssh_bootstrap
```
```

