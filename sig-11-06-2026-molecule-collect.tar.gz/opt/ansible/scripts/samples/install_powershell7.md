# install_powershell7

## 📂 Purpose
Install PowerShell 7 on Windows workstations using an offline MSI package.
The role copies the MSI to a temporary directory, installs it silently, and
removes the installer afterward. It is fully offline-compatible and idempotent.


## ⚙️ Tasks
- Create a temporary directory for the PowerShell 7 installer.
- Copy the PowerShell 7 MSI from the role's `files/` directory to the target.
- Install PowerShell 7 silently using `win_package` with `/quiet /norestart`.
- Remove the MSI from the temporary directory after installation.


## 📌 Requirements
- WinRM must be enabled on the target hosts.
- The PowerShell 7 MSI must be placed in the role’s `files/` directory.
- The role must run with privileges sufficient to install software
  (Ansible uses SYSTEM by default).
- The version and MSI filename must be defined in `vars/main.yml`.


## 📖 Notes
- The role is safe to run multiple times; `win_package` ensures idempotency.
- PowerShell 7 installs system-wide and is available as `pwsh.exe`.
- This role should run before any roles that depend on PowerShell 7,
  such as VS Code extension installation.


## 🚀 Usage
```yaml
Example playbook:

```yaml
- hosts: windows
  roles:
    - install_powershell7
```
```

