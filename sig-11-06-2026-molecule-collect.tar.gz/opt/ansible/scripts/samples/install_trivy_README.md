# install_trivy

## 📂 Purpose
This role installs a complete offline-capable Trivy scanning environment under
/var/lib/containers/trivy. It deploys the directory structure, seed data,
Dockerfile, operator documentation, and version metadata required for
deterministic, operator-friendly vulnerability and SBOM scanning in
disconnected environments. The role is designed to be idempotent, fail-fast,
and fully self-contained.


## ⚙️ Tasks
- Validate container prerequisites
- Create Trivy base directory structure
- Copy operator scripts
- Copy offline image bundles
- Copy offline DB exports
- Copy Dockerfile for auditability
- Copy operator README.md
- Install profile.d launcher for trivy-menu
- Write version metadata
- Append to version_history

## 📌 Requirements
- Docker must already be installed.
- Docker service must be running.
- /var/lib/containers must exist.
- The install_docker_python role must run before this role.
- Target host must support container execution.

## ✅ Verification
- {'bash': 'ls -R /var/lib/containers/trivy'}
- {'bash': 'docker images | grep trivy'}
- {'bash': 'trivy-menu'}

## 📖 Notes
The role installs a deterministic directory structure:

    /var/lib/containers/trivy
    ├── scripts/          # Operator scripts (menu, scans, import/export, DB updates)
    ├── images/           # Offline Trivy image bundles (.tar.gz)
    ├── db_exports/       # Offline Trivy DB exports (.zip)
    ├── Dockerfile        # Dockerfile used to build the Trivy image
    ├── README.md         # Operator-facing documentation
    ├── version           # Current installed version metadata
    └── version_history   # Append-only installation/update log

Seed data includes:
  - A Trivy image bundle placed in images/
  - A Trivy DB export placed in db_exports/

Operators update Trivy by placing new bundles and DB exports into the same
directories. The import-latest workflow automatically selects the newest files
based on timestamp, loads the image as 'latest', installs the DB, and updates
version metadata.


## 🚀 Usage
```yaml
- hosts: all
  roles:
    - install_trivy
```

