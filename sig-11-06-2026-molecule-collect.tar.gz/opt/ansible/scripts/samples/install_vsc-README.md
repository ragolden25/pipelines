# install_vscode

## 📂 Purpose
Install Visual Studio Code on Windows workstations using a PowerShell 7 script.
The script retrieves the latest installer from an offline repository using a
manifest.json file, downloads the correct EXE or MSI, and installs VS Code
silently. Ansible distributes the script to each workstation to ensure the
process is fully offline-compatible and does not rely on direct access to the
repository server.


## ⚙️ Tasks
- Create the directory for the VS Code installer script.
- Copy the vsc-install-latest-pwsh7.ps1 script to the target workstation.
- Execute the script using PowerShell 7 to install Visual Studio Code.
- The script automatically fetches the manifest, downloads the installer,
  and performs a silent installation.


## 📌 Requirements
- PowerShell 7 must already be installed on the target host.
- The vsc-install-latest-pwsh7.ps1 script must be placed in the role’s `files/` directory.
- The offline VS Code repository must be reachable from the target host.
- WinRM must be enabled on the target hosts.


## 📖 Notes
- The script handles both EXE and MSI installers automatically.
- The role is safe to run multiple times; the installer is idempotent.
- This role should run before the per-user VS Code extension installation role.
- Using Ansible to distribute the script ensures consistent behavior across
  all workstations and avoids dependency on direct repository access.


## 🚀 Usage
```yaml
Example playbook:

```yaml
- hosts: windows
  roles:
    - install_vscode
```
```

