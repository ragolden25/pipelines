# install_vscode_extensions

## 📂 Purpose
Install Visual Studio Code extensions on Windows workstations using a
PowerShell 7 script. The script retrieves the list of required extensions
from manifest.json, downloads the corresponding .vsix files from the offline
repository, and installs them using the VS Code command-line interface.
Ansible distributes and executes the script to ensure consistent, offline,
per-user extension installation.


## ⚙️ Tasks
- Create the directory for storing company automation scripts.
- Copy the vsc-extensions-pwsh7.ps1 script to the workstation.
- Execute the script using PowerShell 7.
- The script retrieves extension IDs from manifest.json, downloads matching
  .vsix files, and installs them using code.cmd.


## 📌 Requirements
- PowerShell 7 must already be installed on the workstation.
- Visual Studio Code must already be installed.
- The vsc-extensions-pwsh7.ps1 script must be placed in the role’s `files/` directory.
- WinRM must be enabled on the target hosts.
- The offline VS Code repository must be reachable from the workstation.


## 📖 Notes
- The script installs extensions per user, matching VS Code’s expected behavior.
- The role is safe to run multiple times; VS Code will overwrite existing extensions.
- The script automatically detects the correct code.cmd path.
- The manifest.json file controls which extensions are installed.


## 🚀 Usage
```yaml
Example playbook:

```yaml
- hosts: windows
  roles:
    - install_vscode_extensions
```
```

