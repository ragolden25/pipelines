# Git Knowledge Base

## 📂 Purpose
- Centralized, offline-ready reference for Git workflows and troubleshooting.
- Designed for isolated networks, multi-VM environments, and single-maintainer repos.
- Provides deterministic, repeatable patterns for daily Git operations.

## ⚙️ Tasks
- Use the Git Operations Handbook for full workflows and explanations.
- Use the Git Quick Reference for fast, copy/paste-friendly commands.
- Use the Git Workflow Guide to understand recommended patterns and philosophy.
- Consult Common Git Errors & Fixes when specific error messages appear.
- Extend this knowledge base over time with new patterns, errors, and workflows.

## 📌 Requirements
- Git installed on the workstation or VM.
- Local clone of relevant repositories.
- Basic familiarity with terminal usage.

## ✅ Verification
- {'bash': 'git --version'}
- {'bash': 'git status'}
- {'bash': 'git remote -v'}

## 📖 Notes
- This repository is tool-agnostic and role-agnostic; it applies to any Git-based project.
- Intended for long-term reuse across roles, repos, and environments (including air-gapped).
- Favor `git pull --rebase` and `git push --force-with-lease` for clean, linear history in single-maintainer workflows.
- When in doubt, run `git status` to understand the current state before acting.

## 🚀 Usage
```yaml
# Example: clone and keep this repo handy on isolated networks
git clone git@gitlab.nuc2.scires.com:git/knowledge-base.git

# Suggested layout on an Ansible control node
/opt/ansible/knowledge-base/
  GIT_OPERATIONS_HANDBOOK.md
  GIT_QUICK_REFERENCE.md
  GIT_WORKFLOW_GUIDE.md
```

