#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# Interactive Syft + Grype Scan Script
# Creates /opt/scans/ddmonyyyy/
# Runs syft → grype against a selected Docker image
# =====================================================================

SCAN_ROOT="/opt/scans"
DATE="$(date +%d%b%Y | tr '[:upper:]' '[:lower:]')"   # e.g., 22jul2026
OUT_DIR="${SCAN_ROOT}/${DATE}"

GRYPE_CONFIG="/opt/ansible/grype-offline/grype.yaml"   # adjust if needed
GRYPE_DB_DIR="/opt/ansible/grype-offline/db"           # adjust if needed

mkdir -p "${OUT_DIR}"

echo "==> Scan directory: ${OUT_DIR}"
echo ""

# =====================================================================
# 1. List Docker images
# =====================================================================

echo "Available Docker images:"
echo "------------------------------------------------------------"

mapfile -t IMAGES < <(docker images --format '{{.Repository}}:{{.Tag}}')

i=1
for img in "${IMAGES[@]}"; do
    echo "  [$i] ${img}"
    ((i++))
done

echo ""
read -rp "Enter the number of the image to scan: " choice

# Validate choice
if ! [[ "${choice}" =~ ^[0-9]+$ ]] || (( choice < 1 || choice > ${#IMAGES[@]} )); then
    echo "Invalid selection."
    exit 1
fi

IMAGE="${IMAGES[$((choice-1))]}"

echo ""
echo "==> Selected image: ${IMAGE}"
echo ""

# =====================================================================
# 2. Run Syft SBOM scan
# =====================================================================

SBOM_OUT="${OUT_DIR}/$(echo "${IMAGE}" | tr '/:' '_')-sbom.json"

echo "==> Running Syft SBOM scan..."
docker run --rm \
    -v /var/run/docker.sock:/var/run/docker.sock \
    anchore/syft:latest \
    "${IMAGE}" -o json > "${SBOM_OUT}"

echo "==> SBOM saved to: ${SBOM_OUT}"
echo ""

# =====================================================================
# 3. Run Grype vulnerability scan (offline)
# =====================================================================

GRYPE_OUT="${OUT_DIR}/$(echo "${IMAGE}" | tr '/:' '_')-vuln.json"

echo "==> Running Grype vulnerability scan (offline mode)..."
docker run --rm \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v "${GRYPE_DB_DIR}:${GRYPE_DB_DIR}" \
    -v "${GRYPE_CONFIG}:${GRYPE_CONFIG}" \
    -e GRYPE_CONFIG="${GRYPE_CONFIG}" \
    anchore/grype:latest \
    "${IMAGE}" -o json > "${GRYPE_OUT}"

echo "==> Vulnerability report saved to: ${GRYPE_OUT}"
echo ""

# =====================================================================
# Summary
# =====================================================================

echo "=============================================================="
echo "Scan complete for image: ${IMAGE}"
echo ""
echo "SBOM: ${SBOM_OUT}"
echo "Vuln: ${GRYPE_OUT}"
echo ""
echo "Scan directory:"
echo "  ${OUT_DIR}"
echo "=============================================================="
