#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="/opt/ansible/logs"
LOG_FILE="$LOG_DIR/quarterly-verify.log"

ROLE_DIR="/opt/ansible/roles/build_grafana_release"
TASK_DIR="$ROLE_DIR/tasks"
SCRIPT_DIR="/opt/ansible/scripts"

REQUIRED_TASKS=(
  "main.yml"
  "clean_task.yml"
  "detect_versions.yml"
  "save_images.yml"
  "render_compose.yml"
  "generate_provisioning.yml"
  "generate_metadata.yml"
  "set_permissions.yml"
)

REQUIRED_SCRIPTS=(
  "new-quarter.sh"
  "docker-weekly-clean.sh"
  "fix-ansible-permissions.sh"
)

mkdir -p "$LOG_DIR"

echo "=== Quarterly System Verification ($(date)) ===" | tee "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

STATUS=0

# ---------------------------------------------------------
# Verify role directory exists
# ---------------------------------------------------------
if [ ! -d "$ROLE_DIR" ]; then
    echo "ERROR: Role directory missing: $ROLE_DIR" | tee -a "$LOG_FILE"
    STATUS=1
else
    echo "OK: Role directory exists." | tee -a "$LOG_FILE"
fi

# ---------------------------------------------------------
# Verify task files
# ---------------------------------------------------------
echo "" | tee -a "$LOG_FILE"
echo "--- Checking task files ---" | tee -a "$LOG_FILE"

for file in "${REQUIRED_TASKS[@]}"; do
    if [ ! -f "$TASK_DIR/$file" ]; then
        echo "MISSING: $TASK_DIR/$file" | tee -a "$LOG_FILE"
        STATUS=1
    else
        echo "OK: $file" | tee -a "$LOG_FILE"
    fi
done

# ---------------------------------------------------------
# Verify script directory exists
# ---------------------------------------------------------
echo "" | tee -a "$LOG_FILE"
if [ ! -d "$SCRIPT_DIR" ]; then
    echo "ERROR: Script directory missing: $SCRIPT_DIR" | tee -a "$LOG_FILE"
    STATUS=1
else
    echo "OK: Script directory exists." | tee -a "$LOG_FILE"
fi

# ---------------------------------------------------------
# Verify required scripts
# ---------------------------------------------------------
echo "" | tee -a "$LOG_FILE"
echo "--- Checking scripts ---" | tee -a "$LOG_FILE"

for script in "${REQUIRED_SCRIPTS[@]}"; do
    if [ ! -f "$SCRIPT_DIR/$script" ]; then
        echo "MISSING: $SCRIPT_DIR/$script" | tee -a "$LOG_FILE"
        STATUS=1
    else
        echo "OK: $script" | tee -a "$LOG_FILE"
    fi
done

# ---------------------------------------------------------
# Final status
# ---------------------------------------------------------
echo "" | tee -a "$LOG_FILE"

if [ "$STATUS" -eq 0 ]; then
    echo "=== All required quarterly assets are present. Ready for testing. ===" | tee -a "$LOG_FILE"
else
    echo "=== Missing items detected. Review log before testing. ===" | tee -a "$LOG_FILE"
fi

exit "$STATUS"
