#!/bin/bash
set -euo pipefail

TASK_DIR="/opt/ansible/nucleus/roles/build_grafana_release/tasks"
SCRIPT_DIR="/opt/ansible/files/grafana/scripts"

echo "=== Verifying that all scripts in ${SCRIPT_DIR} are referenced in tasks ==="
echo

# 1. List all scripts in the scripts directory
SCRIPTS=$(find "${SCRIPT_DIR}" -maxdepth 1 -type f -name "*.sh" -printf "%f\n" | sort)

echo "Scripts found in ${SCRIPT_DIR}:"
echo "${SCRIPTS}" | sed 's/^/  - /'
echo

# 2. Search for each script name in the task files
echo "--- Checking references in task files ---"
echo

REFERENCED=""
UNREFERENCED=""

for script in ${SCRIPTS}; do
    if grep -Rqs "${script}" "${TASK_DIR}"; then
        echo "FOUND: ${script}"
        REFERENCED="${REFERENCED}${script}\n"
    else
        echo "NOT FOUND: ${script}"
        UNREFERENCED="${UNREFERENCED}${script}\n"
    fi
done

echo
echo "=== Summary ==="
echo

echo "Referenced scripts:"
if [ -n "${REFERENCED}" ]; then
    echo -e "${REFERENCED}" | sed 's/^/  - /'
else
    echo "  None"
fi

echo
echo "Unreferenced scripts (present on disk but not used in tasks):"
if [ -n "${UNREFERENCED}" ]; then
    echo -e "${UNREFERENCED}" | sed 's/^/  - /'
else
    echo "  None"
fi

echo
echo "=== Verification complete ==="

