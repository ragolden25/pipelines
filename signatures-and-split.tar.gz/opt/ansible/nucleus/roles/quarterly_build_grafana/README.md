# quarterly_build_grafana

Quarterly build of `grafana`. Defines `quarterly_component` in `defaults/main.yml`
and runs `quarterly_common`. See that role for the steps, paths and the last-good fallback.
