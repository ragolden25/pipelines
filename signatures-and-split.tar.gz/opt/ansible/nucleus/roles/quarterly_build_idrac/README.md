# quarterly_build_idrac

Quarterly build of `idrac`. Defines `quarterly_component` in `defaults/main.yml`
and runs `quarterly_common`. See that role for the steps, paths and the last-good fallback.
