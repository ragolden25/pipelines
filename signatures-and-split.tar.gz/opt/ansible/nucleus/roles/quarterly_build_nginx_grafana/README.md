# quarterly_build_nginx_grafana

Quarterly build of `nginx_grafana`. Defines `quarterly_component` in `defaults/main.yml`
and runs `quarterly_common`. See that role for the steps, paths and the last-good fallback.
